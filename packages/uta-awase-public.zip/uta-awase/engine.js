import {CARDS} from './cards.js';
export const wins = (a,b) => ({姫:'殿',殿:'坊主',坊主:'姫'}[a]===b);
export function shuffle(arr,rng=Math.random){let a=[...arr];for(let i=a.length-1;i>0;i--){let j=Math.floor(rng()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;}
export function drawPack(rng=Math.random){
 const pack=[];const rates={N:60,R:27,SR:10,UR:3};
 for(let i=0;i<5;i++){
  const guaranteed=i===4 && pack.every(c=>c.rarity==='N');
  const available=CARDS.filter(c=>!pack.includes(c));
  const ranks=Object.keys(rates).filter(r=>(!guaranteed||r!=='N')&&available.some(c=>c.rarity===r));
  let roll=rng()*ranks.reduce((s,r)=>s+rates[r],0), rank=ranks.at(-1);
  for(const r of ranks){roll-=rates[r];if(roll<0){rank=r;break;}}
  const pool=available.filter(c=>c.rarity===rank);pack.push(pool[Math.floor(rng()*pool.length)]);
 }return pack;
}
export function createBattle(player,cpu,secondFirst=0,tieFirst=0){return {hands:[player,cpu],hp:[100,100],shield:[null,null],sealed:[false,false],boost:[false,false],prevLoss:[0,0],secondFirst,tieFirst,round:0,history:[],finished:false};}
export function resolveRound(s){
 if(s.finished||s.round>=5)throw Error('対戦は終了しています');
 const r=s.round, cards=s.hands.map(h=>h[r]);const start=[...s.hp], losses=[0,0];
 const first=r===0?(wins(cards[0].attr,cards[1].attr)?0:wins(cards[1].attr,cards[0].attr)?1:s.tieFirst):(s.secondFirst+(r-1))%2;
 const events=[];
 for(const side of [first,1-first]){
  if(s.hp.some(h=>h<=0))break;
  const enemy=1-side,c=cards[side],before=[...s.hp];
  const advantage=wins(c.attr,cards[enemy].attr),boosted=s.boost[side];s.boost[side]=false;
  const multiplier=(advantage?1.5:1)*(boosted?1.5:1);
  let base=0,type=c.category, detail='',value=0;
  switch(c.kind){
   case 'attack':case 'heal':base=20;break;
   case 'strong':base=30;break;
   case 'attackFirst':case 'healFirst':base=r===0?30:15;break;
   case 'attackLast':case 'healLast':base=r===4?30:15;break;
   case 'attackLow':case 'healLow':base=s.hp[side]<=50?30:15;break;
   case 'currentHalf':base=s.hp[side]/2;break;
   case 'lostHalf':case 'lostHeal':base=Math.max(0,100-s.hp[side])/2;break;
   case 'prevHeal':base=s.prevLoss[side];break;
   case 'swap':[s.hp[side],s.hp[enemy]]=[s.hp[enemy],s.hp[side]];detail='双方の華を交換';break;
   case 'half':s.shield[side]=.5;detail='次に受ける攻撃を1回半減';break;
   case 'null':s.shield[side]=0;detail='次に受ける攻撃を1回無効';break;
   case 'seal':s.sealed[enemy]=true;detail='相手の次の回復を1回封印';break;
   case 'boost':if(r<4){s.boost[side]=true;detail='次の札の数値効果 ×1.5';}else detail='次の札がないため不発';break;
  }
  if(type==='攻撃'){
   value=Math.floor(base*multiplier);
   if(s.shield[enemy]!==null){value=Math.floor(value*s.shield[enemy]);detail=s.shield[enemy]===0?'守護により無効':'守護により半減';s.shield[enemy]=null;}
   s.hp[enemy]-=value;losses[enemy]+=value;detail=`相手の華 −${value}${detail?'・'+detail:''}`;
  }else if(type==='回復'){
   value=Math.floor(base*multiplier);
   if(s.sealed[side]){s.sealed[side]=false;value=0;detail='回復封印により無効';}
   s.hp[side]+=value;detail=detail||`自分の華 ＋${value}`;
  }
  events.push({side,card:c.id,name:c.ability,type,base,value,multiplier,advantage,boosted,before,after:[...s.hp],detail,status:{shield:[...s.shield],sealed:[...s.sealed],boost:[...s.boost]}});
 }
 s.prevLoss=losses;s.round++;
 s.finished=s.hp.some(h=>h<=0)||s.round>=5;
 const record={round:r,cards:cards.map(c=>c.id),first,start,end:[...s.hp],events};s.history.push(record);return record;
}
export const winner=s=>s.hp[0]===s.hp[1]?'draw':s.hp[0]>s.hp[1]?'win':'lose';
export function simulate(player,cpu,second=0,tie=0){const s=createBattle(player,cpu,second,tie);while(!s.finished)resolveRound(s);return s;}
export function arrangeCPU(cpu,opponent,rng=Math.random){
 // Only the opponent's unordered set is used. Never observe the player's formation.
 const visible=[...opponent].sort((a,b)=>a.id-b.id);
 const samples=Array.from({length:8},()=>shuffle(visible,rng));
 const candidates=Array.from({length:32},()=>shuffle(cpu,rng));
 const scored=candidates.map(hand=>({hand,score:samples.reduce((sum,p,i)=>{
  const s=simulate(p,hand,i%2,(i>>1)%2);const margin=s.hp[1]-s.hp[0];return sum+margin+(s.hp[0]<=0?70:0)-(s.hp[1]<=0?70:0);
 },0)/samples.length+rng()*18})).sort((a,b)=>b.score-a.score);
 return scored[Math.floor(rng()*Math.min(5,scored.length))].hand;
}
