export const CARDS = [
  {
    "id": 1,
    "set": "ogura",
    "name": "天智天皇",
    "poem": [
      "秋の田の",
      "かりほの庵の",
      "苫をあらみ",
      "わが衣手は",
      "露にぬれつつ"
    ],
    "attr": "殿",
    "rarity": "N",
    "ability": "露の衣",
    "kind": "heal",
    "category": "回復",
    "description": "自分の華＋20。"
  },
  {
    "id": 2,
    "set": "ogura",
    "name": "持統天皇",
    "poem": [
      "春すぎて",
      "夏来にけらし",
      "白妙の",
      "衣ほすてふ",
      "天の香具山"
    ],
    "attr": "姫",
    "rarity": "R",
    "ability": "夏衣",
    "kind": "healFirst",
    "category": "回復",
    "description": "自分の華＋15。一の番なら＋30。"
  },
  {
    "id": 3,
    "set": "ogura",
    "name": "柿本人麻呂",
    "poem": [
      "あしびきの",
      "山鳥の尾の",
      "しだり尾の",
      "ながながし夜を",
      "ひとりかも寝む"
    ],
    "attr": "殿",
    "rarity": "N",
    "ability": "長き夜",
    "kind": "heal",
    "category": "回復",
    "description": "自分の華＋20。"
  },
  {
    "id": 4,
    "set": "ogura",
    "name": "山部赤人",
    "poem": [
      "田子の浦に",
      "うち出でて見れば",
      "白妙の",
      "富士の高嶺に",
      "雪はふりつつ"
    ],
    "attr": "殿",
    "rarity": "N",
    "ability": "白妙の雪",
    "kind": "heal",
    "category": "回復",
    "description": "自分の華＋20。"
  },
  {
    "id": 5,
    "set": "ogura",
    "name": "猿丸大夫",
    "poem": [
      "奥山に",
      "もみぢ踏み分け",
      "鳴く鹿の",
      "声聞く時ぞ",
      "秋は悲しき"
    ],
    "attr": "殿",
    "rarity": "N",
    "ability": "鹿の音",
    "kind": "attack",
    "category": "攻撃",
    "description": "相手の華−20。"
  },
  {
    "id": 6,
    "set": "ogura",
    "name": "中納言家持",
    "poem": [
      "かささぎの",
      "渡せる橋に",
      "おく霜の",
      "白きを見れば",
      "夜ぞふけにける"
    ],
    "attr": "殿",
    "rarity": "N",
    "ability": "霜の橋",
    "kind": "half",
    "category": "守護",
    "description": "発動後、次に受ける攻撃を1回半減。"
  },
  {
    "id": 7,
    "set": "ogura",
    "name": "安倍仲麿",
    "poem": [
      "天の原",
      "ふりさけ見れば",
      "春日なる",
      "三笠の山に",
      "出でし月かも"
    ],
    "attr": "殿",
    "rarity": "R",
    "ability": "望郷の月",
    "kind": "healLast",
    "category": "回復",
    "description": "自分の華＋15。五の番なら＋30。"
  },
  {
    "id": 8,
    "set": "ogura",
    "name": "喜撰法師",
    "poem": [
      "わが庵は",
      "都のたつみ",
      "しかぞすむ",
      "世をうぢ山と",
      "人はいふなり"
    ],
    "attr": "坊主",
    "rarity": "R",
    "ability": "宇治の庵",
    "kind": "healLow",
    "category": "回復",
    "description": "自分の華＋15。自分の華50以下なら＋30。"
  },
  {
    "id": 9,
    "set": "ogura",
    "name": "小野小町",
    "poem": [
      "花の色は",
      "うつりにけりな",
      "いたづらに",
      "わが身世にふる",
      "ながめせしまに"
    ],
    "attr": "姫",
    "rarity": "UR",
    "ability": "散華",
    "kind": "currentHalf",
    "category": "攻撃",
    "description": "現在の自分の華の半分で攻撃。"
  },
  {
    "id": 10,
    "set": "ogura",
    "name": "蝉丸",
    "poem": [
      "これやこの",
      "行くも帰るも",
      "別れては",
      "知るも知らぬも",
      "あふ坂の関"
    ],
    "attr": "坊主",
    "rarity": "UR",
    "ability": "逢坂の関",
    "kind": "swap",
    "category": "交換",
    "description": "自分と相手の現在の華を交換。"
  },
  {
    "id": 11,
    "set": "ogura",
    "name": "参議篁",
    "poem": [
      "わたの原",
      "八十島かけて",
      "漕ぎ出でぬと",
      "人には告げよ",
      "あまのつり舟"
    ],
    "attr": "殿",
    "rarity": "N",
    "ability": "八十島越え",
    "kind": "attackFirst",
    "category": "攻撃",
    "description": "相手の華−15。一の番なら−30。"
  },
  {
    "id": 12,
    "set": "ogura",
    "name": "僧正遍昭",
    "poem": [
      "天つ風",
      "雲のかよひ路",
      "吹きとぢよ",
      "をとめの姿",
      "しばしとどめむ"
    ],
    "attr": "坊主",
    "rarity": "SR",
    "ability": "雲の通ひ路",
    "kind": "null",
    "category": "守護",
    "description": "発動後、次に受ける攻撃を1回無効。"
  },
  {
    "id": 13,
    "set": "ogura",
    "name": "陽成院",
    "poem": [
      "つくばねの",
      "峰より落つる",
      "みなの川",
      "こひぞつもりて",
      "淵となりぬる"
    ],
    "attr": "殿",
    "rarity": "R",
    "ability": "積もる恋",
    "kind": "attackLast",
    "category": "攻撃",
    "description": "相手の華−15。五の番なら−30。"
  },
  {
    "id": 14,
    "set": "ogura",
    "name": "河原左大臣",
    "poem": [
      "陸奥の",
      "しのぶもぢずり",
      "誰ゆゑに",
      "乱れそめにし",
      "われならなくに"
    ],
    "attr": "殿",
    "rarity": "N",
    "ability": "乱れ染め",
    "kind": "attack",
    "category": "攻撃",
    "description": "相手の華−20。"
  },
  {
    "id": 15,
    "set": "ogura",
    "name": "光孝天皇",
    "poem": [
      "君がため",
      "春の野に出でて",
      "若菜つむ",
      "わが衣手に",
      "雪はふりつつ"
    ],
    "attr": "殿",
    "rarity": "R",
    "ability": "若菜摘み",
    "kind": "heal",
    "category": "回復",
    "description": "自分の華＋20。"
  },
  {
    "id": 16,
    "set": "ogura",
    "name": "中納言行平",
    "poem": [
      "立ち別れ",
      "いなばの山の",
      "峰に生ふる",
      "まつとし聞かば",
      "今帰り来む"
    ],
    "attr": "殿",
    "rarity": "R",
    "ability": "今帰り来む",
    "kind": "prevHeal",
    "category": "回復",
    "description": "直前の番で攻撃により失った華を回復。"
  },
  {
    "id": 17,
    "set": "ogura",
    "name": "在原業平朝臣",
    "poem": [
      "ちはやぶる",
      "神代もきかず",
      "竜田川",
      "からくれなゐに",
      "水くくるとは"
    ],
    "attr": "殿",
    "rarity": "UR",
    "ability": "ちはやぶる",
    "kind": "strong",
    "category": "攻撃",
    "description": "相手の華−30。"
  },
  {
    "id": 18,
    "set": "ogura",
    "name": "藤原敏行朝臣",
    "poem": [
      "住の江の",
      "岸による波",
      "よるさへや",
      "夢の通ひ路",
      "人めよくらむ"
    ],
    "attr": "殿",
    "rarity": "N",
    "ability": "夢の通ひ路",
    "kind": "attack",
    "category": "攻撃",
    "description": "相手の華−20。"
  },
  {
    "id": 19,
    "set": "ogura",
    "name": "伊勢",
    "poem": [
      "難波潟",
      "みじかき葦の",
      "ふしの間も",
      "あはでこの世を",
      "過ぐしてよとや"
    ],
    "attr": "姫",
    "rarity": "R",
    "ability": "葦のひと節",
    "kind": "attackFirst",
    "category": "攻撃",
    "description": "相手の華−15。一の番なら−30。"
  },
  {
    "id": 20,
    "set": "ogura",
    "name": "元良親王",
    "poem": [
      "わびぬれば",
      "今はた同じ",
      "難波なる",
      "みをつくしても",
      "あはむとぞ思ふ"
    ],
    "attr": "殿",
    "rarity": "SR",
    "ability": "身を尽くす",
    "kind": "lostHalf",
    "category": "攻撃",
    "description": "100から失った自分の華の半分で攻撃。"
  },
  {
    "id": 21,
    "set": "ogura",
    "name": "素性法師",
    "poem": [
      "今こむと",
      "言ひしばかりに",
      "長月の",
      "有明の月を",
      "待ちいでつるかな"
    ],
    "attr": "坊主",
    "rarity": "R",
    "ability": "有明待ち",
    "kind": "healLast",
    "category": "回復",
    "description": "自分の華＋15。五の番なら＋30。"
  },
  {
    "id": 22,
    "set": "ogura",
    "name": "文屋康秀",
    "poem": [
      "吹くからに",
      "秋の草木の",
      "しをるれば",
      "むべ山風を",
      "嵐といふらむ"
    ],
    "attr": "殿",
    "rarity": "N",
    "ability": "山風の嵐",
    "kind": "attack",
    "category": "攻撃",
    "description": "相手の華−20。"
  },
  {
    "id": 23,
    "set": "ogura",
    "name": "大江千里",
    "poem": [
      "月みれば",
      "千々に物こそ",
      "悲しけれ",
      "我が身ひとつの",
      "秋にはあらねど"
    ],
    "attr": "殿",
    "rarity": "R",
    "ability": "千々の月",
    "kind": "lostHeal",
    "category": "回復",
    "description": "100から失った自分の華の半分を回復。"
  },
  {
    "id": 24,
    "set": "ogura",
    "name": "菅家",
    "poem": [
      "このたびは",
      "ぬさもとりあへず",
      "手向山",
      "紅葉のにしき",
      "神のまにまに"
    ],
    "attr": "殿",
    "rarity": "SR",
    "ability": "紅葉の幣",
    "kind": "boost",
    "category": "強化",
    "description": "次の自分の札の数値効果を1.5倍。五の番では不発。"
  },
  {
    "id": 25,
    "set": "ogura",
    "name": "三条右大臣",
    "poem": [
      "名にしおはば",
      "逢坂山の",
      "さねかづら",
      "人に知られで",
      "くるよしもがな"
    ],
    "attr": "殿",
    "rarity": "N",
    "ability": "さねかづら",
    "kind": "attack",
    "category": "攻撃",
    "description": "相手の華−20。"
  },
  {
    "id": 26,
    "set": "ogura",
    "name": "貞信公",
    "poem": [
      "小倉山",
      "峰のもみぢ葉",
      "心あらば",
      "今ひとたびの",
      "みゆき待たなむ"
    ],
    "attr": "殿",
    "rarity": "R",
    "ability": "御幸待ち",
    "kind": "healLast",
    "category": "回復",
    "description": "自分の華＋15。五の番なら＋30。"
  },
  {
    "id": 27,
    "set": "ogura",
    "name": "中納言兼輔",
    "poem": [
      "みかの原",
      "わきて流るる",
      "いづみ川",
      "いつみきとてか",
      "恋しかるらむ"
    ],
    "attr": "殿",
    "rarity": "N",
    "ability": "いづみ川",
    "kind": "heal",
    "category": "回復",
    "description": "自分の華＋20。"
  },
  {
    "id": 28,
    "set": "ogura",
    "name": "源宗于朝臣",
    "poem": [
      "山里は",
      "冬ぞさびしさ",
      "まさりける",
      "人めも草も",
      "かれぬと思へば"
    ],
    "attr": "殿",
    "rarity": "N",
    "ability": "冬の山里",
    "kind": "half",
    "category": "守護",
    "description": "発動後、次に受ける攻撃を1回半減。"
  },
  {
    "id": 29,
    "set": "ogura",
    "name": "凡河内躬恒",
    "poem": [
      "心あてに",
      "折らばや折らむ",
      "初霜の",
      "おきまどはせる",
      "白菊の花"
    ],
    "attr": "殿",
    "rarity": "R",
    "ability": "白菊の花",
    "kind": "healLow",
    "category": "回復",
    "description": "自分の華＋15。自分の華50以下なら＋30。"
  },
  {
    "id": 30,
    "set": "ogura",
    "name": "壬生忠岑",
    "poem": [
      "ありあけの",
      "つれなく見えし",
      "別れより",
      "暁ばかり",
      "憂きものはなし"
    ],
    "attr": "殿",
    "rarity": "N",
    "ability": "暁の別れ",
    "kind": "attack",
    "category": "攻撃",
    "description": "相手の華−20。"
  },
  {
    "id": 31,
    "set": "ogura",
    "name": "坂上是則",
    "poem": [
      "朝ぼらけ",
      "ありあけの月と",
      "見るまでに",
      "吉野の里に",
      "降れる白雪"
    ],
    "attr": "殿",
    "rarity": "N",
    "ability": "吉野の白雪",
    "kind": "heal",
    "category": "回復",
    "description": "自分の華＋20。"
  },
  {
    "id": 32,
    "set": "ogura",
    "name": "春道列樹",
    "poem": [
      "山川に",
      "風のかけたる",
      "しがらみは",
      "流れもあへぬ",
      "紅葉なりけり"
    ],
    "attr": "殿",
    "rarity": "SR",
    "ability": "紅葉のしがらみ",
    "kind": "null",
    "category": "守護",
    "description": "発動後、次に受ける攻撃を1回無効。"
  },
  {
    "id": 33,
    "set": "ogura",
    "name": "紀友則",
    "poem": [
      "ひさかたの",
      "光のどけき",
      "春の日に",
      "しづ心なく",
      "花の散るらむ"
    ],
    "attr": "殿",
    "rarity": "N",
    "ability": "春の散花",
    "kind": "attack",
    "category": "攻撃",
    "description": "相手の華−20。"
  },
  {
    "id": 34,
    "set": "ogura",
    "name": "藤原興風",
    "poem": [
      "誰をかも",
      "知る人にせむ",
      "高砂の",
      "松も昔の",
      "友ならなくに"
    ],
    "attr": "殿",
    "rarity": "N",
    "ability": "高砂の松",
    "kind": "heal",
    "category": "回復",
    "description": "自分の華＋20。"
  },
  {
    "id": 35,
    "set": "ogura",
    "name": "紀貫之",
    "poem": [
      "人はいさ",
      "心も知らず",
      "ふるさとは",
      "花ぞ昔の",
      "香に匂ひける"
    ],
    "attr": "殿",
    "rarity": "R",
    "ability": "昔の香",
    "kind": "prevHeal",
    "category": "回復",
    "description": "直前の番で攻撃により失った華を回復。"
  },
  {
    "id": 36,
    "set": "ogura",
    "name": "清原深養父",
    "poem": [
      "夏の夜は",
      "まだ宵ながら",
      "明けぬるを",
      "雲のいづこに",
      "月やどるらむ"
    ],
    "attr": "殿",
    "rarity": "N",
    "ability": "雲居の月",
    "kind": "half",
    "category": "守護",
    "description": "発動後、次に受ける攻撃を1回半減。"
  },
  {
    "id": 37,
    "set": "ogura",
    "name": "文屋朝康",
    "poem": [
      "白露に",
      "風の吹きしく",
      "秋の野は",
      "つらぬきとめぬ",
      "玉ぞ散りける"
    ],
    "attr": "殿",
    "rarity": "N",
    "ability": "散る白露",
    "kind": "attack",
    "category": "攻撃",
    "description": "相手の華−20。"
  },
  {
    "id": 38,
    "set": "ogura",
    "name": "右近",
    "poem": [
      "忘らるる",
      "身をば思はず",
      "誓ひてし",
      "人のいのちの",
      "惜しくもあるかな"
    ],
    "attr": "姫",
    "rarity": "R",
    "ability": "命の誓ひ",
    "kind": "healLow",
    "category": "回復",
    "description": "自分の華＋15。自分の華50以下なら＋30。"
  },
  {
    "id": 39,
    "set": "ogura",
    "name": "参議等",
    "poem": [
      "浅茅生の",
      "小野の篠原",
      "しのぶれど",
      "あまりてなどか",
      "人の恋しき"
    ],
    "attr": "殿",
    "rarity": "N",
    "ability": "忍ぶ恋",
    "kind": "attack",
    "category": "攻撃",
    "description": "相手の華−20。"
  },
  {
    "id": 40,
    "set": "ogura",
    "name": "平兼盛",
    "poem": [
      "しのぶれど",
      "色に出でにけり",
      "わが恋は",
      "物や思ふと",
      "人の問ふまで"
    ],
    "attr": "殿",
    "rarity": "SR",
    "ability": "色に出づ",
    "kind": "attackLow",
    "category": "攻撃",
    "description": "相手の華−15。自分の華50以下なら−30。"
  },
  {
    "id": 41,
    "set": "ogura",
    "name": "壬生忠見",
    "poem": [
      "恋すてふ",
      "わが名はまだき",
      "立ちにけり",
      "人知れずこそ",
      "思ひ初めしか"
    ],
    "attr": "殿",
    "rarity": "R",
    "ability": "恋の名",
    "kind": "attackFirst",
    "category": "攻撃",
    "description": "相手の華−15。一の番なら−30。"
  },
  {
    "id": 42,
    "set": "ogura",
    "name": "清原元輔",
    "poem": [
      "契りきな",
      "かたみに袖を",
      "しぼりつつ",
      "末の松山",
      "波越さじとは"
    ],
    "attr": "殿",
    "rarity": "R",
    "ability": "末の松山",
    "kind": "half",
    "category": "守護",
    "description": "発動後、次に受ける攻撃を1回半減。"
  },
  {
    "id": 43,
    "set": "ogura",
    "name": "権中納言敦忠",
    "poem": [
      "あひ見ての",
      "のちの心に",
      "くらぶれば",
      "昔は物を",
      "思はざりけり"
    ],
    "attr": "殿",
    "rarity": "R",
    "ability": "逢瀬の後",
    "kind": "attackLast",
    "category": "攻撃",
    "description": "相手の華−15。五の番なら−30。"
  },
  {
    "id": 44,
    "set": "ogura",
    "name": "中納言朝忠",
    "poem": [
      "あふことの",
      "たえてしなくは",
      "なかなかに",
      "人をも身をも",
      "恨みざらまし"
    ],
    "attr": "殿",
    "rarity": "N",
    "ability": "絶えし逢瀬",
    "kind": "seal",
    "category": "封印",
    "description": "発動後、相手の回復を次の1回だけ無効。"
  },
  {
    "id": 45,
    "set": "ogura",
    "name": "謙徳公",
    "poem": [
      "あはれとも",
      "いふべき人は",
      "思ほえで",
      "身のいたづらに",
      "なりぬべきかな"
    ],
    "attr": "殿",
    "rarity": "N",
    "ability": "尽きぬ嘆き",
    "kind": "attack",
    "category": "攻撃",
    "description": "相手の華−20。"
  },
  {
    "id": 46,
    "set": "ogura",
    "name": "曾禰好忠",
    "poem": [
      "由良のとを",
      "渡る舟人",
      "かぢを絶え",
      "ゆくへも知らぬ",
      "恋の道かな"
    ],
    "attr": "殿",
    "rarity": "N",
    "ability": "恋の舟",
    "kind": "attack",
    "category": "攻撃",
    "description": "相手の華−20。"
  },
  {
    "id": 47,
    "set": "ogura",
    "name": "恵慶法師",
    "poem": [
      "八重むぐら",
      "しげれる宿の",
      "さびしきに",
      "人こそ見えね",
      "秋は来にけり"
    ],
    "attr": "坊主",
    "rarity": "N",
    "ability": "秋の訪れ",
    "kind": "heal",
    "category": "回復",
    "description": "自分の華＋20。"
  },
  {
    "id": 48,
    "set": "ogura",
    "name": "源重之",
    "poem": [
      "風をいたみ",
      "岩うつ波の",
      "おのれのみ",
      "くだけて物を",
      "思ふころかな"
    ],
    "attr": "殿",
    "rarity": "R",
    "ability": "砕ける波",
    "kind": "lostHalf",
    "category": "攻撃",
    "description": "100から失った自分の華の半分で攻撃。"
  },
  {
    "id": 49,
    "set": "ogura",
    "name": "大中臣能宣",
    "poem": [
      "みかきもり",
      "衛士のたく火の",
      "夜は燃え",
      "昼は消えつつ",
      "物をこそ思へ"
    ],
    "attr": "殿",
    "rarity": "N",
    "ability": "衛士の火",
    "kind": "attack",
    "category": "攻撃",
    "description": "相手の華−20。"
  },
  {
    "id": 50,
    "set": "ogura",
    "name": "藤原義孝",
    "poem": [
      "君がため",
      "惜しからざりし",
      "命さへ",
      "長くもがなと",
      "思ひけるかな"
    ],
    "attr": "殿",
    "rarity": "SR",
    "ability": "長き命",
    "kind": "healLow",
    "category": "回復",
    "description": "自分の華＋15。自分の華50以下なら＋30。"
  },
  {
    "id": 51,
    "set": "ogura",
    "name": "藤原実方朝臣",
    "poem": [
      "かくとだに",
      "えやはいぶきの",
      "さしも草",
      "さしも知らじな",
      "もゆる思ひを"
    ],
    "attr": "殿",
    "rarity": "R",
    "ability": "もゆる思ひ",
    "kind": "attackLow",
    "category": "攻撃",
    "description": "相手の華−15。自分の華50以下なら−30。"
  },
  {
    "id": 52,
    "set": "ogura",
    "name": "藤原道信朝臣",
    "poem": [
      "明けぬれば",
      "暮るるものとは",
      "知りながら",
      "なほうらめしき",
      "朝ぼらけかな"
    ],
    "attr": "殿",
    "rarity": "N",
    "ability": "朝ぼらけの恨み",
    "kind": "attack",
    "category": "攻撃",
    "description": "相手の華−20。"
  },
  {
    "id": 53,
    "set": "ogura",
    "name": "右大将道綱母",
    "poem": [
      "嘆きつつ",
      "ひとり寝る夜の",
      "明くるまは",
      "いかに久しき",
      "ものとかは知る"
    ],
    "attr": "姫",
    "rarity": "R",
    "ability": "ひとり寝の夜",
    "kind": "healLast",
    "category": "回復",
    "description": "自分の華＋15。五の番なら＋30。"
  },
  {
    "id": 54,
    "set": "ogura",
    "name": "儀同三司母",
    "poem": [
      "忘れじの",
      "行く末までは",
      "かたければ",
      "今日をかぎりの",
      "命ともがな"
    ],
    "attr": "姫",
    "rarity": "R",
    "ability": "今日をかぎり",
    "kind": "attackLast",
    "category": "攻撃",
    "description": "相手の華−15。五の番なら−30。"
  },
  {
    "id": 55,
    "set": "ogura",
    "name": "大納言公任",
    "poem": [
      "滝の音は",
      "絶えて久しく",
      "なりぬれど",
      "名こそ流れて",
      "なほ聞こえけれ"
    ],
    "attr": "殿",
    "rarity": "R",
    "ability": "滝の名残",
    "kind": "boost",
    "category": "強化",
    "description": "次の自分の札の数値効果を1.5倍。五の番では不発。"
  },
  {
    "id": 56,
    "set": "ogura",
    "name": "和泉式部",
    "poem": [
      "あらざらむ",
      "この世のほかの",
      "思ひ出に",
      "今ひとたびの",
      "逢ふこともがな"
    ],
    "attr": "姫",
    "rarity": "SR",
    "ability": "今ひとたび",
    "kind": "healLow",
    "category": "回復",
    "description": "自分の華＋15。自分の華50以下なら＋30。"
  },
  {
    "id": 57,
    "set": "ogura",
    "name": "紫式部",
    "poem": [
      "めぐりあひて",
      "見しやそれとも",
      "分かぬまに",
      "雲がくれにし",
      "夜半の月かな"
    ],
    "attr": "姫",
    "rarity": "UR",
    "ability": "めぐり逢ひ",
    "kind": "prevHeal",
    "category": "回復",
    "description": "直前の番で攻撃により失った華を回復。"
  },
  {
    "id": 58,
    "set": "ogura",
    "name": "大弐三位",
    "poem": [
      "ありま山",
      "ゐなの笹原",
      "風吹けば",
      "いでそよ人を",
      "忘れやはする"
    ],
    "attr": "姫",
    "rarity": "N",
    "ability": "忘れぬ笹風",
    "kind": "heal",
    "category": "回復",
    "description": "自分の華＋20。"
  },
  {
    "id": 59,
    "set": "ogura",
    "name": "赤染衛門",
    "poem": [
      "やすらはで",
      "寝なましものを",
      "さ夜更けて",
      "かたぶくまでの",
      "月を見しかな"
    ],
    "attr": "姫",
    "rarity": "N",
    "ability": "傾く月",
    "kind": "healLast",
    "category": "回復",
    "description": "自分の華＋15。五の番なら＋30。"
  },
  {
    "id": 60,
    "set": "ogura",
    "name": "小式部内侍",
    "poem": [
      "大江山",
      "いく野の道の",
      "遠ければ",
      "まだふみも見ず",
      "天の橋立"
    ],
    "attr": "姫",
    "rarity": "R",
    "ability": "天の橋立",
    "kind": "attackFirst",
    "category": "攻撃",
    "description": "相手の華−15。一の番なら−30。"
  },
  {
    "id": 61,
    "set": "ogura",
    "name": "伊勢大輔",
    "poem": [
      "いにしへの",
      "奈良の都の",
      "八重桜",
      "けふ九重に",
      "にほひぬるかな"
    ],
    "attr": "姫",
    "rarity": "R",
    "ability": "八重桜",
    "kind": "heal",
    "category": "回復",
    "description": "自分の華＋20。"
  },
  {
    "id": 62,
    "set": "ogura",
    "name": "清少納言",
    "poem": [
      "夜をこめて",
      "鳥のそらねは",
      "はかるとも",
      "よに逢坂の",
      "関はゆるさじ"
    ],
    "attr": "姫",
    "rarity": "SR",
    "ability": "関はゆるさじ",
    "kind": "null",
    "category": "守護",
    "description": "発動後、次に受ける攻撃を1回無効。"
  },
  {
    "id": 63,
    "set": "ogura",
    "name": "左京大夫道雅",
    "poem": [
      "今はただ",
      "思ひ絶えなむ",
      "とばかりを",
      "人づてならで",
      "言ふよしもがな"
    ],
    "attr": "殿",
    "rarity": "N",
    "ability": "思ひ絶え",
    "kind": "seal",
    "category": "封印",
    "description": "発動後、相手の回復を次の1回だけ無効。"
  },
  {
    "id": 64,
    "set": "ogura",
    "name": "権中納言定頼",
    "poem": [
      "朝ぼらけ",
      "宇治の川霧",
      "たえだえに",
      "あらはれわたる",
      "瀬々の網代木"
    ],
    "attr": "殿",
    "rarity": "N",
    "ability": "川霧晴れ",
    "kind": "heal",
    "category": "回復",
    "description": "自分の華＋20。"
  },
  {
    "id": 65,
    "set": "ogura",
    "name": "相模",
    "poem": [
      "恨みわび",
      "ほさぬ袖だに",
      "あるものを",
      "恋にくちなむ",
      "名こそ惜しけれ"
    ],
    "attr": "姫",
    "rarity": "R",
    "ability": "濡れ袖の恋",
    "kind": "lostHalf",
    "category": "攻撃",
    "description": "100から失った自分の華の半分で攻撃。"
  },
  {
    "id": 66,
    "set": "ogura",
    "name": "前大僧正行尊",
    "poem": [
      "もろともに",
      "あはれと思へ",
      "山桜",
      "花よりほかに",
      "知る人もなし"
    ],
    "attr": "坊主",
    "rarity": "SR",
    "ability": "ともに山桜",
    "kind": "lostHeal",
    "category": "回復",
    "description": "100から失った自分の華の半分を回復。"
  },
  {
    "id": 67,
    "set": "ogura",
    "name": "周防内侍",
    "poem": [
      "春の夜の",
      "夢ばかりなる",
      "手枕に",
      "かひなく立たむ",
      "名こそ惜しけれ"
    ],
    "attr": "姫",
    "rarity": "R",
    "ability": "夢の手枕",
    "kind": "half",
    "category": "守護",
    "description": "発動後、次に受ける攻撃を1回半減。"
  },
  {
    "id": 68,
    "set": "ogura",
    "name": "三条院",
    "poem": [
      "心にも",
      "あらでうき世に",
      "ながらへば",
      "恋しかるべき",
      "夜半の月かな"
    ],
    "attr": "殿",
    "rarity": "N",
    "ability": "夜半の月",
    "kind": "heal",
    "category": "回復",
    "description": "自分の華＋20。"
  },
  {
    "id": 69,
    "set": "ogura",
    "name": "能因法師",
    "poem": [
      "あらし吹く",
      "み室の山の",
      "もみぢ葉は",
      "竜田の川の",
      "錦なりけり"
    ],
    "attr": "坊主",
    "rarity": "N",
    "ability": "竜田の錦",
    "kind": "attack",
    "category": "攻撃",
    "description": "相手の華−20。"
  },
  {
    "id": 70,
    "set": "ogura",
    "name": "良暹法師",
    "poem": [
      "さびしさに",
      "宿をたち出でて",
      "ながむれば",
      "いづこも同じ",
      "秋の夕暮れ"
    ],
    "attr": "坊主",
    "rarity": "N",
    "ability": "秋の夕暮れ",
    "kind": "heal",
    "category": "回復",
    "description": "自分の華＋20。"
  },
  {
    "id": 71,
    "set": "ogura",
    "name": "大納言経信",
    "poem": [
      "夕されば",
      "門田の稲葉",
      "おとづれて",
      "葦のまろやに",
      "秋風ぞ吹く"
    ],
    "attr": "殿",
    "rarity": "N",
    "ability": "稲葉の秋風",
    "kind": "attack",
    "category": "攻撃",
    "description": "相手の華−20。"
  },
  {
    "id": 72,
    "set": "ogura",
    "name": "祐子内親王家紀伊",
    "poem": [
      "音にきく",
      "たかしの浜の",
      "あだ波は",
      "かけじや袖の",
      "ぬれもこそすれ"
    ],
    "attr": "姫",
    "rarity": "R",
    "ability": "袖にかけじ",
    "kind": "half",
    "category": "守護",
    "description": "発動後、次に受ける攻撃を1回半減。"
  },
  {
    "id": 73,
    "set": "ogura",
    "name": "前中納言匡房",
    "poem": [
      "高砂の",
      "をのへの桜",
      "咲きにけり",
      "外山のかすみ",
      "立たずもあらなむ"
    ],
    "attr": "殿",
    "rarity": "N",
    "ability": "尾上の桜",
    "kind": "heal",
    "category": "回復",
    "description": "自分の華＋20。"
  },
  {
    "id": 74,
    "set": "ogura",
    "name": "源俊頼朝臣",
    "poem": [
      "憂かりける",
      "人を初瀬の",
      "山おろしよ",
      "はげしかれとは",
      "祈らぬものを"
    ],
    "attr": "殿",
    "rarity": "N",
    "ability": "初瀬の山おろし",
    "kind": "attack",
    "category": "攻撃",
    "description": "相手の華−20。"
  },
  {
    "id": 75,
    "set": "ogura",
    "name": "藤原基俊",
    "poem": [
      "契りおきし",
      "させもが露を",
      "いのちにて",
      "あはれ今年の",
      "秋もいぬめり"
    ],
    "attr": "殿",
    "rarity": "N",
    "ability": "させもの露",
    "kind": "heal",
    "category": "回復",
    "description": "自分の華＋20。"
  },
  {
    "id": 76,
    "set": "ogura",
    "name": "法性寺入道前関白太政大臣",
    "poem": [
      "わたの原",
      "こぎ出でてみれば",
      "久方の",
      "雲ゐにまがふ",
      "冲つ白波"
    ],
    "attr": "坊主",
    "rarity": "R",
    "ability": "沖つ白波",
    "kind": "attackFirst",
    "category": "攻撃",
    "description": "相手の華−15。一の番なら−30。"
  },
  {
    "id": 77,
    "set": "ogura",
    "name": "崇徳院",
    "poem": [
      "瀬をはやみ",
      "岩にせかるる",
      "滝川の",
      "われても末に",
      "あはむとぞ思ふ"
    ],
    "attr": "殿",
    "rarity": "SR",
    "ability": "われても末に",
    "kind": "prevHeal",
    "category": "回復",
    "description": "直前の番で攻撃により失った華を回復。"
  },
  {
    "id": 78,
    "set": "ogura",
    "name": "源兼昌",
    "poem": [
      "淡路島",
      "かよふ千鳥の",
      "鳴く声に",
      "幾夜ねざめぬ",
      "須磨の関守"
    ],
    "attr": "殿",
    "rarity": "N",
    "ability": "須磨の関守",
    "kind": "half",
    "category": "守護",
    "description": "発動後、次に受ける攻撃を1回半減。"
  },
  {
    "id": 79,
    "set": "ogura",
    "name": "左京大夫顕輔",
    "poem": [
      "秋風に",
      "たなびく雲の",
      "たえ間より",
      "もれ出づる月の",
      "かげのさやけさ"
    ],
    "attr": "殿",
    "rarity": "N",
    "ability": "雲間の月",
    "kind": "heal",
    "category": "回復",
    "description": "自分の華＋20。"
  },
  {
    "id": 80,
    "set": "ogura",
    "name": "待賢門院堀河",
    "poem": [
      "長からむ",
      "心も知らず",
      "黒髪の",
      "乱れてけさは",
      "物をこそ思へ"
    ],
    "attr": "姫",
    "rarity": "N",
    "ability": "乱るる黒髪",
    "kind": "attack",
    "category": "攻撃",
    "description": "相手の華−20。"
  },
  {
    "id": 81,
    "set": "ogura",
    "name": "後徳大寺左大臣",
    "poem": [
      "ほととぎす",
      "鳴きつる方を",
      "ながむれば",
      "ただありあけの",
      "月ぞ残れる"
    ],
    "attr": "殿",
    "rarity": "N",
    "ability": "残る月",
    "kind": "healLast",
    "category": "回復",
    "description": "自分の華＋15。五の番なら＋30。"
  },
  {
    "id": 82,
    "set": "ogura",
    "name": "道因法師",
    "poem": [
      "思ひわび",
      "さてもいのちは",
      "あるものを",
      "憂きにたへぬは",
      "涙なりけり"
    ],
    "attr": "坊主",
    "rarity": "N",
    "ability": "たへぬ涙",
    "kind": "lostHeal",
    "category": "回復",
    "description": "100から失った自分の華の半分を回復。"
  },
  {
    "id": 83,
    "set": "ogura",
    "name": "皇太后宮大夫俊成",
    "poem": [
      "世の中よ",
      "道こそなけれ",
      "思ひ入る",
      "山の奥にも",
      "鹿ぞ鳴くなる"
    ],
    "attr": "殿",
    "rarity": "R",
    "ability": "山奥の鹿",
    "kind": "attackLow",
    "category": "攻撃",
    "description": "相手の華−15。自分の華50以下なら−30。"
  },
  {
    "id": 84,
    "set": "ogura",
    "name": "藤原清輔朝臣",
    "poem": [
      "ながらへば",
      "またこのごろや",
      "しのばれむ",
      "憂しと見し世ぞ",
      "今は恋しき"
    ],
    "attr": "殿",
    "rarity": "N",
    "ability": "恋しき日々",
    "kind": "prevHeal",
    "category": "回復",
    "description": "直前の番で攻撃により失った華を回復。"
  },
  {
    "id": 85,
    "set": "ogura",
    "name": "俊恵法師",
    "poem": [
      "夜もすがら",
      "物思ふころは",
      "明けやらで",
      "閨のひまさへ",
      "つれなかりけり"
    ],
    "attr": "坊主",
    "rarity": "N",
    "ability": "明けぬ夜",
    "kind": "seal",
    "category": "封印",
    "description": "発動後、相手の回復を次の1回だけ無効。"
  },
  {
    "id": 86,
    "set": "ogura",
    "name": "西行法師",
    "poem": [
      "嘆けとて",
      "月やは物を",
      "思はする",
      "かこち顔なる",
      "わが涙かな"
    ],
    "attr": "坊主",
    "rarity": "SR",
    "ability": "かこち顔",
    "kind": "lostHalf",
    "category": "攻撃",
    "description": "100から失った自分の華の半分で攻撃。"
  },
  {
    "id": 87,
    "set": "ogura",
    "name": "寂蓮法師",
    "poem": [
      "村雨の",
      "露もまだひぬ",
      "まきの葉に",
      "霧立ちのぼる",
      "秋の夕暮れ"
    ],
    "attr": "坊主",
    "rarity": "R",
    "ability": "村雨の霧",
    "kind": "half",
    "category": "守護",
    "description": "発動後、次に受ける攻撃を1回半減。"
  },
  {
    "id": 88,
    "set": "ogura",
    "name": "皇嘉門院別当",
    "poem": [
      "難波江の",
      "葦のかりねの",
      "ひとよゆゑ",
      "みをつくしてや",
      "恋ひわたるべき"
    ],
    "attr": "姫",
    "rarity": "N",
    "ability": "ひと夜の恋",
    "kind": "attack",
    "category": "攻撃",
    "description": "相手の華−20。"
  },
  {
    "id": 89,
    "set": "ogura",
    "name": "式子内親王",
    "poem": [
      "玉のをよ",
      "たえなばたえね",
      "ながらへば",
      "忍ぶることの",
      "弱りもぞする"
    ],
    "attr": "姫",
    "rarity": "SR",
    "ability": "玉の緒",
    "kind": "attackLow",
    "category": "攻撃",
    "description": "相手の華−15。自分の華50以下なら−30。"
  },
  {
    "id": 90,
    "set": "ogura",
    "name": "殷富門院大輔",
    "poem": [
      "見せばやな",
      "雄島のあまの",
      "袖だにも",
      "濡れにぞ濡れし",
      "色は変はらず"
    ],
    "attr": "姫",
    "rarity": "N",
    "ability": "変はらぬ袖",
    "kind": "heal",
    "category": "回復",
    "description": "自分の華＋20。"
  },
  {
    "id": 91,
    "set": "ogura",
    "name": "後京極摂政前太政大臣",
    "poem": [
      "きりぎりす",
      "鳴くや霜夜の",
      "さむしろに",
      "衣かたしき",
      "ひとりかも寝む"
    ],
    "attr": "殿",
    "rarity": "N",
    "ability": "霜夜の衣",
    "kind": "half",
    "category": "守護",
    "description": "発動後、次に受ける攻撃を1回半減。"
  },
  {
    "id": 92,
    "set": "ogura",
    "name": "二条院讃岐",
    "poem": [
      "わが袖は",
      "潮干に見えぬ",
      "沖の石の",
      "人こそ知らね",
      "乾くまもなし"
    ],
    "attr": "姫",
    "rarity": "N",
    "ability": "乾かぬ袖",
    "kind": "heal",
    "category": "回復",
    "description": "自分の華＋20。"
  },
  {
    "id": 93,
    "set": "ogura",
    "name": "鎌倉右大臣",
    "poem": [
      "世の中は",
      "つねにもがもな",
      "渚こぐ",
      "あまの小舟の",
      "綱手かなしも"
    ],
    "attr": "殿",
    "rarity": "SR",
    "ability": "つねにもがもな",
    "kind": "null",
    "category": "守護",
    "description": "発動後、次に受ける攻撃を1回無効。"
  },
  {
    "id": 94,
    "set": "ogura",
    "name": "参議雅経",
    "poem": [
      "み吉野の",
      "山の秋風",
      "さ夜ふけて",
      "ふるさと寒く",
      "衣うつなり"
    ],
    "attr": "殿",
    "rarity": "N",
    "ability": "衣打つ音",
    "kind": "attack",
    "category": "攻撃",
    "description": "相手の華−20。"
  },
  {
    "id": 95,
    "set": "ogura",
    "name": "前大僧正慈円",
    "poem": [
      "おほけなく",
      "うき世の民に",
      "おほふかな",
      "わが立つ杣に",
      "すみぞめの袖"
    ],
    "attr": "坊主",
    "rarity": "SR",
    "ability": "墨染の袖",
    "kind": "null",
    "category": "守護",
    "description": "発動後、次に受ける攻撃を1回無効。"
  },
  {
    "id": 96,
    "set": "ogura",
    "name": "入道前太政大臣",
    "poem": [
      "花さそふ",
      "嵐の庭の",
      "雪ならで",
      "ふりゆくものは",
      "わが身なりけり"
    ],
    "attr": "坊主",
    "rarity": "R",
    "ability": "花誘ふ嵐",
    "kind": "attackLow",
    "category": "攻撃",
    "description": "相手の華−15。自分の華50以下なら−30。"
  },
  {
    "id": 97,
    "set": "ogura",
    "name": "権中納言定家",
    "poem": [
      "こぬ人を",
      "まつほの浦の",
      "夕なぎに",
      "焼くやもしほの",
      "身もこがれつつ"
    ],
    "attr": "殿",
    "rarity": "UR",
    "ability": "百人一首",
    "kind": "boost",
    "category": "強化",
    "description": "次の自分の札の数値効果を1.5倍。五の番では不発。"
  },
  {
    "id": 98,
    "set": "ogura",
    "name": "従二位家隆",
    "poem": [
      "風そよぐ",
      "ならの小川の",
      "夕暮れは",
      "みそぎぞ夏の",
      "しるしなりける"
    ],
    "attr": "殿",
    "rarity": "N",
    "ability": "夏のみそぎ",
    "kind": "heal",
    "category": "回復",
    "description": "自分の華＋20。"
  },
  {
    "id": 99,
    "set": "ogura",
    "name": "後鳥羽院",
    "poem": [
      "人もをし",
      "人も恨めし",
      "あぢきなく",
      "世を思ふゆゑに",
      "物思ふ身は"
    ],
    "attr": "殿",
    "rarity": "N",
    "ability": "愛憎の世",
    "kind": "attack",
    "category": "攻撃",
    "description": "相手の華−20。"
  },
  {
    "id": 100,
    "set": "ogura",
    "name": "順徳院",
    "poem": [
      "百敷や",
      "ふるき軒端の",
      "しのぶにも",
      "なほあまりある",
      "昔なりけり"
    ],
    "attr": "殿",
    "rarity": "SR",
    "ability": "古き軒端",
    "kind": "healLast",
    "category": "回復",
    "description": "自分の華＋15。五の番なら＋30。"
  }
];
export const SETS = [{id:"ogura", name:"小倉百人一首", count:100}];
