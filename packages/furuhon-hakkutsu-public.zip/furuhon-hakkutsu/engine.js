export const genres=['文学','実用','雑誌','写真','画集','洋書','児童書','漫画','専門書','郷土資料','歴史','科学','哲学','趣味','旅行','料理','その他'];
export const tagNames=['恋愛','青春','家族','人生','歴史','戦争','旅行','料理','健康','仕事','趣味','芸術','音楽','映画','スポーツ','鉄道','車','生き物','自然','怪奇','哲学','科学','地元','懐かしい','役立つ','美しい','奇妙','難解','冒険','社会'];
export const rules=[];function add(id,name,description,test){rules.push({id,name,description,test})}
const genreRoots=['文学青年','人生を100円ずつ改善中','時代を綴じる人','文字を読む気がない','本棚美術館','読めるとは言ってない','心はまだ図書室','コマの中の住人','研究室の居候','地元から出る気がない','過去へ引っ越す人','好奇心の研究者','人生について考えすぎ','休日が足りない','本棚だけ世界一周','読む前に作れ','分類できない人生'];
const steps=[1,3,5,10,20,40,70,100,150,250];const stage=['のはじめの一冊','の見習い','','の常連','の蔵書家','の案内人','の達人','の主宰者','の守護者','の伝説'];
genres.forEach((g,i)=>steps.forEach((n,j)=>add(`genre-${i}-${j}`,genreRoots[i]+stage[j],`${g}の購入が${n}冊になりました。気になる本の積み重ねが、あなたの棚になります。`,s=>s.genres[g]>=n)));
const tagRoots=['恋は古本に聞け','青春延長申請中','家族のしおり','人生の予習帳','歴史の立会人','平和の記憶係','乗らずに旅する','積ん読レストラン','健康への不安がすごい','100円で成功したい','趣味が本業','1000円美術館','紙上の指揮者','活字の映画館','本棚の運動部','鉄分多め','書斎ドライバー','紙の動物園','机上の森林浴','夜に読む本しかない','答えより問いを買う','博士ここにいましたか','郷土愛が重すぎる','昭和の思い出係','明日から本気出す','装丁より想像','なぜこれを選んだ','理解する気はある','冒険は棚から','社会を読む人'];
const ts=[1,3,5,10,20,40,80,150],suffix=['：最初のしおり','：入門編','','：探求編','：収集編','：常連編','：熟練編','：殿堂入り'];
tagNames.forEach((t,i)=>ts.forEach((n,j)=>add(`tag-${i}-${j}`,tagRoots[i]+suffix[j],`「${t}」のゲーム用タグを持つ本を累計${n}冊購入。興味の足跡が蔵書に残りました。`,s=>s.tags[t]>=n)));
['A','B','C'].forEach((c,i)=>steps.forEach((n,j)=>add(`state-${c}-${j}`,['ぴかぴか古本愛好家','なじむ古本生活','ボロ本救済センター'][i]+stage[j],`状態${c}の本を累計${n}冊。状態はゲーム上の架空の個体設定です。`,s=>s.conditions[c]>=n)));
export function era(year){return !Number.isFinite(year)?'不明':year<1912?'明治以前':year<1926?'大正':year<1989?'昭和':year<2019?'平成':year>=2019?'令和':'不明'}
['明治以前','大正','昭和','平成','令和','2000年代'].forEach((e,i)=>[1,5,15,40,100].forEach((n,j)=>add(`era-${i}-${j}`,['古い時代の散歩人','大正への寄り道','昭和から帰ってこない人','平成の記憶保管室','令和の古本日記','二千年紀の書庫係'][i]+['：出会い','','：常連','：書庫','：語り部'][j],`${e}の本を累計${n}冊購入。刊行年は収録版の書誌情報に基づきます。`,s=>s.eras[e]>=n)));
export const rarityBands=[[1,30,'COMMON'],[31,50,'UNCOMMON'],[51,70,'DISCOVERY'],[71,89,'RARE!'],[90,97,'SUPER RARE!!'],[98,99,'ULTRA RARE!!'],[100,100,'LEGENDARY']];
rarityBands.forEach(([lo,hi,label],i)=>[1,5,20].forEach((n,j)=>add(`rarity-${i}-${j}`,['価値は俺が決める','普通の中の小さな発見','静かな棚の目利き','レア本の案内人','驚きの収集家','奇跡を綴じる人','伝説の一冊'][i]+['','：五つの出会い','：二十の宝物'][j],`RARITY ${lo===hi?lo:lo+'〜'+hi}の本を累計${n}冊発掘。現実の価格や評価とは関係のないゲーム設定です。`,s=>s.rarityCounts[i]>=n)));
[1,10,30,50,100,200,350,500,1000].forEach((n,i)=>add(`shelf-${i}`,['本に選ばれた人','小さな本棚の主','棚を漁る常連','蔵書票のある暮らし','百冊の物語','本棚からはみ出す人','床にも本がある','家が古本屋','千冊の司書'][i],`累計${n}冊を購入しました。次の一冊は、あなたが選びます。`,s=>s.total>=n));

// Combination awards consider the entire collection, alongside progression awards.
const mixes=[
 ['文字より色彩の棚','写真・画集をそれぞれ3冊以上収集。',s=>s.genres['写真']>=3&&s.genres['画集']>=3],
 ['献立と生活の作戦室','料理・実用をそれぞれ3冊以上収集。',s=>s.genres['料理']>=3&&s.genres['実用']>=3],
 ['物語と問いの同居人','文学・哲学をそれぞれ3冊以上収集。',s=>s.genres['文学']>=3&&s.genres['哲学']>=3],
 ['時間旅行の切符売り','歴史・旅行をそれぞれ3冊以上収集。',s=>s.genres['歴史']>=3&&s.genres['旅行']>=3],
 ['帰省先は本棚','郷土資料・歴史をそれぞれ3冊以上収集。',s=>s.genres['郷土資料']>=3&&s.genres['歴史']>=3],
 ['研究の合間の寄り道','科学・趣味をそれぞれ3冊以上収集。',s=>s.genres['科学']>=3&&s.genres['趣味']>=3],
 ['図書室と放課後','児童書・漫画をそれぞれ3冊以上収集。',s=>s.genres['児童書']>=3&&s.genres['漫画']>=3],
 ['国境を越えるしおり','洋書・旅行をそれぞれ3冊以上収集。',s=>s.genres['洋書']>=3&&s.genres['旅行']>=3],
 ['まじめと遊びの二段棚','専門書・漫画をそれぞれ3冊以上収集。',s=>s.genres['専門書']>=3&&s.genres['漫画']>=3],
 ['昨日のニュース明日の暮らし','雑誌・実用をそれぞれ3冊以上収集。',s=>s.genres['雑誌']>=3&&s.genres['実用']>=3],
 ['本棚に思想なし','10冊以上の蔵書に10種類以上のジャンル。',s=>s.total>=10&&Object.values(s.genres).filter(n=>n>0).length>=10],
 ['もはやファン','20冊以上の蔵書で一つのジャンルが8割以上。',s=>s.total>=20&&Math.max(...Object.values(s.genres))>=s.total*.8],
 ['一発逆転の本棚','低レアを5冊以上、RARITY90以上も発見。',s=>s.rarityCounts[0]>=5&&s.max>=90],
 ['きれいも傷みも物語','状態AとCをそれぞれ5冊以上収集。',s=>s.conditions.A>=5&&s.conditions.C>=5],
 ['昭和と令和の橋渡し','昭和・令和の本をそれぞれ5冊以上収集。',s=>s.eras['昭和']>=5&&s.eras['令和']>=5],
 ['地図と鉄路の空想旅','旅行・鉄道タグをそれぞれ5冊以上収集。',s=>s.tags['旅行']>=5&&s.tags['鉄道']>=5],
 ['恋と人生の相談窓口','恋愛・人生タグをそれぞれ5冊以上収集。',s=>s.tags['恋愛']>=5&&s.tags['人生']>=5],
 ['食べて元気になる予定','料理・健康タグをそれぞれ5冊以上収集。',s=>s.tags['料理']>=5&&s.tags['健康']>=5],
 ['深夜二時の研究室','怪奇・科学タグをそれぞれ5冊以上収集。',s=>s.tags['怪奇']>=5&&s.tags['科学']>=5],
 ['積ん読とは言わせない棚','異なる100タイトルと5ジャンル以上を収集。',s=>s.unique>=100&&Object.values(s.genres).filter(n=>n>0).length>=5]
];
mixes.forEach(([name,description,test],i)=>{const index=rules.findIndex(r=>r.id===`tag-${i+10}-7`);rules[index]={id:`mix-${i}`,name,description,test}});

export function aggregate(purchases){const s={total:purchases.length,unique:new Set(purchases.map(p=>p.book.title)).size,max:0,average:0,genres:Object.fromEntries(genres.map(g=>[g,0])),tags:Object.fromEntries(tagNames.map(t=>[t,0])),conditions:{A:0,B:0,C:0},eras:{'明治以前':0,'大正':0,'昭和':0,'平成':0,'令和':0,'不明':0,'2000年代':0},rarityCounts:Array(7).fill(0)};let sum=0;for(const{book:b}of purchases){s.genres[b.genre]=(s.genres[b.genre]||0)+1;s.conditions[b.condition]++;s.eras[era(b.year)]++;if(b.year>=2000&&b.year<=2009)s.eras['2000年代']++;for(const t of new Set(b.tags))s.tags[t]=(s.tags[t]||0)+1;sum+=b.rarity;s.max=Math.max(s.max,b.rarity);s.rarityCounts[rarityBands.findIndex(([lo,hi])=>b.rarity>=lo&&b.rarity<=hi)]++}s.average=s.total?Math.round(sum/s.total*10)/10:0;return s}
export function purchase(state,book){if(state.pending)throw Error('前の鑑定が未完了です');if(!book||!Number.isInteger(book.rarity)||book.rarity<1||book.rarity>100)throw Error('書籍データが無効です');const p={id:crypto.randomUUID(),book:structuredClone(book),at:new Date().toISOString()};const purchases=[...state.purchases,p];const stats=aggregate(purchases),awardRecords={...state.awardRecords},newAwards=[];for(const r of rules)if(!awardRecords[r.id]&&r.test(stats)){awardRecords[r.id]={at:stats.total,date:p.at};newAwards.push(r.id)}return{...state,purchases,stats,awardRecords,pending:{id:p.id,newAwards}}}
export function shuffle(a){const b=[...a];for(let i=b.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[b[i],b[j]]=[b[j],b[i]]}return b}
