// One persistent music player and a separate effects bus; both honor the saved sound switch.
export function createBookshopAudio(isEnabled){
 let ctx,master,musicGain,effectsGain,player,source,unlocked=false,playing=false,duckTimer,duckUntil=0,silent=false;
 const voices=new Set(),levels={music:.14,ducked:.035,effects:.72};
 function ensure(){
  if(ctx)return true;
  const AudioContext=window.AudioContext||window.webkitAudioContext;if(!AudioContext)return false;
  try{ctx=new AudioContext();master=ctx.createGain();master.gain.value=isEnabled()?1:0;const limiter=ctx.createDynamicsCompressor();limiter.threshold.value=-10;limiter.knee.value=12;limiter.ratio.value=5;master.connect(limiter);limiter.connect(ctx.destination);effectsGain=ctx.createGain();effectsGain.gain.value=levels.effects;effectsGain.connect(master);musicGain=ctx.createGain();musicGain.gain.value=levels.music;musicGain.connect(master);
   player=new Audio(new URL('./quiet-bookshop.mp3',import.meta.url).href);player.loop=true;player.preload='auto';player.setAttribute('playsinline','');source=ctx.createMediaElementSource(player);source.connect(musicGain);return true;
  }catch{return false}
 }
 function unlock(){if(!isEnabled()||document.hidden||!ensure())return;unlocked=true;ctx.resume().catch(()=>{});if(!silent&&player.paused&&!playing){playing=true;Promise.resolve(player.play()).catch(()=>{}).finally(()=>playing=false)}}
 function sync(){if(!isEnabled()){clearTimeout(duckTimer);duckUntil=0;if(player)player.pause();stopEffects();if(master)master.gain.setValueAtTime(0,ctx.currentTime);if(musicGain){musicGain.gain.cancelScheduledValues(ctx.currentTime);musicGain.gain.setValueAtTime(levels.music,ctx.currentTime)}return}if(ensure()){master.gain.setValueAtTime(1,ctx.currentTime);unlock()}}
 function duck(seconds=.3){if(!musicGain)return;duckUntil=Math.max(duckUntil,Date.now()+seconds*1000);const t=ctx.currentTime;musicGain.gain.cancelScheduledValues(t);musicGain.gain.setTargetAtTime(levels.ducked,t,.025);clearTimeout(duckTimer);duckTimer=setTimeout(()=>{if(isEnabled()&&!document.hidden){musicGain.gain.cancelScheduledValues(ctx.currentTime);musicGain.gain.setTargetAtTime(levels.music,ctx.currentTime,.22)}},Math.max(0,duckUntil-Date.now()))}
 function stopEffects(){for(const o of voices){try{o.stop()}catch{}}voices.clear()}
 function note(f,start,duration,volume=.12,type='sine',endFrequency){const o=ctx.createOscillator(),g=ctx.createGain(),t=ctx.currentTime+start;o.type=type;o.frequency.setValueAtTime(f,t);if(endFrequency)o.frequency.exponentialRampToValueAtTime(endFrequency,t+duration);g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(volume,t+.012);g.gain.exponentialRampToValueAtTime(.0001,t+duration);o.connect(g);g.connect(effectsGain);voices.add(o);o.onended=()=>{voices.delete(o);o.disconnect();g.disconnect()};o.start(t);o.stop(t+duration+.02)}
 function silence(){silent=true;clearTimeout(duckTimer);player?.pause();stopEffects()}
 function resumeMusic(){silent=false;sync()}
 function sound(kind,rarity=0){if(!isEnabled()||document.hidden)return;if(kind==='reveal')silent=false;unlock();if(!ctx)return;
  if(kind==='reveal'||kind==='appraise'||kind==='award')stopEffects();
  if(kind==='tap'){duck(.14);note(710,0,.06,.07,'triangle',520)}
  else if(kind==='select'){duck(.3);note(523,0,.12,.13,'triangle');note(784,.065,.22,.13)}
  else if(kind==='remove'){duck(.25);note(590,0,.14,.10,'triangle',294)}
  else if(kind==='page'){duck(.22);note(360,0,.07,.065,'triangle');note(470,.045,.12,.06,'triangle')}
  else if(kind==='appraise'){duck(.85);[392,494,587,784].forEach((f,i)=>note(f,i*.16,.20,.055,'triangle'))}
  else if(kind==='reveal'){
   // Even a common book gets a bright, positive discovery phrase.
   const tier=rarity===100?4:rarity>=98?3:rarity>=90?2:rarity>=71?1:0;silent=false;
   const tunes=[[523,659,784],[523,659,784,1047],[392,523,659,784,1047],[523,659,784,1047,1319,1568],[262,392,523,659,784,1047,1319,1568,2093]];
   const beat=tier===4?.11:.09,notes=tunes[tier],tail=tier>=2?.65:.36;duck(notes.length*beat+tail+.15);
   notes.forEach((f,i)=>{note(f,i*beat,tail,.13,'triangle');note(f*2,i*beat,.22,.035)});
   const final=(notes.length-1)*beat;[523,659,784].forEach(f=>note(f,final,.65,.045));
   if(tier>=3){[1568,2093,2637].forEach((f,i)=>note(f,final+.18+i*.09,.45,.05));note(131,0,.8,.10,'sine')}
  }else if(kind==='award'){duck(1.35);[392,523,659,784,1047,1319].forEach((f,i)=>note(f,i*.10,.5,.11,'triangle'));[262,330,392].forEach(f=>note(f,.45,.8,.05))}
 }
 function visibility(){if(document.hidden){player?.pause();stopEffects();ctx?.suspend().catch(()=>{})}else if(unlocked&&isEnabled()){sync()}}
 document.addEventListener('visibilitychange',visibility);
 return{unlock,sync,silence,resumeMusic,tap:()=>sound('tap'),select:()=>sound('select'),remove:()=>sound('remove'),page:()=>sound('page'),appraise:()=>sound('appraise'),reveal:r=>sound('reveal',r),award:()=>sound('award'),destroy(){document.removeEventListener('visibilitychange',visibility);clearTimeout(duckTimer);player?.pause();stopEffects();ctx?.close()}};
}
