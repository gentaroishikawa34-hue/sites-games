const toggle=document.querySelector('.toggle');
const nav=document.querySelector('#navigation');
function closeMenu(){toggle.setAttribute('aria-expanded','false');toggle.setAttribute('aria-label','メニューを開く');nav.classList.remove('open')}
toggle.addEventListener('click',()=>{const open=toggle.getAttribute('aria-expanded')!=='true';toggle.setAttribute('aria-expanded',String(open));toggle.setAttribute('aria-label',open?'メニューを閉じる':'メニューを開く');nav.classList.toggle('open',open)});
nav.addEventListener('click',e=>{if(e.target.closest('a'))closeMenu()});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&nav.classList.contains('open')){closeMenu();toggle.focus()}});
document.addEventListener('click',e=>{if(!e.target.closest('header'))closeMenu()});
window.matchMedia('(min-width:761px)').addEventListener('change',closeMenu);
const gallery=[['gallery-1.webp','モリネコの料理'],['gallery-2.webp','モリネコの店内'],['gallery-3.webp','季節のおいしいひと皿'],['gallery-4.webp','モリネコのスイーツ'],['gallery-5.webp','モリネコのコーヒー'],['gallery-6.webp','モリネコのフルーツデザート']];
for(const [file,alt] of gallery){const a=document.createElement('a');a.href='https://www.instagram.com/morineko_bistrante/';a.target='_blank';a.rel='noopener noreferrer';a.setAttribute('aria-label',alt+' — Instagramへ');const img=new Image();img.src='assets/'+file;img.alt=alt;img.loading='lazy';img.width=500;img.height=500;a.append(img);document.getElementById('gallery-grid').append(a)}
