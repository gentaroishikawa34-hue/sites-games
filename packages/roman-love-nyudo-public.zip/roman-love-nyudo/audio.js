// Original pentatonic score and synthesized effects. No external audio/API requests.
export class GameAudio {
  constructor(){this.ctx=null;this.bgm=true;this.se=true;this.mode='calm';this.step=0;this.timer=null;this.next=0;this.started=false;}
  unlock(){try{if(!this.ctx){this.ctx=new(window.AudioContext||window.webkitAudioContext)();this.music=this.ctx.createGain();this.fx=this.ctx.createGain();const limiter=this.ctx.createDynamicsCompressor();limiter.threshold.value=-15;limiter.ratio.value=8;this.music.connect(limiter);this.fx.connect(limiter);limiter.connect(this.ctx.destination);this.configure(this.bgm,this.se);}
    this.started=true;if(!document.hidden)Promise.resolve(this.ctx.resume()).then(()=>this.start()).catch(()=>{});
  }catch{}}
  configure(bgm,se){this.bgm=bgm;this.se=se;if(!this.ctx)return;this.music.gain.setTargetAtTime(bgm&&this.mode!=='draw'?.38:0,this.ctx.currentTime,.08);this.fx.gain.setTargetAtTime(se?.65:0,this.ctx.currentTime,.015);if(bgm&&this.started)this.start();else this.stop();}
  setMode(mode){if(this.mode===mode)return;this.mode=mode;this.step=0;this.next=(this.ctx?.currentTime||0)+.12;this.configure(this.bgm,this.se);}
  tone(freq,t,d,level,bus,type='sine',end){const c=this.ctx,o=c.createOscillator(),g=c.createGain();o.type=type;o.frequency.setValueAtTime(freq,t);if(end)o.frequency.exponentialRampToValueAtTime(end,t+d);g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(level,t+.012);g.gain.exponentialRampToValueAtTime(.0001,t+d);o.connect(g);g.connect(bus);o.onended=()=>{o.disconnect();g.disconnect();};o.start(t);o.stop(t+d+.03);}
  pluck(f,t,v=.13){this.tone(f,t,1.2,v,this.music,'triangle');this.tone(f*2,t,.35,v*.22,this.music);}
  start(){if(this.timer||!this.bgm||document.hidden||this.ctx?.state!=='running')return;this.next=Math.max(this.next,this.ctx.currentTime+.05);this.tick();this.timer=setInterval(()=>this.tick(),100);}
  stop(){clearInterval(this.timer);this.timer=null;}
  tick(){if(this.ctx.state!=='running')return;const c=this.ctx;if(this.next<c.currentTime)this.next=c.currentTime+.05;while(this.next<c.currentTime+.25){if(this.mode!=='draw')this.beat(this.step++,this.next);this.next+=this.mode==='romance'?.42:.38;}}
  beat(n,t){const calm=[62,69,72,74,77,74,72,69,62,65,69,72,69,65,62,null,60,65,69,72,74,72,69,65,62,69,72,69,65,62,null,null];const love=[62,66,69,73,74,73,69,66,59,66,69,73,76,73,69,66,55,62,66,69,74,69,66,62,57,64,69,73,76,73,69,null];const notes=this.mode==='romance'?love:calm;const note=notes[n%notes.length];const hz=m=>440*2**((m-69)/12);if(note!==null)this.pluck(hz(note),t,this.mode==='story'?.105:.13);if(n%8===0){const bass=[38,36,41,38][Math.floor(n/8)%4];this.tone(hz(bass),t,2.5,.12,this.music);this.tone(hz(bass+7),t,2,.045,this.music);}if(n%4===0&&this.mode!=='romance')this.tone(150,t,.19,.06,this.music,'sine',48);}
  effect(name){if(!this.ctx||!this.se||document.hidden||this.ctx.state!=='running')return;const t=this.ctx.currentTime,play=(f,delay,d=.4,v=.15,type='sine',end)=>this.tone(f,t+delay,d,v,this.fx,type,end);
    if(name==='tap'){play(760,0,.07,.08);play(1140,.04,.08,.04);}
    if(name==='choice'){play(180,0,.25,.25,'sine',50);play(620,.04,.16,.09);}
    if(name==='bell')[110,221,309,457,603].forEach((f,i)=>play(f,0,3.5,.24/(i+1)));
    if(name==='rise')[220,294,440,587,880].forEach((f,i)=>play(f,i*.12,.6,.1));
    if(name==='burst'){play(100,0,.7,.28,'sine',28);[220,277,330,440,554,660].forEach((f,i)=>play(f,i*.055,1.4,.10));}
    if(name==='clear')[523,784,1047].forEach((f,i)=>play(f,i*.16,1.3,.13));
    if(name==='desire')[440,392,311,196].forEach((f,i)=>play(f,i*.17,.25,.13,'triangle'));
    if(name==='reward')[523,659,784,1047,1319].forEach((f,i)=>play(f,i*.12,1.2,.14));
  }
  hide(){this.stop();if(this.ctx)Promise.resolve(this.ctx.suspend()).catch(()=>{});}
  visible(){if(this.started)this.unlock();}
}
