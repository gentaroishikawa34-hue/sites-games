import {CONFIG} from './config.js';
export const STACK_POINTS=[0,100,220,360,520,750,1050,1400,1850,2400,3000];
export const multiplier=combo=>[1,1,1.2,1.5,1.8,2][Math.min(5,Math.max(0,combo))];
export function scoreBurger(stack,combo){
 if(!stack.length||stack.length>10)return {total:0,combos:[],base:0,multiplier:1};
 const counts={};for(const f of stack)counts[f.id]=(counts[f.id]||0)+1;
 const combos=CONFIG.combos.filter(c=>(!c.min||stack.length>=c.min)&&(!c.requires||Object.entries(c.requires).every(([id,n])=>(counts[id]||0)>=n)));
 const base=STACK_POINTS[stack.length]+stack.reduce((a,f)=>a+f.points,0);
 return {base,combos,multiplier:multiplier(combo),total:Math.round((base+combos.reduce((a,c)=>a+c.bonus,0))*multiplier(combo))};
}
export const rewardFor=score=>CONFIG.rewards.filter(r=>score>=r.score).at(-1);
export const isGameOver=loss=>loss>10;
export const titleFor=score=>score>=20000?'BURGER LEGEND':score>=10000?'バーガーマスター':score>=5000?'バーガー職人':'見習いバーガー職人';
