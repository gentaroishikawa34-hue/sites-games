export const CONFIG = {
 title:'BURGER STACK！', store:'FRANKLIN DINER', logo:'franklin-logo.jpg', characters:'franklin-characters.jpg', background:'', bgm:'',
 storeUrl:'', inquiryUrl:'', promotional:true,
 rewards:[{score:3000,name:'ステッカー',icon:'★'},{score:8000,name:'缶バッジ',icon:'●'},{score:15000,name:'アクリルキーホルダー',icon:'✦'}],
 coupon:{enabled:false,score:10000,label:'ポテト50円OFF'},
 sample:true,
 levels:[{at:0,speed:1,interval:2.1},{at:25,speed:1.3,interval:1.8},{at:50,speed:1.65,interval:1.5},{at:80,speed:2.1,interval:1.25},{at:110,speed:2.65,interval:1.05}],
 ingredients:[
 {id:'patty',name:'ビーフパティ',sprite:2,points:150,speed:1.28,weight:13},
 {id:'cheese',name:'チーズ',sprite:3,points:70,speed:.85,weight:16},
 {id:'lettuce',name:'レタス',sprite:4,points:50,speed:.68,weight:16},
 {id:'tomato',name:'トマト',sprite:5,points:70,speed:1,weight:13},
 {id:'bacon',name:'ベーコン',sprite:6,points:120,speed:1.15,weight:10},
 {id:'onion',name:'オニオン',sprite:7,points:80,speed:1,weight:12},
 {id:'egg',name:'目玉焼き',sprite:8,points:100,speed:1,weight:10},
 {id:'avocado',name:'アボカド',sprite:9,points:250,speed:.82,weight:3},
 {id:'hash',name:'ハッシュポテト',sprite:10,points:180,speed:1.5,weight:7}],
 combos:[
 {name:'CHEESE BURGER',requires:{patty:1,cheese:1},bonus:300},
 {name:'DOUBLE MEAT',requires:{patty:2},bonus:400},
 {name:'BACON EGG',requires:{bacon:1,egg:1},bonus:350},
 {name:'VEGGIE BURGER',requires:{lettuce:1,tomato:1,onion:1,avocado:1},bonus:700},
 {name:'DOUBLE CHEESE',requires:{cheese:2},bonus:300},
 {name:'MEGA BURGER',min:8,bonus:600},
 {name:'PERFECT STACK',min:10,bonus:1800}]
};
