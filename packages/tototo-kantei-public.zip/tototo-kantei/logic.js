export const mod=(n,m)=>((n%m)+m)%m;
export function getJDN(year,month,day){const a=Math.floor((14-month)/12),y=year+4800-a,m=month+12*a-3;return day+Math.floor((153*m+2)/5)+365*y+Math.floor(y/4)-Math.floor(y/100)+Math.floor(y/400)-32045;}
export const getYearCode=year=>mod(mod(getJDN(year,1,1)+49,10)-1,10);
export const isLeapYear=year=>year%400===0||(year%4===0&&year%100!==0);
export const getMonthCode=(year,month)=>[0,0,1,9,0,0,1,1,2,3,3,4,4][month]+(isLeapYear(year)&&month>=3?1:0);
export function validDate(y,m,d){if(![y,m,d].every(Number.isInteger)||y<1900||y>new Date().getFullYear()||m<1||m>12||d<1)return false;const max=[31,isLeapYear(y)?29:28,31,30,31,30,31,31,30,31,30,31][m-1];if(d>max)return false;const now=new Date();return y<now.getFullYear()||m<now.getMonth()+1||(m===now.getMonth()+1&&d<=now.getDate());}
export function calculate(year,month,day){if(!validDate(year,month,day))throw new Error('実在する、今日以前の生年月日を選んでください。');const yearCode=getYearCode(year),monthCode=getMonthCode(year,month),total=yearCode+monthCode+day;return{year,month,day,yearCode,monthCode,total,characterIndex:mod(total,10),branchIndex:mod(getJDN(year,month,day)+49,12)};}
