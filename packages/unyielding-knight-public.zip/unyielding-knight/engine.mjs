import {EVENTS,KINGDOM,AFTER,ARRIVAL,ALL_EVENTS,ACTIONS,outcomeFor} from './events.mjs';
export const clamp=v=>Math.max(0,Math.min(100,v));
export const findEvent=id=>ALL_EVENTS.find(e=>e.id===id)||ARRIVAL;
export const ENDINGS={
escape:{title:'城を去る騎士',label:'脱走 END',summary:'命令の届かない朝。彼女は、誰にも告げずに自分の道を選んだ。'},
release:{title:'開かれた扉',label:'解放 END',summary:'自由を与えた日、彼女は城を去った。その一歩を、魔王は止めなかった。'},
love:{title:'別々の道、同じ想い',label:'恋慕 END',summary:'想いと忠誠は、同じではない。彼女は魔王を想いながら、自分の道を歩んでゆく。'},
reunion:{title:'もう一度、あの扉へ',label:'再会 END',summary:'一度城を去った彼女は、命令ではなく、自分の足で帰ってきた。'},
obedient:{title:'最後の命令',label:'従属 END',summary:'完璧に命令を受け入れた騎士は、解放の言葉にも従った。残された食卓に、笑顔の記憶はなかった。'},
true:{title:'不屈の騎士',label:'TRUE END',summary:'彼女は誰にも屈しなかった。祖国にも、魔王にも。だからこそ、自らの意志で主を選んだ。'}
};
export function newGame(){
return {v:1,day:1,o:44,a:4,phase:'intro',introStep:0,current:ARRIVAL.id,pool:[],seen:[],history:[],commands:[],counts:[0,0,0,0,0],streak:0,last:-1,kingdom:0,flags:{care:0,agency:0,shared:0,truth:0,identity:0,justice:0,refuge:0,experience:0,protection:0},result:null,end:null,endStep:0,pendingEscape:false};
}
function shuffle(items,random){const a=[...items];for(let i=a.length-1;i>0;i--){const j=Math.floor(random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;}
export function beginDay(s,random=Math.random){
s.phase='event';s.result=null;s.pendingEscape=false;
if(s.day===1)s.current=ARRIVAL.id;
else if(s.day%5===0){
const i=s.day/5-1;s.current=i<KINGDOM.length?KINGDOM[i].id:AFTER[(i-KINGDOM.length)%AFTER.length].id;
}else{
if(!s.pool.length)s.pool=shuffle(EVENTS.map(e=>e.id),random);
// Avoid intimate or jealous scenes before an acquaintance has actually formed.
let i=s.pool.findIndex(id=>{const e=findEvent(id);return !(s.a<25&&(e.profile==='intimate'||['別の女性','呼び方','離れた椅子'].includes(e.title)));});
if(i<0){s.pool=shuffle(EVENTS.map(e=>e.id),random);i=s.pool.findIndex(id=>findEvent(id).profile!=='intimate');}
s.current=s.pool.splice(i,1)[0];
}
if(!s.seen.includes(s.current))s.seen.push(s.current);
return s;
}
export function finishIntro(s,random=Math.random){if(s.phase!=='intro')throw Error('序章は終了しています。');return beginDay(s,random);}
export function decay(o){return o<=30?0:o<=60?1:o<=80?2:3;}
export function naturalGrowth(a){return a<30?.28:a<60?.14:a<80?.045:0;}
const suffixes=[
['……貴様の考えが、私の考えになったわけではない。','恐れることと、信じることは違う。','借りは、覚えておく。それだけだ。','聞かれたから、答えた。勘違いするな。','私の腕まで、奪われたわけではない。'],
['ご命令は承りました。我が主。','その御力には、従わざるを得ません。','お気遣い、感謝いたします。我が主。','お尋ねには、答えます。……それが役目ですから。','お任せいただいた務めは、果たします。'],
['……心配してくれたのか？　だが、私の意志も聞いてくれ。','お前の強さは知っている。だからこそ、無理をするな。','ありがとう。……だからといって、何でも言うことを聞くと思うな。','好きだ。……それでも、私の答えは自分で決める。','お前が信じてくれるなら、私は私のやり方で応える。'],
['ご命令を、我が主。……命令がなくても、お傍にはおりますが。','あなたが皆を守るなら、私はあなたの背を守る。','……あなたが傍にいてくれるなら、少し休めそうです。','あなたと話す時間を、私も待っていた。','あなたの騎士として。……そして、私自身として。任されよう。']
];
export function quadrant(s){return (s.a>=60?2:0)+(s.o>=65?1:0);}
const nightLines=[
['……明日も、私は私だ。','この城の静けさには、まだ慣れない。','祖国の皆は……無事なのだろうか。','眠るだけだ。見張る必要はない。','窓の向こうに、道がある。'],
['明日の務めも、承りました。','命令は果たした。……それでよいのだろう。','この城の規律は、理解した。','我が主。お先に、失礼いたします。','剣は磨いた。次の命を待つ。'],
['……まだ起きているのか。少し、付き合え。','好きにする。……今夜は、ここにいたい。','お前も、ちゃんと休め。これは私の意見だ。','帰る場所を、一つしか持ってはいけないのか。','……明日、また話そう。約束だ。'],
['おやすみなさい。我が主。……いい夢を。','明日の朝も、同じ席を空けておいてくれ。','あなたが眠るまで、もう少しここにいよう。','今日は、よい日だった。……あなたにも、そうならよい。','命令ではなく、私がここにいたい。それだけだ。']
];
export function warning(s){
if(s.o<=20)return '夜が明ける前に、彼女の足音が廊下を遠ざかってゆく。';
if(s.o<=22)return '「……魔王。もし私がいなくなったら、お前はどうする？」';
if(s.o<=25)return '部屋から、彼女の私物が少しずつなくなっている。';
if(s.o<=30)return '最近、彼女は城の出口を長く眺めている。';
return '';
}
export function choose(s,index){
if(s.phase!=='event'||!Number.isInteger(index)||index<0||index>4)throw Error('いま選べる行動ではありません。');
const e=findEvent(s.current),r=outcomeFor(e,index);
s.streak=s.last===index?s.streak+1:1;s.last=index;s.counts[index]++;
s.commands.push(index);if(s.commands.length>256)s.commands.shift();
const factor=[1,1,.75,.5][s.streak]??.25;
// In emergencies, repeating effective protection or nursing remains sensible.
const sensible=r.a>=5&&((e.profile==='battle'&&index===1)||(e.profile==='illness'&&[0,2].includes(index))||(e.profile==='wound'&&index===2));
const scale=sensible?Math.max(.75,factor):factor;
let gain=Math.round(r.o>0?r.o*scale:r.o);
let intimacy=r.a>0?r.a*scale:r.a;
if(s.streak>=3&&!sensible){intimacy-=2;}
const before=s.o;
const commanded=clamp(s.o+gain);const loss=decay(commanded);
s.o=clamp(commanded-loss);s.a=clamp(s.a+intimacy+naturalGrowth(s.a));
if(r.a>=3&&scale>=.5)for(const f of r.marks)s.flags[f]=(s.flags[f]||0)+1;
if(e.kingdom)s.kingdom=Math.max(s.kingdom,e.kingdom);
const q=quadrant(s);
let reply=r.reply;
if(r.a>=0)reply+='\n'+suffixes[q][index];
if(s.streak>=3&&!sensible)reply+='\n'+(index===2?'私は姫ではない。騎士だ。……最近、そればかりだな。':'……最近、そればかりだな。私の話も、聞いているか。');
let night=nightLines[q][s.day%5];
if(s.o<=30)night=warning(s);
s.result={action:index,text:r.text,reply,gain:Math.round(commanded-before),loss,delta:s.o-before,night,expression:resultExpression(s,e,r,index)};
s.history.push({day:s.day,event:e.id,action:index,text:r.text,reply,night,expression:s.result.expression});
if(s.history.length>256)s.history.shift();
s.pendingEscape=s.o<=20;s.phase='result';
return s.result;
}
function resultExpression(s,e,r,index){
if(r.a<0)return e.profile==='memory'?3:e.profile==='illness'?13:1;
if(['battle','pride'].includes(e.profile)&&s.a<60)return 4;
if(e.cat==='祖国'&&e.kingdom>=4&&e.kingdom<=6&&s.a<65)return 11;
if(e.profile==='wound'||e.profile==='illness')return s.a>=60?14:7;
if(e.title==='別の女性'&&s.a>=40)return 12;
if(s.a>=80)return s.o>=65?(index===0?19:index===4?18:8):(index===3?17:9);
if(s.a>=60)return index===3?5:index===4?8:7;
if(s.a>=30)return index===3?17:7;
return s.o>=65?4:index===4?4:2;
}
export function presentation(s){
const e=findEvent(s.current);
let expression=e.expression,quote=e.quote;
if(e.title==='別の女性'){expression=s.a>=40?12:2;quote=s.a>=40?e.quote:'魔族の将軍か。どの部隊を率いている？';}
if(e.profile==='intimate'&&s.a>=60){expression=s.a>=80?14:5;quote+='\n'+(s.o>=65?'……我が主。今だけは、隣にいてもよいか。':'……一緒にいたいのは、私がそう決めたからだ。');}
if(e.title==='魔王の負傷'&&s.a<30)quote='魔王にも血は流れるのだな。……城医を呼ぶ。';
if(e.title==='魔王の負傷'&&s.a>=70){quote='何をしている！　なぜ、黙っていた！\n……お願いだ。私の前で、平気な顔をするな。';expression=6;}
if(e.title==='呼び方'&&s.a>=60)quote=s.o>=65?'我が主。……あなたを、そう呼んでもよいか。':'お前の名前を、教えてくれないか。魔王としてではなく。';
if(e.cat==='祖国')return {e,expression,quote};
if(s.a<20&&['food','routine'].includes(e.profile))expression=s.day%2?0:2;
return {e,expression,quote};
}
export function nextDay(s,random=Math.random){
if(s.phase!=='result')throw Error('先に、今日の行動を選んでください。');
if(s.pendingEscape)return finish(s,'escape');
s.day++;return beginDay(s,random);
}
export function endingFor(s){
if(s.o<=20)return 'escape';
const f=s.flags,variety=s.counts.filter(n=>n>0).length,total=s.counts.reduce((a,b)=>a+b,0);
const balanced=total>0&&Math.max(...s.counts)/total<.65;
if(s.a>=72&&s.o>=55&&s.kingdom>=6&&f.agency>=5&&f.care>=3&&f.shared>=3&&f.experience>=2&&f.truth>=2&&f.identity>=1&&(f.justice>=2||f.refuge>=1)&&variety>=4&&balanced)return 'true';
if(s.o>=85&&s.a<32)return 'obedient';
if(s.a>=58&&s.o>=50&&s.kingdom>=3&&f.agency>=2&&f.shared>=2&&variety>=3)return 'reunion';
if(s.a>=55&&(f.shared>=2||f.agency>=2))return 'love';
return 'release';
}
export function finish(s,id=endingFor(s)){
s.end=id;s.phase='ending';s.endStep=0;s.pendingEscape=false;return s;
}
export function release(s){
if(!['event','result'].includes(s.phase)||s.pendingEscape)throw Error('いま解放を告げることはできません。');
return finish(s);
}
const scene=(speaker,text,expression=16)=>({speaker,text,expression});
export function endingScenes(s){
const common=[scene('魔王','お前は自由だ。',4)];
switch(s.end){
case 'true':return [...common,
scene('女騎士','…………。',6),
scene('','彼女は出口へ向かう。\n扉を開く。外の光を見る。\n長い間、沈黙。',16),
scene('','そして――\n扉を閉める。',4),
scene('','魔王のもとへ戻り、剣を抜く。\nその剣を魔王の前へ置き、跪く。',19),
scene('女騎士','我が主。',19),
scene('魔王','もう命令はしないと言ったはずだ。',4),
scene('女騎士','はい。\nですから――これは命令ではありません。\n私の意志です。',19),
scene('女騎士','私は誰にも屈しない。\n祖国にも。\nあなたにも。',4),
scene('','彼女は魔王を真っ直ぐに見つめる。\nそして、微笑む。',8),
scene('女騎士','だからこそ。\n私自身が、あなたを主と決めました。',8),
scene('女騎士','もう一度――\n私を、あなたの騎士にしてください。',19)];
case 'obedient':return [...common,
scene('女騎士','……承知しました。',4),
scene('','彼女は、いつものように一礼した。\n笑顔はない。',4),
scene('女騎士','今まで、お世話になりました。',4),
scene('','命令どおりに去ってゆく背中。\nその最後の命令だけは、取り消せなかった。',16)];
case 'love':return [...common,
scene('女騎士','……そうか。\nならば、私も正直に言う。',5),
scene('女騎士','好きだ。\nお前のことを、私は好きになってしまった。',17),
scene('女騎士','それでも、誰かに仕える道は選べない。\n私は、私の剣の行き先を探す。',4),
scene('','城を離れた騎士は、旅の夜に時折あの窓を思う。\n想いは、命令より遠くまで届いた。',16)];
case 'reunion':return [...common,
scene('女騎士','一度、外へ出てみたい。\n私が誰なのか、私自身で確かめたい。',4),
scene('魔王','行け。帰ることも、帰らぬことも、お前が決めろ。',4),
scene('','季節が、ひとつ巡った。\nある夕暮れ、城の扉が叩かれる。',16),
scene('女騎士','……久しぶりだな。\n招かれてはいないが、顔を見たくなった。',8),
scene('女騎士','今日は客だ。\n明日のことは、明日決める。',9),
scene('','二人分の茶を、同じ食卓に置く。\n今度の再会には、鎖も命令もなかった。',8)];
case 'escape':{
const q=s.a<20?0:s.a<40?1:s.a<60?2:s.a<80?3:4;
return [scene('','翌朝、女騎士の部屋は空になっていた。\n机に、一通の手紙だけが残されている。',16),
scene('女騎士',[
'二度と私の前に現れるな、魔王。',
'……世話になったことだけは、礼を言う。',
'あなたを嫌いになれたら……\nもっと簡単だったのにな。',
'……追ってきてくれたら、\n私はどうするのだろうな。',
'好きだよ。\n……それでも私は、自分の道を選ぶ。'][q],q>=3?5:4),
scene('',[
'彼女は、一度も振り返らなかった。',
'丘を越える前に、一度だけ城を振り返る。',
'迷いを抱えながらも、彼女は歩みを止めなかった。',
'城を長く見つめ、それでも彼女は道を進んだ。',
'愛していることと、従うことは同じではない。\n彼女はその両方を、自分の意志で決めた。'][q],16)];
}
default:return [...common,
scene('女騎士','……本当に、よいのか。',6),
scene('魔王','剣も、帰る道も、お前のものだ。',4),
scene('女騎士',s.a>=25?'世話になったな。\nここで知ったことは、忘れない。':'私は、私の道を行く。\n……これで、ようやく決められる。',4),
scene('','扉の向こうには、まだ知らない道がある。\n彼女はまっすぐに歩き出した。',16)];
}
}
export const PROLOGUE=[
{title:'討伐の果て',text:'王国から送り込まれた、成人の女騎士。\nその剣は、魔王には届かなかった。\n\nそれでも、彼女の眼差しは折れていない。'},
{title:'魔王城にて',text:'「殺せ。だが私は、貴様には従わない」\n\n魔王は彼女を生かし、城に部屋を与えた。\n剣も誇りも、失わせぬままに。'},
{title:'あなたが選ぶ言葉',text:'一日につき、行動はひとつ。\n彼女の言葉と表情を見て、接し方を選ぶ。\n\nいつか「お前は自由だ」と告げるまで、\n二人の日々は続いてゆく。'}
];
export function validSave(s){
return !!s&&s.v===1&&Number.isInteger(s.day)&&s.day>=1&&Number.isFinite(s.o)&&s.o>=0&&s.o<=100&&Number.isFinite(s.a)&&s.a>=0&&s.a<=100&&['intro','event','result','ending'].includes(s.phase)&&ALL_EVENTS.some(e=>e.id===s.current)&&Array.isArray(s.pool)&&Array.isArray(s.seen)&&Array.isArray(s.history)&&Array.isArray(s.commands)&&Array.isArray(s.counts)&&s.counts.length===5&&s.counts.every(n=>Number.isFinite(n)&&n>=0)&&s.flags&&Object.values(s.flags).every(n=>Number.isFinite(n)&&n>=0)&&(s.phase!=='result'||s.result&&typeof s.result.reply==='string')&&(s.phase!=='ending'||!!ENDINGS[s.end]);
}
