// Original, procedural chamber score. No external audio dependencies.
const scores={
castle:{root:146.83,steps:[0,7,12,3,7,10,7,3],tempo:720,wave:'triangle'},
daily:{root:174.61,steps:[0,4,7,12,7,4,9,7],tempo:610,wave:'sine'},
tension:{root:130.81,steps:[0,1,7,1,0,6,7,1],tempo:410,wave:'triangle'},
battle:{root:146.83,steps:[0,0,7,10,0,3,7,12],tempo:270,wave:'triangle'},
homeland:{root:164.81,steps:[0,7,3,10,7,3,2,0],tempo:800,wave:'sine'},
sorrow:{root:130.81,steps:[0,3,7,10,7,3,2,0],tempo:1050,wave:'sine'},
intimate:{root:196,steps:[0,4,7,11,12,7,4,2],tempo:880,wave:'sine'},
ending:{root:174.61,steps:[0,7,12,16,12,7,9,4],tempo:920,wave:'sine'}
};
export class Sound{
constructor(enabled=true,volume=.28){this.enabled=enabled;this.volume=volume;this.mode='castle';this.tick=0;this.timer=null;this.ctx=null;}
async unlock(){
if(!this.enabled)return;
try{if(!this.ctx){this.ctx=new (window.AudioContext||window.webkitAudioContext)();this.master=this.ctx.createGain();this.master.gain.value=this.volume;this.master.connect(this.ctx.destination);}
if(this.ctx.state==='suspended')await this.ctx.resume();this.start();}catch{}
}
tone(freq,duration=.8,level=.08,wave='sine',delay=0){
if(!this.ctx||!this.enabled||this.ctx.state!=='running')return;
const t=this.ctx.currentTime+delay,o=this.ctx.createOscillator(),g=this.ctx.createGain();
o.type=wave;o.frequency.setValueAtTime(freq,t);
g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(Math.max(.0002,level),t+.035);g.gain.exponentialRampToValueAtTime(.0001,t+duration);
o.connect(g);g.connect(this.master);o.start(t);o.stop(t+duration+.05);
}
noise(duration=.25,level=.06,low=2500){
if(!this.ctx||!this.enabled)return;
const n=Math.ceil(this.ctx.sampleRate*duration),buffer=this.ctx.createBuffer(1,n,this.ctx.sampleRate),v=buffer.getChannelData(0);for(let i=0;i<n;i++)v[i]=(Math.random()*2-1)*(1-i/n);
const s=this.ctx.createBufferSource(),g=this.ctx.createGain(),f=this.ctx.createBiquadFilter();s.buffer=buffer;f.type='lowpass';f.frequency.value=low;g.gain.value=level;s.connect(f);f.connect(g);g.connect(this.master);s.start();
}
start(){if(this.timer||!this.enabled||!this.ctx)return;this.pulse();const recur=()=>{if(!this.enabled)return;this.pulse();this.timer=setTimeout(recur,scores[this.mode].tempo);};this.timer=setTimeout(recur,scores[this.mode].tempo);}
pulse(){
if(document.hidden)return;
const sc=scores[this.mode],step=sc.steps[this.tick%sc.steps.length];
this.tone(sc.root*2**(step/12),sc.tempo/1000*2.8,.036,sc.wave);
if(this.tick%4===0){this.tone(sc.root/2,3.2,.04,'sine');this.tone(sc.root*2**(7/12),2.6,.014,'sine');}
if(this.mode==='battle'&&this.tick%2===0)this.noise(.1,.025,400);
this.tick++;
}
setMode(mode){this.mode=scores[mode]?mode:'castle';}
setEnabled(on){this.enabled=on;if(!on){clearTimeout(this.timer);this.timer=null;if(this.master)this.master.gain.setTargetAtTime(0,this.ctx.currentTime,.08);}else{if(this.master)this.master.gain.setTargetAtTime(this.volume,this.ctx.currentTime,.08);void this.unlock();}}
setVolume(v){this.volume=v;if(this.master)this.master.gain.setTargetAtTime(this.enabled?v:0,this.ctx.currentTime,.05);}
fx(type){
if(!this.enabled)return;
switch(type){
case 'up':this.tone(392,.32,.08,'triangle');this.tone(523.25,.48,.06,'sine',.1);break;
case 'down':this.tone(220,.35,.06,'triangle');this.tone(174.61,.5,.045,'sine',.12);break;
case 'sword':this.noise(.25,.12,7000);this.tone(1760,.2,.04,'triangle');break;
case 'armor':this.noise(.14,.055,4800);this.tone(660,.18,.04,'triangle');break;
case 'door':this.noise(.45,.09,350);this.tone(80,.28,.09,'triangle');break;
case 'steps':this.noise(.09,.06,900);setTimeout(()=>this.noise(.1,.06,800),220);break;
case 'fire':this.noise(.55,.05,1800);break;
case 'magic':[220,440,660,880].forEach((f,i)=>this.tone(f,.6,.05,'sine',i*.07));break;
case 'rain':this.noise(1.2,.035,5500);break;
case 'thunder':this.noise(1.2,.12,250);break;
default:this.tone(294,.12,.025,'sine');
}
}
}
