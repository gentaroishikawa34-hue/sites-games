import {ACTIONS,EXPRESSIONS,EVENTS,ALL_EVENTS} from './events.mjs';
import {newGame,beginDay,finishIntro,choose,nextDay,release,presentation,warning,findEvent,ENDINGS,endingScenes,PROLOGUE,validSave} from './engine.mjs';
import {Sound} from './audio.mjs';
const $=s=>document.querySelector(s),app=$('#app'),modal=$('#modal'),SAVE='invictus-save-v1',COLLECTION='invictus-collection-v1',SETTINGS='invictus-settings-v1';
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function read(key,fallback){try{return JSON.parse(localStorage.getItem(key))??fallback;}catch{return fallback;}}
let state=read(SAVE,null);if(!validSave(state))state=null;
let collection=read(COLLECTION,{seen:[],memories:{},endings:{}});if(!collection||!Array.isArray(collection.seen)||!collection.memories||!collection.endings)collection={seen:[],memories:{},endings:{}};
let settings=read(SETTINGS,{sound:true,volume:.28});if(!settings||typeof settings.sound!=='boolean'||!Number.isFinite(settings.volume))settings={sound:true,volume:.28};
settings.volume=Math.max(0,Math.min(.7,settings.volume));
const sound=new Sound(settings.sound,settings.volume);
let view='title',saveOK=true,modalType='',archiveTab='events',busy=false;
const paths={
sword:'<path d="m18 3 3 3-11 11-3-3L18 3Z"/><path d="m4 14 6 6M7 17l-4 4M3 19l2 2"/>',
crown:'<path d="m3 7 4 4 5-7 5 7 4-4-2 13H5L3 7Z"/><path d="M6 16h12"/>',
flame:'<path d="M12 3c2 5 7 6 7 11a7 7 0 0 1-14 0c0-3 2-5 4-7 0 4 2 5 3 6 2-3 2-6 0-10Z"/>',
cup:'<path d="M5 3h14v5a7 7 0 0 1-14 0V3ZM12 15v6M7 21h10"/>',
talk:'<path d="M21 11a8 8 0 0 1-8 8H8l-5 3 2-6a8 8 0 1 1 16-5Z"/><path d="M7 10h10M7 14h7"/>',
hand:'<path d="M5 12V8a2 2 0 0 1 4 0V4a2 2 0 0 1 4 0v1a2 2 0 0 1 4 0v3a2 2 0 0 1 4 0v6c0 5-3 8-7 8-3 0-5-2-7-4l-4-4a2 2 0 0 1 2-3l4 3"/>',
book:'<path d="M12 5v16M3 4c4-1 6 0 9 1 3-1 5-2 9-1v15c-4-1-6 0-9 1-3-1-5-2-9-1V4Z"/>',
sound:'<path d="m3 10 5 0 5-5v14l-5-5H3v-4Z"/><path d="M17 8a6 6 0 0 1 0 8M20 5a10 10 0 0 1 0 14"/>',
mute:'<path d="m3 10 5 0 5-5v14l-5-5H3v-4Z"/><path d="m17 9 5 6m0-6-5 6"/>',
menu:'<path d="M4 6h16M4 12h16M4 18h16"/>',
door:'<path d="M4 21V3h13v18M10 3l11 3v13l-11 2V3ZM14 12h1"/>'
};
const icon=id=>'<svg viewBox="0 0 24 24" aria-hidden="true">'+paths[id]+'</svg>';
function topbar(){return '<header class="topbar"><button class="brand" data-do="title" aria-label="タイトルに戻る">'+icon('sword')+'<span>不屈の騎士<small>THE UNYIELDING KNIGHT</small></span></button><nav class="tools" aria-label="ゲームメニュー"><button class="icon-button" data-do="archive">'+icon('book')+'<span class="tool-label">回想録</span></button><button class="icon-button" data-do="audio" aria-label="音の設定">'+icon(settings.sound?'sound':'mute')+'</button><button class="icon-button" data-do="menu" aria-label="メニュー">'+icon('menu')+'</button></nav></header>';}
function toast(text){const e=$('#toast');e.textContent=text;e.classList.add('visible');clearTimeout(toast.timer);toast.timer=setTimeout(()=>e.classList.remove('visible'),3500);}
function write(key,val){try{localStorage.setItem(key,JSON.stringify(val));return true;}catch{return false;}}
function persist(){
if(!state)return;
saveOK=write(SAVE,state);
for(const id of state.seen)if(!collection.seen.includes(id))collection.seen.push(id);
if(state.phase==='result'&&state.history.length){const m=state.history.at(-1),list=collection.memories[m.event]||[];if(!list.some(x=>x.day===m.day&&x.action===m.action&&x.reply===m.reply))list.push({...m});collection.memories[m.event]=list.slice(-5);}
if(state.phase==='ending'){const old=collection.endings[state.end];if(!old)collection.endings[state.end]={day:state.day,scenes:endingScenes(state)};}
if(!write(COLLECTION,collection))saveOK=false;
}
function changeView(v){view=v;render();window.scrollTo({top:0,behavior:'instant'});}
function title(){
sound.setMode('castle');
app.innerHTML='<main class="start">'+topbar()+'<div class="start-art" aria-hidden="true"></div><section class="start-content fade-in"><div class="eyebrow">DARK FANTASY · PSYCHOLOGICAL ADV</div><div class="rule"></div><h1>不屈の騎士</h1><p class="catch">「私は、絶対に屈しない。」</p><p class="intro-copy">命令には従う。心まで従うとは限らない。<br>彼女に自由を与えたとき、<br>あなたは初めて、その答えを知る。</p><div class="start-actions"><button class="primary" data-do="new">最初から</button><button class="secondary" data-do="continue" '+(!state?'disabled':'')+'>続きから'+(state?'<span style="display:block;font-size:12px;letter-spacing:.05em">DAY '+state.day+'</span>':'')+'</button></div><div class="start-aux"><button class="text-button" data-do="guide">遊び方</button><button class="text-button" data-do="archive">回想録・結末</button></div></section><p class="start-footer">その忠誠は、誰の意志か。</p></main>';
}
function intro(){
const p=PROLOGUE[state.introStep]||PROLOGUE[0];sound.setMode('tension');
app.innerHTML='<main class="prologue"><section class="prologue-box fade-in"><p class="eyebrow">PROLOGUE '+(state.introStep+1)+' / '+PROLOGUE.length+'</p><h2>'+esc(p.title)+'</h2><p>'+esc(p.text)+'</p><button class="primary" data-do="intro-next">'+(state.introStep===2?'城での日々を始める':'物語を進める')+'</button><button class="text-button skip" data-do="intro-skip">序章をスキップ</button></section></main>';
}
function sprite(expr){return '<div class="portrait-sprite" style="--col:'+expr%5+';--row:'+Math.floor(expr/5)+'"><img src="assets/expressions.jpeg" alt="女騎士の表情：'+esc(EXPRESSIONS[expr])+'" draggable="false"></div>';}
function sceneEffect(e){if(e.profile==='battle')sound.fx('sword');else if(e.topic.includes('雷'))sound.fx('thunder');else if(e.topic.includes('雨'))sound.fx('rain');else if(e.topic.includes('火'))sound.fx('fire');}
function game(){
const p=presentation(state),e=p.e,isResult=state.phase==='result',r=state.result,expr=isResult?r.expression:p.expression,warn=warning(state);
sound.setMode(e.sound);
const commandIcons=['crown','flame','cup','talk','hand'],notes=['務めを与える','威厳を見せる','心身を気遣う','言葉を交わす','判断を託す'];
const actions=isResult?'<div class="result-change '+(r.delta<0?'down':'')+'">服従度 '+(r.delta>=0?'+':'')+r.delta+' <span class="text-muted">（行動 '+(r.gain>=0?'+':'')+r.gain+' ／ 時間経過 −'+r.loss+'）</span></div><div class="night"><span class="speaker">夜、静かな城で</span><br>'+esc(r.night)+'</div><button class="primary next-day" data-do="next">翌朝へ</button>':'<p class="action-prompt">魔王として、どう接する？</p><div class="actions">'+ACTIONS.map((a,i)=>'<button class="action" data-do="choose" data-action="'+i+'">'+icon(commandIcons[i])+'<strong>'+a+'</strong><small>'+notes[i]+'</small></button>').join('')+'<div class="action-six" aria-hidden="true">✧</div></div>';
app.innerHTML='<main class="game">'+topbar()+'<div class="game-layout"><section class="scene fade-in" aria-label="女騎士"><div class="scene-bg"></div><div class="scene-day"><span>IN THE DEMON KING’S CASTLE</span><strong>DAY '+String(state.day).padStart(2,'0')+'</strong></div><div class="scene-weather">'+(e.cat==='祖国'?'祖国からの知らせ':isResult?'夜の魔王城':'魔王城')+'</div><div class="portrait-frame">'+sprite(expr)+'</div><div class="scene-caption"><span class="dash"></span><p>「私は、絶対に屈しない。」</p></div></section><section class="story fade-in"><div class="obedience '+(state.o<=30?'warning':'')+'"><div class="obedience-top"><span>服従度</span><span class="obedience-number">'+state.o+'<small>%</small></span></div><div class="meter" role="meter" aria-label="服従度" aria-valuemin="0" aria-valuemax="100" aria-valuenow="'+state.o+'"><span style="width:'+state.o+'%"></span></div>'+(warn?'<p class="warning-note">'+esc(warn)+'</p>':'')+'</div><div class="event-meta"><span class="event-tag">'+e.cat+'</span><span class="eyebrow">'+(isResult?'AFTER YOUR CHOICE':'TODAY’S ENCOUNTER')+'</span></div><h2 class="event-title">'+esc(e.title)+'</h2><p class="narration">'+esc(isResult?r.text:e.text)+'</p><div class="dialogue" aria-live="polite"><p class="speaker">女騎士</p><p class="quote">'+esc(isResult?r.reply:p.quote)+'</p></div>'+actions+'<div class="freedom-bar"><button class="freedom" data-do="freedom" '+(state.pendingEscape?'disabled':'')+'>'+icon('door')+'お前は自由だ</button><span class="save-note">'+(saveOK?'記録済み':'保存できませんでした')+'</span></div></section></div></main>';
}
function ending(){
sound.setMode(state.end==='true'?'ending':'sorrow');const def=ENDINGS[state.end],scenes=endingScenes(state),complete=state.endStep>=scenes.length;
if(complete){
app.innerHTML='<main class="ending '+(state.end==='true'?'true':'')+'"><div class="ending-bg"></div><section class="ending-content fade-in"><p class="eyebrow">'+def.label+'</p><h1>'+esc(def.title)+'</h1><p class="end-summary">'+esc(def.summary)+'</p><p class="eyebrow" style="margin:28px 0">DAY '+state.day+' · 服従度 '+state.o+'%</p><div class="end-buttons"><button class="primary" data-do="new">もう一度、はじめる</button><button class="secondary" data-do="archive">回想録を見る</button><button class="secondary" data-do="title">タイトルへ</button></div></section></main>';
}else{
const s=scenes[state.endStep];
app.innerHTML='<main class="ending"><div class="ending-bg"></div><section class="ending-content fade-in"><p class="eyebrow">'+(state.end==='escape'?'THE NEXT MORNING':'AN OPEN DOOR')+'</p><div class="rule" style="margin:30px auto"></div><p class="end-speaker">'+esc(s.speaker||'　')+'</p><div class="end-text" aria-live="polite">'+esc(s.text)+'</div><p class="progress-dots">'+(state.endStep+1)+' / '+scenes.length+'</p><button class="primary" data-do="end-next">'+(state.endStep===scenes.length-1?'結末を見る':'物語を進める')+'</button></section></main>';
}
}
function render(){if(view==='title'){title();return;}if(!state){view='title';title();return;}if(state.phase==='intro')intro();else if(state.phase==='ending')ending();else game();}
function openModal(title,content,type){
modalType=type;$('#modal-body').innerHTML='<div class="modal-head"><h2 id="modal-title">'+title+'</h2><button class="modal-close" data-do="close" aria-label="閉じる">×</button></div><div class="modal-content">'+content+'</div>';if(!modal.open)modal.showModal();
}
function closeModal(){modal.close();modalType='';}
function guide(){
openModal('城での日々','<div class="guide-list"><section><h3>一日につき、ひとつの行動</h3><p>出来事を読み、女騎士の言葉と表情を見て、5つの行動から選びます。行動の後は、夜の言葉を聞いて「翌朝へ」。期限はありません。</p></section><section><h3>命令と、心は別のもの</h3><p>服従度は、命令を受け入れる度合いです。高いほど日々下がりやすくなります。20%以下では、翌朝、彼女が城を去ります。出口を見つめ始めたら、接し方を考え直してください。</p></section><section><h3>同じ親切でも、受け取られ方は違う</h3><p>病人には休息が必要です。誇りを傷つけられた騎士には、任せることが助けになるかもしれません。同じ行動の繰り返しは、効果が薄れます。危機の対処や看病には、続けるべき時もあります。</p></section><section><h3>5日ごとに、祖国からの知らせ</h3><p>祖国の物語は順番に進み、30日を過ぎても続きます。知った事実をどう受け止めるかは、彼女とあなたの選択です。</p></section><section><h3>「お前は自由だ」</h3><p>いつでも告げられる、日々を終える言葉。確認して告げると、撤回できません。彼女が何を選ぶかは、それまでの経験と二人の関係によって変わります。</p></section><section><h3>記録について</h3><p>進行は、この端末・ブラウザに自動保存されます。「最初から」で進行をやり直しても、回想録と見た結末は残ります。ブラウザのデータを消すと記録も消えます。</p></section></div>','guide');
}
function archive(tab=archiveTab){
archiveTab=tab;const tabs='<div class="archive-tabs"><button class="'+(tab==='events'?'active':'')+'" data-do="archive-events">出来事</button><button class="'+(tab==='ends'?'active':'')+'" data-do="archive-ends">結末</button></div>';
let html;
if(tab==='events'){
const seen=ALL_EVENTS.filter(e=>collection.seen.includes(e.id));
html='<p class="text-muted" style="font-size:14px">出会った出来事 '+seen.length+' / '+ALL_EVENTS.length+'</p><div class="archive-list">'+(seen.length?seen.map(e=>'<button class="archive-item" data-do="memory" data-id="'+e.id+'"><small>'+e.cat+'</small><strong>'+esc(e.title)+'</strong></button>').join(''):'<p>城で過ごした日々が、ここに残ります。</p>')+'</div>';
}else{
html='<p class="text-muted" style="font-size:14px">見届けた結末 '+Object.keys(collection.endings).length+' / 6</p>'+Object.entries(ENDINGS).map(([id,e])=>collection.endings[id]?'<button class="archive-item" style="width:100%;margin-bottom:10px" data-do="replay-end" data-id="'+id+'"><small>'+e.label+'</small><strong>'+e.title+'</strong></button>':'<div class="end-card locked"><h3>'+e.label+'</h3><p>まだ見ていない結末</p></div>').join('');
}
openModal('回想録',tabs+html,'archive');
}
function memory(id){
const e=findEvent(id);if(!collection.seen.includes(id))return;const list=collection.memories[id]||[];
openModal(e.title,'<p>'+esc(e.text)+'</p><div class="memory-line"><small>女騎士</small>'+esc(e.quote)+'</div>'+list.map(m=>'<div class="memory-line"><small>DAY '+m.day+' · '+ACTIONS[m.action]+'</small>'+esc(m.text)+'</div><div class="memory-line"><small>女騎士</small>'+esc(m.reply)+'</div><div class="memory-line"><small>その夜</small>'+esc(m.night)+'</div>').join('')+'<button class="secondary" style="margin-top:25px;width:100%" data-do="archive-events">回想録に戻る</button>','memory');
}
function replayEnd(id){
const saved=collection.endings[id];if(!saved)return;
const def=ENDINGS[id],scenes=saved.scenes||[];
openModal(def.title,'<p class="eyebrow">'+def.label+'</p>'+scenes.map(s=>'<div class="memory-line"><small>'+esc(s.speaker||'情景')+'</small>'+esc(s.text)+'</div>').join('')+'<button class="secondary" style="margin-top:25px;width:100%" data-do="archive-ends">結末一覧に戻る</button>','replay');
}
function audioSettings(){
openModal('音の設定','<p>場面に合わせた音楽と効果音を流します。</p><div class="audio-row"><span>音楽・効果音</span><button class="audio-switch" data-do="toggle-sound">'+(settings.sound?'ON':'OFF')+'</button></div><label for="volume">音量</label><input class="volume" id="volume" type="range" min="0" max="70" value="'+Math.round(settings.volume*100)+'" aria-label="音量">','audio');
}
function menu(){
openModal('メニュー','<div class="menu-list"><button class="secondary" data-do="guide">遊び方</button><button class="secondary" data-do="archive">回想録・結末</button><button class="secondary" data-do="audio">音の設定</button><button class="secondary" data-do="title">タイトルへ</button></div>','menu');
}
function startNew(){
if(state){openModal('新しい日々を始める','<p>現在の進行を、最初からやり直します。</p><p>回想録と見た結末は残ります。</p><div class="modal-buttons"><button class="secondary" data-do="close">戻る</button><button class="primary" data-do="new-confirm">最初から始める</button></div>','new');}
else createNew();
}
function createNew(){closeModal();state=newGame();persist();changeView('game');}
function freedom(){
if(!state||!['event','result'].includes(state.phase)||state.pendingEscape)return;
openModal('お前は自由だ','<p class="strong">女騎士を解放します。</p><p>一度告げれば撤回できません。<br>この言葉をもって、二人の日々は結末へ向かいます。</p><div class="modal-buttons"><button class="secondary" data-do="close">まだだ</button><button class="primary" data-do="release-confirm">告げる</button></div>','freedom');
}
function selectAction(index){
if(!state||state.phase!=='event')return;
choose(state,index);persist();const delta=state.result.delta;sound.fx(index===1?'magic':index===0?'armor':index===4?'sword':'click');setTimeout(()=>sound.fx(delta>=0?'up':'down'),200);render();const focus=app.querySelector('[data-do="next"]');focus?.focus({preventScroll:true});
}
async function handle(name,el){
if(busy)return;
void sound.unlock();
switch(name){
case 'new':startNew();break;
case 'new-confirm':createNew();break;
case 'continue':if(state){closeModal();changeView('game');}break;
case 'title':closeModal();changeView('title');break;
case 'intro-next':if(state?.phase==='intro'){state.introStep++;if(state.introStep>=PROLOGUE.length)finishIntro(state);persist();render();if(state.phase==='event')sound.fx('door');}break;
case 'intro-skip':if(state?.phase==='intro'){finishIntro(state);persist();render();sound.fx('door');}break;
case 'choose':selectAction(Number(el.dataset.action));break;
case 'next':if(state?.phase==='result'){nextDay(state);persist();render();window.scrollTo({top:0,behavior:'instant'});if(state.phase==='event')sceneEffect(findEvent(state.current));else sound.fx('steps');}break;
case 'end-next':if(state?.phase==='ending'){const scenes=endingScenes(state);state.endStep=Math.min(state.endStep+1,scenes.length);persist();render();if(state.end==='true'&&[2,3].includes(state.endStep))sound.fx('door');if(state.end==='true'&&state.endStep===4)sound.fx('sword');}break;
case 'freedom':freedom();break;
case 'release-confirm':if(modalType==='freedom'&&state){release(state);closeModal();persist();sound.fx('door');changeView('game');}break;
case 'guide':guide();break;
case 'archive':archive();break;
case 'archive-events':archive('events');break;
case 'archive-ends':archive('ends');break;
case 'memory':memory(el.dataset.id);break;
case 'replay-end':replayEnd(el.dataset.id);break;
case 'audio':audioSettings();break;
case 'toggle-sound':settings.sound=!settings.sound;sound.setEnabled(settings.sound);write(SETTINGS,settings);audioSettings();render();break;
case 'menu':menu();break;
case 'close':closeModal();break;
}
}
document.addEventListener('click',e=>{const el=e.target.closest('[data-do]');if(el){void handle(el.dataset.do,el).catch(()=>toast('操作を続けられませんでした。タイトルから再開してください。'));}});
modal.addEventListener('click',e=>{if(e.target===modal){const r=modal.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)closeModal();}});
modal.addEventListener('cancel',()=>{modalType='';});
document.addEventListener('input',e=>{if(e.target.id==='volume'){settings.volume=Number(e.target.value)/100;sound.setVolume(settings.volume);write(SETTINGS,settings);}});
document.addEventListener('keydown',e=>{if(modal.open||['INPUT','BUTTON'].includes(e.target.tagName)||view==='title')return;if(e.key===' '||e.key==='Enter'){const next=app.querySelector('[data-do="next"],[data-do="end-next"],[data-do="intro-next"]');if(next){e.preventDefault();next.click();}}});
document.addEventListener('visibilitychange',()=>{if(document.hidden){if(state)persist();if(sound.ctx?.state==='running')void sound.ctx.suspend();}else if(settings.sound&&sound.ctx)void sound.unlock();});
window.addEventListener('pagehide',()=>{if(state)persist();});
function publicState(){const e=state?findEvent(state.current):null;return {screen:view,day:state?.day??null,obedience:state?.o??null,phase:state?.phase??null,event:e?.title??null,choices:state?.phase==='event'?ACTIONS:[],ending:state?.phase==='ending'?ENDINGS[state.end].label:null};}
function registerTools(){
const context=document.modelContext;if(!context?.registerTool)return;
const signal=new AbortController();window.addEventListener('pagehide',()=>signal.abort(),{once:true});
const defs=[
{name:'read_knight_game',description:'現在の画面、日付、服従度、選べる行動を読む。隠された感情や分岐条件は返さない。',inputSchema:{type:'object',properties:{},additionalProperties:false},annotations:{readOnlyHint:true,untrustedContentHint:false},execute:()=>publicState()},
{name:'open_knight_game',description:'保存済みのゲームを開く。保存がなければ序章を開始する。保存の上書きはしない。',inputSchema:{type:'object',properties:{},additionalProperties:false},execute:()=>{if(!state)createNew();else{closeModal();changeView('game');}return publicState();}},
{name:'choose_knight_action',description:'今日の5つの行動から1つを選び、夜の結果まで進める。',inputSchema:{type:'object',properties:{action:{type:'string',enum:ACTIONS}},required:['action'],additionalProperties:false},execute:input=>{if(!input||Object.keys(input).some(k=>k!=='action')||!ACTIONS.includes(input.action)||view!=='game'||state?.phase!=='event'||modal.open)throw Error('行動を選べる画面で、有効な行動を指定してください。');selectAction(ACTIONS.indexOf(input.action));return publicState();}},
{name:'advance_knight_story',description:'表示中の序章、行動後の夜、結末の文章を次へ進める。行動の自動選択はしない。',inputSchema:{type:'object',properties:{},additionalProperties:false},execute:async()=>{if(view!=='game'||modal.open)throw Error('ゲームを開いてください。');const key=state?.phase==='intro'?'intro-next':state?.phase==='result'?'next':state?.phase==='ending'?'end-next':null;if(!key)throw Error('今日の行動を先に選んでください。');await handle(key,{});return publicState();}},
{name:'stage_knight_release',description:'女騎士の解放確認を開く。まだ結末は確定しない。',inputSchema:{type:'object',properties:{},additionalProperties:false},execute:()=>{if(view!=='game'||!state||!['event','result'].includes(state.phase)||state.pendingEscape)throw Error('いまは解放できません。');freedom();return {confirmationOpen:true};}},
{name:'confirm_knight_release',description:'開いている解放確認で「告げる」を選び、撤回できない結末へ進める。',inputSchema:{type:'object',properties:{confirmed:{type:'boolean',const:true}},required:['confirmed'],additionalProperties:false},execute:async input=>{if(!input||input.confirmed!==true||Object.keys(input).some(k=>k!=='confirmed')||modalType!=='freedom'||!modal.open)throw Error('解放確認を開き、明示的に確認してください。');await handle('release-confirm',{});return publicState();}}
];
for(const d of defs)try{Promise.resolve(context.registerTool({...d,annotations:d.annotations||{readOnlyHint:false,untrustedContentHint:false}},{signal:signal.signal})).catch(()=>{});}catch{}
}
render();registerTools();
