import {visual,HAIR_NAMES,CLOTHES_NAMES,FACILITY_NAMES} from './visual-state.mjs';
import L from './asset-layout.mjs';
const path=(kind,id)=>`assets/evolution/${kind}-${id}.png`;
const image=(src,cls,style='')=>`<img src="${src}" class="${cls}" style="${style}" alt="" draggable="false">`;
const actor=(id,cls,style='')=>image(path('actors',id),cls,style);
export function appearanceScene(s,cls='',override=null){
 const v=override||visual(s), head=L.heads[v.hair],body=L.bodies[v.clothes];
 const headScale=50/head.faceWidth, bodyScale=[90,90,90,95,102,112,125,138,158,200][v.clothes]/(body.h-body.y);
 const cx=160,faceY=153,neckY=172;
 const hstyle=`width:${head.w*headScale}px;left:${cx-head.x*headScale}px;top:${faceY-head.y*headScale}px`;
 const bstyle=`width:${body.w*bodyScale}px;left:${cx-body.x*bodyScale}px;top:${neckY-body.y*bodyScale}px`;
 const counts=[1,3,5,24,60,104,264],count=counts[v.crowd];
 const front=Array.from({length:count},(_,i)=>{
  let w,x,y;
  if(v.crowd<3){w=24;x=8+i*(77/Math.max(1,count-1));y=4+(i%2)*3;}
  else {const cols=v.crowd===6?44:16;w=v.crowd===6?5:v.crowd===5?14:17;x=1+(i%cols)*98/(cols-1);y=Math.floor(i/cols)*(v.crowd===6?6:13)-3;}
  return actor(1,'follower',`width:${w}px;left:${x}%;bottom:${y}px;z-index:${Math.floor(i/16)};`);
 }).join('');
 const backgroundCrowd=v.crowd>=4?Array.from({length:36},(_,i)=>actor(1,'follower rear-follower',`width:8px;left:${4+(i%18)*5.3}%;bottom:${88+Math.floor(i/18)*13}px`)).join(''):'';
 const shineCount=v.mystery===1?3:v.mystery>=5?18:v.mystery>=4?8:0;
 const glints=Array.from({length:shineCount},(_,i)=>image('assets/evolution/sparkle.png','glint',`left:${7+(i*31)%86}%;top:${10+(i*23)%64}%;width:${v.mystery>=5?12:9}px;--delay:${i*.31}s`)).join('');
 const halo=v.mystery>=2?actor(7,'aura aura-'+v.mystery):'';
 const reporters=v.suspicion>=2?Array.from({length:v.suspicion>=3?4:1},(_,i)=>actor(4,'reporter',`width:${i<2?41:29}px;${i%2?'left':'right'}:${4+Math.floor(i/2)*12}%;bottom:${22+Math.floor(i/2)*30}px;`)).join(''):'';
 const microphones=v.suspicion>=4?actor(5,'microphones left-mics')+actor(5,'microphones right-mics'):'';
 const badges=[v.poor?'清貧の救世主':v.rich?'黄金の先生':'',v.floating?'神秘MAX':'',v.scandal?'渦中の救世主':'',v.social?'百万再生':''].filter(Boolean);
 const desc=`髪型 ${HAIR_NAMES[v.hair]}、服装 ${v.poor?'ボロいローブ':CLOTHES_NAMES[v.clothes]}、施設 ${FACILITY_NAMES[v.facility]}`;
 return `<div class="evo-scene ${cls} ${v.suspicion===5?'warning':''} ${v.mystery>=4?'wind':''}" role="img" aria-label="${desc}">
 ${image(path('facility',v.facility),'facility-art')}
 <div class="rear-crowd">${backgroundCrowd}</div>
 <div class="hero-space"><div class="guru-actor ${v.floating?'levitating':''}">${halo}
 ${v.poor?image('assets/evolution/hand-left.png','poor-hand',`width:14px;left:${cx-45}px;top:${neckY+29}px`)+image('assets/evolution/hand-right.png','poor-hand',`width:14px;left:${cx+31}px;top:${neckY+29}px`):''}
 ${v.poor?actor(2,'garment',`width:90px;left:${cx-45}px;top:${neckY-8}px`):image(path('bodies',v.clothes),'garment '+(v.clothes>=6?'golden-garment':''),bstyle)}
 ${image(path('heads',v.hair),'integrated-head '+(v.movingHair?'head-shimmer':''),hstyle)}
 ${v.scandal?image('assets/evolution/smile.png','smile-mouth',`width:19px;left:${cx-9}px;top:${faceY+10}px`):''}
 ${v.clothes>=7&&!v.poor?actor(6,'royal-crown',`width:${v.clothes===9?51:38}px;left:${cx-21}px;top:${Math.max(2,faceY-head.y*headScale-15)}px`):''}
 </div></div>
 ${glints}${v.social?actor(8,'social-phone'):''}
 ${v.suspicion===1?actor(3,'shadow-visitor'):''}${reporters}
 <div class="front-crowd">${front}</div>${microphones}
 ${v.suspicion===5?'<span class="press-bubble">説明してください！</span>':''}
 <div class="scene-badges">${badges.map(t=>`<span>${t}</span>`).join('')}</div>
 <div class="scene-shade"></div><p class="transformation-caption">教祖さまに変化が……！</p>
 </div>`;
}
export function visualInfo(s,v=visual(s)){
 let quote=v.floating?'教祖「浮いてない？」　信者「浮いております。」':v.clothes===9?'教祖「重い。」':v.facility===9?'教祖「ここ、どこ？」':v.hair>=8?'教祖「切っていい？」　信者「なりません。」':v.hair===1?'信者「先生の髪には意味がある。」　教祖「ないよ。」':v.poor?'教祖「席、足りないよね？」':v.rich?'教祖「今日は何人来るかな。」':'教祖「いつも通りにしてるだけなんだけど。」';
 return `<div class="appearance-info"><span>HAIR Lv${v.hair+1}<b>${HAIR_NAMES[v.hair]}</b></span><span>CLOTHES Lv${v.clothes+1}<b>${v.poor?'ボロいローブ':CLOTHES_NAMES[v.clothes]}</b></span><span>FACILITY Lv${v.facility+1}<b>${FACILITY_NAMES[v.facility]}</b></span></div><p class="guru-quote">${quote}</p>`;
}
export function appearanceChanges(before,after){
 let current={...before};const cards=[];
 const defs=[['hair','髪型',HAIR_NAMES,'教祖「これ進化なの？」'],['clothes','服装',CLOTHES_NAMES,'教祖「着替え、手伝ってくれる？」'],['facility','施設',FACILITY_NAMES,'教祖「ここ、どこ？」'],['mystery','周囲の光',['いつもの日常','小さなキラキラ','小さな後光','後光と光線','浮遊する光と風','星降るきらめき','神秘MAX'],'教祖「何か光ってない？」'],['suspicion','周囲の気配',['平和な日常','端にいる人影','カメラを持った記者','集まり始めた記者','押し寄せるマイク','説明してください！'],'教祖「皆さん、どちらさま？」']];
 for(const [key,label,names,quote] of defs)if(before[key]!==after[key]){
  const previous={...current};current={...current,[key]:after[key]};
  if(key==='hair')current.movingHair=after.movingHair;
  if(key==='clothes')current.poor=after.poor;
  if(key==='facility'){current.rich=after.rich;current.poor=after.poor;}
  if(key==='mystery'){current.floating=after.floating;current.movingHair=after.movingHair;}
  if(key==='suspicion')current.scandal=after.scandal;
  cards.push({name:`${label}が${after[key]>before[key]?'進化':'変化'}しました！`,text:quote,from:names[before[key]],to:names[after[key]],kind:'appearance',label:'教祖さまに変化が……！',visualBefore:previous,visualAfter:{...current},revealed:false,sound:'evolve'});
 }
 const newSpecial=['poor','rich','floating','scandal','social'].filter(k=>before[k]!==after[k]);
 if(newSpecial.length){cards.push({name:'周囲だけが、盛り上がる。',text:after.social?'信者「百万再生です！」\n教祖「僕の動画なの？」':'教祖「状況が、よく分からない。」',kind:'appearance',label:'新しい教祖さまのすがた',visualBefore:{...current},visualAfter:{...after},revealed:false,sound:'evolve'});}
 if(cards.length)cards[cards.length-1].visualAfter={...after};
 return cards;
}
