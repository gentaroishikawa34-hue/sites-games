export const HAIR_NAMES=['ふつう','アホ毛','ふわふわ','流星','大渦','八方髪','浮遊毛','天界ヘア','大宇宙','宇宙そのもの'];
export const CLOTHES_NAMES=['私服','白い服','簡易ローブ','導師服','豪華ローブ','聖衣','黄金聖衣','王衣','大宇宙法衣','説明不能'];
export const FACILITY_NAMES=['普通の部屋','貸し会議室','小さな集会所','道場','教祖会館','大講堂','聖堂','大神殿','聖都','教祖ワールド'];
export const HAIR_LIMITS=[0n,50n,200n,1000n,5000n,20000n,100000n,500000n,3000000n,100000000n];
export const CLOTHES_LIMITS=[0n,200000n,1000000n,5000000n,20000000n,100000000n,500000000n,2000000000n,10000000000n,100000000000n];
const tier=(n,limits)=>limits.reduce((last,v,i)=>n>=v?i:last,0);
export const hair=s=>tier(s.f,HAIR_LIMITS);
export const clothes=s=>tier(s.m,CLOTHES_LIMITS);
export const mystery=s=>tier(s.y,[0,20,40,60,80,95,100]);
export const suspicion=s=>tier(s.s,[0,20,40,60,80,100]);
export function special(s){return {poor:s.f>=1000000n&&s.m<1000000n,rich:s.m>=10000000000n&&s.f<10000n,floating:s.y>=100,scandal:s.s>=90&&s.f>=100000n,social:(s.snsEvents??0)>=5};}
export function facility(s){const x=special(s);return x.poor?1:x.rich?Math.max(8,clothes(s)):Math.min(hair(s),clothes(s));}
export function crowd(s){return tier(s.f,[0n,100n,1000n,10000n,100000n,1000000n,10000000n]);}
export function visual(s){return {hair:hair(s),clothes:clothes(s),facility:facility(s),mystery:mystery(s),suspicion:suspicion(s),crowd:crowd(s),movingHair:(hair(s)>=6&&s.y>=70)||s.y>=100,...special(s)};}
