export class Sound{
 constructor(settings){this.settings=settings;this.ctx=null;this.mode='title';this.tick=0;this.timer=null;document.addEventListener('visibilitychange',()=>{if(document.hidden)this.stop();else this.start();});}
 unlock(){try{if(!this.ctx)this.ctx=new (window.AudioContext||window.webkitAudioContext)();if(this.ctx.state==='suspended')this.ctx.resume().catch(()=>{});this.start();}catch{}}
 tone(freq,duration=.2,type='sine',volume=.08,delay=0){if(!this.ctx)return;const c=this.ctx,t=c.currentTime+delay,o=c.createOscillator(),g=c.createGain();o.type=type;o.frequency.value=freq;g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(volume,t+.012);g.gain.exponentialRampToValueAtTime(.001,t+duration);o.connect(g);g.connect(c.destination);o.start(t);o.stop(t+duration+.03);}
 setMode(mode){if(this.mode!==mode){this.mode=mode;this.tick=0;}this.start();}
 start(){if(!this.ctx||!this.settings.bgm||document.hidden){this.stop();return;}if(this.timer)return;this.timer=setInterval(()=>this.playBeat(),380);}
 stop(){if(this.timer){clearInterval(this.timer);this.timer=null;}}
 playBeat(){const tension=['collect','break','ended'].includes(this.mode),root=tension?82.41:110;const scale=tension?[0,1,7,1,0,6,7,1]:this.mode==='title'?[0,7,10,14,12,7,3,10]:[0,3,7,10,7,5,3,7];const n=scale[this.tick%8];this.tone(root*Math.pow(2,n/12),.6,'sine',.035);if(this.tick%4===0){this.tone(root/2,1.1,'triangle',.035);if(!tension)[3,7,10].forEach((v,i)=>this.tone(root*2*Math.pow(2,v/12),.8,'sine',.012,i*.035));}this.tick++;}
 effect(kind){if(!this.settings.sfx)return;this.unlock();const patterns={tap:[330],work:[330,440,550],gain:[523,659,784],loss:[220,185,146],promote:[392,494,587,784],title:[440,554,659,880],collect:[110,116,110],paid:[294,392,494],failed:[196,147,98],break:[220,207,196],ended:[220,165,110],great:[523,659,784,1047]};(patterns[kind]||patterns.tap).forEach((n,i)=>this.tone(n,.35,'sine',.065,i*.13));}
}
