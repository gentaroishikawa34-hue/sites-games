import {JOBS,POLICIES,TITLES,LINES} from './data.js';
import {EVENTS} from './events.js';
export const VERSION=1;
export const bi=x=>BigInt(x??0);
export const titleFor=s=>s.gifted==='0'?'ただの彼女':TITLES.filter(t=>bi(s.gifted)>=bi(t[0])).at(-1)[1];
export const newGame=()=>({id:globalThis.crypto?.randomUUID?.()||`${Date.now()}-${Math.random()}`,version:VERSION,rev:0,job:0,money:'0',gifted:'0',collected:'0',pop:0,month:1,completed:0,phase:'work',eventIndex:0,history:[],lastLines:{},unlocked:[0],milestones:[],ledger:[],notice:[],finished:false});
function say(s,group,rng){const pool=LINES[group].filter(x=>x!==s.lastLines[group]);const line=pool[Math.floor(rng()*pool.length)];s.lastLines[group]=line;return line;}
function cash(s,amount,label){const before=bi(s.money);const after=before+bi(amount)<0n?0n:before+bi(amount);s.money=String(after);const delta=after-before;s.ledger.push({label,delta:String(delta)});return String(delta);}
function draw(s,rng){let rarity=rng()<.035?'超レア':rng()<.17?'レア':'通常';let pool=EVENTS.filter(e=>e.rarity===rarity&&e.ranks.includes(s.job)&&s.month>=e.minMonth&&!s.history.includes(e.id));if(!pool.length)pool=EVENTS.filter(e=>e.ranks.includes(s.job)&&s.month>=e.minMonth&&!s.history.includes(e.id));s.eventId=pool[Math.floor(rng()*pool.length)].id;s.history=[...s.history,s.eventId].slice(-24);s.phase='event';s.quote=EVENTS.find(e=>e.id===s.eventId).quote||say(s,'daily',rng);}
function finish(s,reason,rng){s.finished=true;s.phase='ended';s.reason=reason;s.endQuote=say(s,reason==='集金不足'?'failed':'goodbye',rng);if(reason==='集金不足')s.completed=s.month;}
function afterGift(s,rng){if(s.month%3===0){s.phase='collect';s.quote=say(s,'collect',rng);}else{s.completed=s.month;s.phase='monthEnd';}}
export function transition(state,action,payload={},rng=Math.random){
 if(!state||state.finished)return state;
 if(payload.rev!==undefined&&payload.rev!==state.rev)return state;
 const s=structuredClone(state), phase=s.phase, j=JOBS[s.job];let changed=true;
 switch(action){
 case 'work':{
  if(phase!=='work'||![0,1,2].includes(payload.index))return state;
  const p=POLICIES[payload.index], roll=rng(),amount=Math.round(j.salary*(1+(roll*2-1)*p.range));
  s.ledger=[];cash(s,amount,'仕事収入');s.pop+=p.pop;s.report={title:j.work[payload.index],text:j.result[payload.index],cash:String(amount),pop:p.pop,great:payload.index===2&&roll>.85};s.phase='workResult';s.eventIndex=0;break;}
 case 'next':
  if(phase==='workResult')draw(s,rng);
  else if(phase==='eventResult'){if(s.eventIndex<3)draw(s,rng);else s.phase='promotion';}
  else if(phase==='promotionResult')s.phase='promotion';
  else if(phase==='giftResult'){s.notice=[];if(s.special===2000000000){s.special=null;s.quote=say(s,'daily',rng);}afterGift(s,rng);}
  else if(phase==='collectResult'){s.completed=s.month;s.phase='monthEnd';}
  else if(phase==='monthEnd'){s.month++;s.phase='work';s.ledger=[];s.report=null;}
  else if(phase==='breakResult')s.phase=s.resume;
  else return state;break;
 case 'choose':{
  if(phase!=='event'||![0,1,2].includes(payload.index))return state;
  const event=EVENTS.find(e=>e.id===s.eventId);const option=event.choices[payload.index];const good=rng()<option.chance;const outcome=good?option.good:option.bad;
  const requested=Math.round(j.salary*outcome.money),actual=cash(s,requested,event.title);const old=s.pop;s.pop=Math.max(0,s.pop+outcome.pop);
  s.report={title:event.title,text:outcome.text,cash:actual,requested:String(requested),pop:s.pop-old,good,image:event.image,rarity:event.rarity};s.eventIndex++;s.phase='eventResult';s.quote=outcome.quote||event.quote||say(s,'daily',rng);break;}
 case 'promote':
  if(phase!=='promotion'||s.job>=5||s.pop<JOBS[s.job+1].threshold)return state;
  s.job++;s.phase='promotionResult';s.quote=LINES.career[s.job*2+Math.floor(rng()*2)];break;
 case 'toGift':if(phase!=='promotion')return state;s.phase='gift';break;
 case 'gift':{
  if(phase!=='gift'||!/^\d+$/.test(String(payload.amount)))return state;
  const amount=bi(payload.amount);if(amount<0n||amount>bi(s.money))return state;
  if(amount===0n){afterGift(s,rng);break;}
  cash(s,-amount,'自由貢ぎ');s.gifted=String(bi(s.gifted)+amount);s.quote=say(s,'gift',rng);s.notice=[];
  TITLES.forEach(([limit,name],i)=>{if(bi(s.gifted)>=bi(limit)&&!s.unlocked.includes(i)){s.unlocked.push(i);s.notice.push(name);}});
  s.special=null;for(const limit of [100000000,1000000000,2000000000])if(bi(s.gifted)>=bi(limit)&&!s.milestones.includes(limit)){s.milestones.push(limit);s.special=limit;}
  if(s.special===2000000000)s.quote='貢がなくても、もういいぜ…。お前の愛…ちゃんと伝わってるからよ…。';
  s.report={cash:String(amount)};s.phase='giftResult';break;}
 case 'collect':
  if(phase!=='collect')return state;
  if(bi(s.money)<bi(j.fee)){s.shortage=String(bi(j.fee)-bi(s.money));finish(s,'集金不足',rng);}
  else{cash(s,-bi(j.fee),'強制集金');s.collected=String(bi(s.collected)+bi(j.fee));s.quote=say(s,'paid',rng);s.phase='collectResult';}break;
 case 'break':
  if(phase==='breakResult')return state;
  if(rng()<.25)finish(s,'別れ話に成功',rng);
  else{s.resume=phase;s.phase='breakResult';s.quote=say(s,'refuse',rng);}break;
 default:changed=false;
 }
 if(!changed)return state;s.rev++;return s;
}
export function validateSave(s){try{return s.version===VERSION&&Number.isInteger(s.job)&&s.job>=0&&s.job<=5&&Number.isInteger(s.month)&&s.month>=1&&Number.isFinite(s.pop)&&s.pop>=0&&['money','gifted','collected'].every(k=>/^\d+$/.test(s[k]))&&Array.isArray(s.history)&&Array.isArray(s.ledger)&&['work','workResult','event','eventResult','promotion','promotionResult','gift','giftResult','collect','collectResult','monthEnd','breakResult','ended'].includes(s.phase)&&(!(s.phase==='event')||EVENTS.some(e=>e.id===s.eventId));}catch{return false;}}
export function summarize(s){return{id:s.id,date:new Date().toISOString(),job:s.job,completed:s.completed,pop:s.pop,gifted:s.gifted,collected:s.collected,title:titleFor(s),reason:s.reason,quote:s.endQuote};}
