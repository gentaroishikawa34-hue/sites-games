/* Four-second manga finishing sequence. Owns presentation only. */
window.YamiFinisher=(()=>{
  const timeline=[{at:0,phase:'silence',label:''},{at:240,phase:'approach',label:'闇より、忍び寄る。',audio:'draw'},{at:1530,phase:'strike',label:'一 閃',audio:'cut'},{at:2240,phase:'aftermath',label:'悪は、夜に沈む。',audio:'tail'},{at:3650,phase:'seal',label:'仕置完了'}];
  let running=false,timers=[],finishCallback=null;
  function mount(){const root=document.querySelector('#cinematic');root.innerHTML='<div class="finish-aura"></div><div class="finish-panel"><div class="finish-art"></div></div><div class="finish-slash"></div><div class="finish-flash"></div><div class="finish-ink"></div><p class="finish-line"></p><div class="finish-seal" aria-hidden="true"><small>悪を討ち、闇に還る</small><strong>仕置完了</strong><span>第一話　悪代官の屋敷</span></div>';return root;}
  function render(phase,label=''){let root=document.querySelector('#cinematic');if(!root.querySelector('.finish-panel'))root=mount();root.classList.remove('hidden');root.dataset.phase=phase;root.querySelector('.finish-line').textContent=label;root.querySelector('.finish-seal').setAttribute('aria-hidden',phase==='seal'?'false':'true');}
  function complete(){if(!running)return;running=false;timers.forEach(clearTimeout);timers=[];document.querySelector('#cinematic').classList.add('hidden');const callback=finishCallback;finishCallback=null;callback?.();}
  function play({sound,onComplete}){if(running)return;running=true;finishCallback=onComplete;mount();for(const step of timeline){const fire=()=>{render(step.phase,step.label);if(step.audio)sound?.(step.audio)};if(!step.at)fire();else timers.push(setTimeout(fire,step.at));}timers.push(setTimeout(complete,4450));}
  return{play,render};
})();
