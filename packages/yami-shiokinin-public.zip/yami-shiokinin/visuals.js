/* Presentation layer: game simulation remains in its original world coordinates. */
window.YamiVisual=(()=>{
  const project=(x,y)=>({x:480+.86*x-.48*y,y:90+.35*x+.68*y});
  const inverse=(x,y)=>({x:(.68*x+.48*y)/.7528,y:(-.35*x+.86*y)/.7528});
  let seed=71;const rng=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296};
  function poly(g,pts,color,alpha=1){g.fillStyle(color,alpha).fillPoints(pts,true);}
  function rect(g,x,y,w,h,color,alpha=1,z=0){poly(g,[[x,y],[x+w,y],[x+w,y+h],[x,y+h]].map(([a,b])=>{let p=project(a,b);p.y-=z;return p}),color,alpha);}
  function line(g,x,y,x2,y2,color,alpha=.5,width=1,z=0){let a=project(x,y),b=project(x2,y2);g.lineStyle(width,color,alpha).lineBetween(a.x,a.y-z,b.x,b.y-z);}
  function frames(scene,key){const img=scene.textures.get(key).getSourceImage(),cw=Math.floor(img.width/4),ch=Math.floor(img.height/2);const c=document.createElement('canvas');c.width=img.width;c.height=img.height;let ctx=c.getContext('2d',{willReadFrequently:true});ctx.drawImage(img,0,0);let d=ctx.getImageData(0,0,c.width,c.height).data;for(let i=0;i<8;i++){let ox=(i%4)*cw,oy=Math.floor(i/4)*ch,l=cw,t=ch,r=0,b=0;for(let y=5;y<ch-5;y++)for(let x=5;x<cw-5;x++){if(d[((oy+y)*c.width+ox+x)*4+3]>60){l=Math.min(l,x);r=Math.max(r,x);t=Math.min(t,y);b=Math.max(b,y)}}if(r<l){l=0;t=0;r=cw-1;b=ch-1}scene.textures.get(key).add(String(i),0,ox+l,oy+t,r-l+1,b-t+1);}}
  function preload(scene){scene.load.image('cast','assets/cast.png');scene.load.image('props','assets/props.png');scene.load.image('materials','assets/materials.png');}
  function init(scene){frames(scene,'cast');frames(scene,'props');let c=document.createElement('canvas');c.width=256;c.height=256;let ctx=c.getContext('2d'),grad=ctx.createRadialGradient(128,128,0,128,128,128);grad.addColorStop(0,'rgba(255,186,89,0.32)');grad.addColorStop(.35,'rgba(255,158,58,0.11)');grad.addColorStop(1,'rgba(255,158,58,0)');ctx.fillStyle=grad;ctx.fillRect(0,0,256,256);scene.textures.addCanvas('light',c);}
  function prop(scene,index,x,y,width){let p=project(x,y);let im=scene.add.image(p.x,p.y,'props',String(index)).setOrigin(.5,.91);im.setScale(width/im.width).setDepth(p.y);return im;}
  function wall(scene,x,y,w,h,index){const g=scene.add.graphics();const height=index<4?52: index<13?62:44;let a=project(x,y),b=project(x+w,y),c=project(x+w,y+h),d=project(x,y+h);g.setDepth(c.y-8);poly(g,[{x:d.x,y:d.y-height},{x:c.x,y:c.y-height},c,d],0x302f29);poly(g,[{x:b.x,y:b.y-height},{x:c.x,y:c.y-height},c,b],0x211e1c);rect(g,x,y,w,h,0x3c4750,1,height);let long=w>h,length=long?w:h;for(let n=0;n<length;n+=45){let q=project(x+(long?n:w),y+(long?h:n));g.lineStyle(3,0x1b1615,.9).lineBetween(q.x,q.y,q.x,q.y-height);if(index>=4&&index<13){let next=project(x+(long?Math.min(n+40,w):w),y+(long?h:Math.min(n+40,h)));poly(g,[{x:q.x+3,y:q.y-height+9},{x:next.x-3,y:next.y-height+9},{x:next.x-3,y:next.y-12},{x:q.x+3,y:q.y-12}],0xbca06c,.59);g.lineStyle(1,0x352b24,.8).lineBetween(q.x,q.y-32,next.x,next.y-32)}}if(index<4){for(let n=0;n<length;n+=23){let q=project(x+(long?n:0),y+(long?0:n));g.lineStyle(4,0x415366,.8).lineBetween(q.x-8,q.y-height-8,q.x+21,q.y-height+10)}}return g;}
  function materialFloor(scene){
    const source=scene.textures.get('materials').getSourceImage(),cw=source.width/2,ch=source.height/2;
    const canvas=document.createElement('canvas');canvas.width=2250;canvas.height=1460;let ctx=canvas.getContext('2d');ctx.setTransform(.86,.35,-.48,.68,480,90);
    function fill(index,x,y,w,h,size=300,alpha=1){ctx.save();ctx.beginPath();ctx.rect(x,y,w,h);ctx.clip();ctx.globalAlpha=alpha;let th=size*ch/cw;for(let yy=y;yy<y+h;yy+=th)for(let xx=x;xx<x+w;xx+=size)ctx.drawImage(source,(index%2)*cw,Math.floor(index/2)*ch,cw,ch,xx,yy,size,th);ctx.restore();}
    fill(0,60,55,950,780,380,.94);
    ctx.save();ctx.beginPath();for(let i=0;i<40;i++){let x=90+i*24,y=350+Math.sin(i*.4)*22;ctx.rect(x,y-25,30,50)}ctx.clip();fill(1,80,290,930,110,205,.84);ctx.restore();
    fill(1,85,383,148,142,205,.55);fill(2,90,542,925,200,390,.95);
    fill(3,1065,292,750,350,330,.78);ctx.fillStyle='#273e35';ctx.strokeStyle='#23392e';ctx.lineWidth=5;for(let x=1065;x<1815;x+=125)for(let y=292;y<642;y+=87)ctx.strokeRect(x+2,y+2,120,82);
    ctx.fillStyle='#652c2a';ctx.fillRect(1550,380,218,147);ctx.strokeStyle='#b49254';ctx.lineWidth=2;ctx.strokeRect(1557,387,204,133);ctx.globalAlpha=.16;for(let i=0;i<10;i++){ctx.beginPath();ctx.arc(1570+i*19,450,7,0,Math.PI*2);ctx.stroke()}ctx.globalAlpha=1;
    scene.textures.addCanvas('floorMaterial',canvas);scene.add.image(0,0,'floorMaterial').setOrigin(0).setDepth(-95);
  }
  function map(scene,solids,cover){seed=71;init(scene);const g=scene.add.graphics().setDepth(-100);g.fillStyle(0x07131e).fillRect(-300,-300,3000,2100);rect(g,35,35,1800,810,0x182b2d);for(let i=0;i<2900;i++){let x=62+rng()*940,y=62+rng()*770,p=project(x,y);g.fillStyle(pick([0x335043,0x263f3a,0x1c3334,0x536358]),.4).fillEllipse(p.x,p.y,2+rng()*8,1+rng()*3)}
    // Irregular flagstone paths in the garden and entry court.
    for(let i=0;i<39;i++){let x=100+i*23,y=345+Math.sin(i*.68)*27;rect(g,x,y,22+rng()*10,15+rng()*8,0x5a6664,.75);line(g,x,y,x+22,y,0x9aa79d,.3)}
    for(let i=0;i<48;i++){let x=95+rng()*135,y=380+rng()*140;rect(g,x,y,17+rng()*13,12+rng()*8,0x6a7168,.36)}
    // Raised timber passage, plank joins and grain.
    rect(g,78,534,940,211,0x101922);rect(g,90,542,925,200,0x6b5035);
    for(let y=544;y<742;y+=16){for(let x=90;x<1015;x+=93){rect(g,x,y,Math.min(90,1015-x),14,pick([0x644a32,0x705137,0x795a3b,0x58432f]));for(let j=0;j<3;j++)line(g,x+4,y+3+j*3,Math.min(x+86,1013),y+4+j*3,0x302a22,.32)}}
    // Tatami rooms with alternating weave and dark borders.
    rect(g,1049,276,776,384,0x463828);for(let x=1065;x<1815;x+=125)for(let y=292;y<642;y+=87){rect(g,x,y,122,84,pick([0x80754b,0x746d4b,0x8b7b4e]));for(let n=3;n<83;n+=4)line(g,x+3,y+n,x+119,y+n,0x443e2b,.3);rect(g,x,y,5,84,0x25332d)}
    rect(g,1550,380,218,147,0x6e302b,.85);rect(g,1557,387,204,133,0x8a4534,.3);for(let i=0;i<12;i++){let x=1562+i*16;line(g,x,387,x,517,0xc6a363,.11)}
    materialFloor(scene);
    // Physical objects match the unchanged collision footprints.
    solids.forEach((r,i)=>{if(i<13)wall(scene,...r,i);else if(i<17||i===20)prop(scene,5,r[0]+r[2]/2,r[1]+r[3]/2,32);else prop(scene,1,r[0]+r[2]/2,r[1]+r[3]/2,r[2]+23)});
    cover.forEach(([x,y,w,h])=>prop(scene,0,x+w/2,y+h/2,w+22));
    [[335,115],[956,467],[1078,474],[1792,429],[1477,317],[142,550]].forEach(([x,y])=>{let p=project(x,y);scene.add.image(p.x,p.y-15,'light').setDisplaySize(205,160).setBlendMode(Phaser.BlendModes.ADD).setDepth(-20);prop(scene,2,x,y,44)});
    // Scenic objects beyond the playable boundary never imply additional cover.
    [[92,7],[270,10],[595,0],[780,12],[12,280],[12,720],[1750,880]].forEach(([x,y])=>prop(scene,6,x,y,115));
    [[1100,262],[1290,262],[1510,262],[1750,262]].forEach(([x,y])=>prop(scene,7,x,y,45));
    for(let x=115;x<960;x+=140)prop(scene,3,x,29,145);
    const title=(x,y,label)=>{let p=project(x,y);scene.add.text(p.x,p.y,label,{fontFamily:'serif',fontSize:'17px',color:'#e0cda3',stroke:'#0a151d',strokeThickness:3}).setOrigin(.5).setAlpha(.76).setDepth(-5)};title(540,445,'庭　園');title(690,735,'渡り廊下');title(1660,565,'奥座敷');
    // Slow, low-opacity drifting moonlit mist.
    for(let i=0;i<4;i++){let p=project(170+i*300,160+i*120);let fog=scene.add.ellipse(p.x,p.y,550,120,0x91bdce,.025).setDepth(2000);scene.tweens.add({targets:fog,x:p.x+100,y:p.y+30,duration:14000+i*2000,yoyo:true,repeat:-1});}
  }
  const pick=a=>a[Math.floor(rng()*a.length)];
  function figure(scene,kind,x,y){let p=project(x,y),col={player:0,guard:1,runner:2,target:3}[kind];let sprite=scene.add.image(p.x,p.y,'cast',String(col)).setOrigin(.5,1);sprite.setScale((kind==='target'?57:70)/sprite.height).setDepth(p.y+2);sprite._kind=kind;sprite._last={x,y};sprite._shadow=scene.add.ellipse(p.x,p.y-1,kind==='target'?43:31,12,0x02070c,.5).setDepth(-2);if(kind==='player'){sprite._ring=scene.add.ellipse(p.x,p.y,37,17,0xe4c78d,.06).setStrokeStyle(1,0xe4c78d,.4).setDepth(-1)}sprite._mark=scene.add.text(p.x,p.y-80,kind==='target'?'標的':'',{fontSize:'14px',fontFamily:'serif',color:'#e7bd78',stroke:'#101719',strokeThickness:3}).setOrigin(.5).setDepth(2001);sprite.on('destroy',()=>{sprite._shadow.destroy();sprite._ring?.destroy();sprite._mark.destroy()});return sprite;}
  function sync(e,time=0){let p=project(e.x,e.y),s=e.sprite;if(!e.alive){s._mark.setText('');return}let dx=e.x-s._last.x,dy=e.y-s._last.y,moving=Math.hypot(dx,dy)>.1,col={player:0,guard:1,runner:2,target:3}[e.kind];let face=e.face||{x:1,y:0},sy=.35*face.x+.68*face.y,sx=.86*face.x-.48*face.y;let frame=col+(sy<-.1?4:0);s.setFrame(String(frame));s.setFlipX(sx<0);s.setScale((e.kind==='target'?57:70)/s.height);s.setPosition(p.x,p.y-(moving?Math.sin(time*12)*1.5:Math.sin(time*2+e.x)*.3)).setDepth(p.y+2);s._shadow.setPosition(p.x,p.y);s._ring?.setPosition(p.x,p.y);s._mark.setPosition(p.x,p.y-79).setText(e.kind==='target'?'標的':e.state==='chase'?'！':['search','investigate'].includes(e.state)?'？':'').setColor(e.state==='chase'?'#ff6e55':'#e7bd78');s._last={x:e.x,y:e.y};}
  return{project,inverse,preload,map,figure,sync,bounds:{width:2250,height:1460}};
})();
