/* 闇の仕置人 — self-contained Phaser 3 game. Map coordinates are world pixels. */
(() => {
  'use strict';
  const W=1880,H=900, VW=960,VH=540, R=15;
  const art=window.YamiVisual;
  const $=s=>document.querySelector(s);
  const ui={screen:$('#screen'),copy:$('#screen-copy'),buttons:$('#screen-buttons'),hud:$('#hud'),status:$('#status'),timer:$('#timer'),strike:$('#strike'),stick:$('#stick'),joy:$('#joystick'),cinema:$('#cinematic'),cut:$('#cut-image'),caption:$('#cut-caption'),number:$('#cut-number')};
  const solids=[
    // perimeter and enclosing walls; the two openings at x=1030 are the garden and hall routes
    [25,25,1830,30],[25,845,1830,30],[25,25,30,850],[1825,25,30,850],
    [1015,45,34,206],[1015,391,34,139],[1015,661,34,183],
    [1049,251,775,24],[1049,660,775,24],
    [1435,275,26,105],[1435,520,26,140],
    [1220,275,22,65],[1220,595,22,65],
    // pillars / obstacles
    [1160,405,25,28],[1315,405,24,28],[1515,326,24,28],[1660,592,24,28],
    [390,178,64,52],[670,345,65,55],[840,165,55,50],[540,570,25,29]
  ];
  const cover=[[225,253,70,55],[510,294,80,58],[750,114,80,54],[878,416,72,57],[324,410,66,54]];
  const collision=[...solids,...cover];
  const routes=[
    [[250,145],[320,315],[460,315],[560,150]],
    [[590,170],[760,260],[920,315],[805,405]],
    [[170,630],[360,600],[620,615],[810,600]],
    [[770,706],[965,610],[915,560],[660,600]],
    [[1110,310],[1270,350],[1350,465],[1120,520]],
    [[1100,585],[1290,580],[1350,495],[1190,475]],
    [[1510,420],[1690,390],[1755,525],[1550,540]],
    [[1500,600],[1690,565],[1755,440],[1600,400]]
  ];
  const spawnPoints=[[1100,322],[1100,600],[1540,310],[1710,595],[920,300],[920,610]];
  let scene, mode='title', elapsed=0, alarmTime=0, reinforcementCount=0, player, target, guards=[], objects=[], joy={x:0,y:0}, pausedMusic=null, musicAt=0, audioCtx=null, cameraShake=0;
  const rand=(a,b)=>a+Math.random()*(b-a), pick=a=>a[Math.floor(Math.random()*a.length)], dist=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y), centerRect=(x,y,r)=>[x-r,y-r,r*2,r*2];
  const intersects=(a,b)=>a[0]<b[0]+b[2]&&a[0]+a[2]>b[0]&&a[1]<b[1]+b[3]&&a[1]+a[3]>b[1];
  function blocked(x,y,r=R){return collision.some(o=>intersects(centerRect(x,y,r),o));}
  function move(entity,vx,vy,dt){const step=Math.min(dt,.045);let nx=entity.x+vx*step,ny=entity.y+vy*step;if(!blocked(nx,entity.y,entity.radius))entity.x=nx;if(!blocked(entity.x,ny,entity.radius))entity.y=ny;art.sync(entity,elapsed);}
  function clearLine(x1,y1,x2,y2){const n=Math.ceil(Math.hypot(x2-x1,y2-y1)/12);for(let i=1;i<n;i++){const t=i/n,x=x1+(x2-x1)*t,y=y1+(y2-y1)*t;if(collision.some(o=>x>=o[0]&&x<=o[0]+o[2]&&y>=o[1]&&y<=o[1]+o[3]))return false;}return true;}
  // A* on a coarse grid keeps chasing enemies from walking into walls or getting stuck at doors.
  const cell=32,cols=Math.ceil(W/cell),rows=Math.ceil(H/cell);let walkable=[];
  function setupGrid(){walkable=Array.from({length:cols*rows},(_,i)=>!blocked((i%cols+.5)*cell,(Math.floor(i/cols)+.5)*cell,13));}
  function node(x,y){const cx=Math.max(0,Math.min(cols-1,Math.floor(x/cell))),cy=Math.max(0,Math.min(rows-1,Math.floor(y/cell)));return cy*cols+cx;}
  function nearestOpen(index){if(walkable[index])return index;let x=index%cols,y=Math.floor(index/cols);for(let radius=1;radius<8;radius++)for(let yy=y-radius;yy<=y+radius;yy++)for(let xx=x-radius;xx<=x+radius;xx++){let k=yy*cols+xx;if(xx>=0&&yy>=0&&xx<cols&&yy<rows&&walkable[k])return k;}return index;}
  function pathfind(from,to){let start=nearestOpen(node(from.x,from.y)),end=nearestOpen(node(to.x,to.y));if(start===end)return[{x:to.x,y:to.y}];const open=[start],cost=new Map([[start,0]]),prev=new Map(),closed=new Set();let iterations=0;while(open.length&&iterations++<2500){let best=0,score=Infinity;for(let i=0;i<open.length;i++){let k=open[i],f=cost.get(k)+Math.abs(k%cols-end%cols)+Math.abs(Math.floor(k/cols)-Math.floor(end/cols));if(f<score){score=f;best=i;}}let current=open.splice(best,1)[0];if(current===end){let result=[];while(current!==start){result.unshift({x:(current%cols+.5)*cell,y:(Math.floor(current/cols)+.5)*cell});current=prev.get(current);if(current===undefined)break;}return result;}closed.add(current);const x=current%cols,y=Math.floor(current/cols);for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){let xx=x+dx,yy=y+dy,k=yy*cols+xx;if(xx<0||xx>=cols||yy<0||yy>=rows||!walkable[k]||closed.has(k))continue;let next=cost.get(current)+1;if(next<(cost.get(k)??Infinity)){cost.set(k,next);prev.set(k,current);if(!open.includes(k))open.push(k);}}}return[];}
  function createMap(){art.map(scene,solids,cover);}
  function character(kind,x,y){const sprite=art.figure(scene,kind,x,y);return{kind,x,y,sprite,radius:kind==='target'?18:14,alive:true,face:{x:1,y:0},state:'patrol',path:[],pathTick:0,investigate:null,route:null,idx:0,searchUntil:0};}
  function spawnGuard(kind='guard',pos=null){let spawn=pos||pick(spawnPoints);const p=character(kind,spawn[0]+rand(-9,9),spawn[1]+rand(-9,9));p.speed=kind==='runner'?122:kind==='guard'?73:0;p.face={x:Math.cos(rand(0,Math.PI*2)),y:Math.sin(rand(0,Math.PI*2))};p.idx=Math.floor(rand(0,p.route?.length||4));p.seenBodies=new Set();guards.push(p);return p;}
  function reset(){for(let o of objects)o?.destroy();objects=[];for(let guard of guards)guard.sprite.destroy();guards=[];player?.sprite.destroy();target?.sprite.destroy();mode='playing';elapsed=0;alarmTime=0;reinforcementCount=0;musicAt=0;joy.x=joy.y=0;resetStick();scene.cameras.main.stopFollow();player=character('player',125,445);target=character('target',1700,451);scene.cameras.main.startFollow(player.sprite,false,.11,.11);scene.cameras.main.setBounds(0,0,art.bounds.width,art.bounds.height);scene.cameras.main.setDeadzone(200,135);
    let order=Phaser.Utils.Array.Shuffle([...routes.keys()]);let count=5+Math.floor(Math.random()*4);for(let i=0;i<count;i++){let route=routes[order[i]].map(v=>({x:v[0],y:v[1]}));let idx=Math.floor(rand(0,route.length)),p=spawnGuard('guard',[route[idx].x,route[idx].y]);p.route=route;p.idx=(idx+1)%route.length;p.face={x:Math.cos(rand(-Math.PI,Math.PI)),y:Math.sin(rand(-Math.PI,Math.PI))};}
    ui.hud.classList.remove('hidden');ui.screen.classList.add('hidden');ui.cinema.classList.add('hidden');setStatus('気配を消して、奥座敷へ');ui.strike.disabled=true;ui.strike.classList.remove('ready');sound('start');
  }
  function setStatus(s,alert=false){ui.status.textContent=s;ui.status.classList.toggle('alert',alert);}
  function changeScreen(title,copy,actions){mode='menu';ui.hud.classList.add('hidden');ui.screen.classList.remove('hidden');ui.screen.querySelector('h1').textContent=title;ui.copy.innerHTML=copy;ui.buttons.innerHTML=actions.map(a=>`<button class="${a.secondary?'secondary':''}" data-action="${a.action}">${a.label}</button>`).join('');}
  function endGame(){if(mode!=='playing')return;sound('caught');changeScreen('闇に散る','追っ手に捕らえられた。<br>敵の配置と巡回路を変えて、再挑戦できます。',[{action:'retry',label:'即リトライ'},{action:'title',label:'タイトルへ',secondary:true}]);}
  function alert(){if(mode!=='playing'||alarmTime)return;alarmTime=.001;guards.forEach(g=>{if(g.alive)g.state='chase'});setStatus('発見！　追っ手が迫る',true);sound('spotted');}
  function noise(x,y){for(let g of guards){if(!g.alive||g.state==='chase')continue;if(Math.hypot(g.x-x,g.y-y)<195){g.state='investigate';g.investigate={x,y};g.searchUntil=elapsed+6;g.pathTick=0;}}}
  function strike(){if(mode!=='playing')return;let near=guards.filter(g=>g.alive&&dist(player,g)<59).sort((a,b)=>dist(player,a)-dist(player,b));let victim=target.alive&&dist(player,target)<62?target:near[0];if(!victim)return;if(victim===target){finish();return;}victim.alive=false;victim.state='dead';victim.sprite.setOrigin(.5,.5).setRotation(-Math.PI/2).setTint(0x818b89).setAlpha(.8).setDepth(art.project(victim.x,victim.y).y-1);victim.sprite.setPosition(art.project(victim.x,victim.y).x,art.project(victim.x,victim.y).y-9);art.sync(victim);sound('guard');noise(victim.x,victim.y);setStatus('物音が響く。見張りが確認に来る');}
  function reinforce(){for(let n=0;n<2;n++){let possibilities=spawnPoints.filter(p=>Math.hypot(p[0]-player.x,p[1]-player.y)>270);let g=spawnGuard('runner',pick(possibilities.length?possibilities:spawnPoints));g.state='chase';g.pathTick=0;}reinforcementCount+=2;setStatus(`発見中！　追っ手 ${reinforcementCount} 人増援`,true);sound('reinforce');}
  function finish(){
    if(mode!=='playing')return;
    mode='cinematic';ui.hud.classList.add('hidden');
    window.YamiFinisher.play({sound:finishSound,onComplete:()=>{
      changeScreen('仕置完了',`悪代官を仕留めた。<br>所要時間 ${formatTime(elapsed)}　／　追っ手 ${reinforcementCount} 人`,[{action:'retry',label:'もう一度遊ぶ'},{action:'title',label:'タイトルへ',secondary:true}]);
    }});
  }
  function finishSound(cue){
    if(!audioCtx)return;
    if(cue==='draw'){note(146.83,.95,'triangle',.075);note(293.66,.65,'sawtooth',.025,.018);note(73.4,.8,'sine',.07);}
    if(cue==='cut'){
      const length=Math.floor(audioCtx.sampleRate*.18),buffer=audioCtx.createBuffer(1,length,audioCtx.sampleRate),samples=buffer.getChannelData(0);
      for(let i=0;i<length;i++)samples[i]=(Math.random()*2-1)*Math.pow(1-i/length,2);
      const source=audioCtx.createBufferSource(),filter=audioCtx.createBiquadFilter(),gain=audioCtx.createGain(),t=audioCtx.currentTime;
      source.buffer=buffer;filter.type='bandpass';filter.Q.value=.8;filter.frequency.setValueAtTime(4200,t);filter.frequency.exponentialRampToValueAtTime(450,t+.16);gain.gain.setValueAtTime(.23,t);gain.gain.exponentialRampToValueAtTime(.001,t+.18);
      source.connect(filter).connect(gain).connect(audioCtx.destination);source.start(t);source.stop(t+.2);
      source.onended=()=>{source.disconnect();filter.disconnect();gain.disconnect()};note(78,.34,'sine',.13,.025);note(196,.22,'triangle',.08,.01);
    }
    if(cue==='tail'){note(110,1.15,'triangle',.045);note(146.83,1.2,'sine',.025,.08);}
  }
  function formatTime(t){let s=Math.floor(t);return `${String(Math.floor(s/60)).padStart(2,'0')}:${String(s%60).padStart(2,'0')}`;}
  function updateGuard(g,dt){if(!g.alive)return;
    // Vision is never drawn; a visible direction cue comes from the character's heading.
    let d=dist(g,player),toward={x:(player.x-g.x)/(d||1),y:(player.y-g.y)/(d||1)},dot=toward.x*g.face.x+toward.y*g.face.y;
    if(!alarmTime&&d<(d<60?85:175)&&dot>(d<60?-.25:.43)&&clearLine(g.x,g.y,player.x,player.y))alert();
    if(!alarmTime&&g.state!=='chase'){for(let corpse of guards){if(corpse.alive||corpse===g||g.seenBodies.has(corpse))continue;let dc=dist(g,corpse),v={x:(corpse.x-g.x)/(dc||1),y:(corpse.y-g.y)/(dc||1)};if(dc<145&&(v.x*g.face.x+v.y*g.face.y)>.25&&clearLine(g.x,g.y,corpse.x,corpse.y)){g.seenBodies.add(corpse);g.state='search';g.investigate={x:corpse.x,y:corpse.y};g.searchUntil=elapsed+7;g.pathTick=0;break;}}}
    let dest;if(alarmTime||g.state==='chase'){g.state='chase';dest=player;}else if(g.state==='investigate'||g.state==='search'){dest=g.investigate;if(dist(g,dest)<24){g.state='search';if(elapsed>g.searchUntil){g.state='patrol';g.investigate=null;}else{g.face={x:Math.cos(elapsed*2+g.x),y:Math.sin(elapsed*2+g.x)};return;}}}else{dest=g.route[g.idx];if(dist(g,dest)<20){g.idx=(g.idx+1)%g.route.length;dest=g.route[g.idx];}}
    g.pathTick-=dt;if(g.pathTick<=0){g.path=pathfind(g,dest);g.pathTick=g.state==='chase'?.34:.8;}
    let waypoint=g.path[0]||dest;if(dist(g,waypoint)<17&&g.path.length>1){g.path.shift();waypoint=g.path[0];}let dx=waypoint.x-g.x,dy=waypoint.y-g.y,mag=Math.hypot(dx,dy);if(mag>2){g.face={x:dx/mag,y:dy/mag};move(g,g.face.x*g.speed,g.face.y*g.speed,dt);}art.sync(g,elapsed);
    if(alarmTime&&dist(g,player)<22){endGame();}
  }
  class Stage extends Phaser.Scene {constructor(){super('stage')}preload(){art.preload(this)}create(){scene=this;setupGrid();createMap();this.cameras.main.setBounds(0,0,art.bounds.width,art.bounds.height);this.cameras.main.centerOn(1050,610);this.keys=this.input.keyboard.addKeys('W,A,S,D,UP,DOWN,LEFT,RIGHT');this.input.keyboard.on('keydown-SPACE',e=>{e.preventDefault();strike()});this.input.keyboard.on('keydown-ENTER',e=>{if(mode==='playing'){e.preventDefault();strike()}});window.__yami={getState:()=>({mode,elapsed,alarmTime,guards:guards.length,alive:guards.filter(g=>g.alive).length,reinforcements:reinforcementCount,player:{x:player?.x,y:player?.y},target:{x:target?.x,y:target?.y}}),start:reset,movePlayer:(x,y)=>{if(player){player.x=x;player.y=y;art.sync(player,elapsed)}},routeLength:(a,b)=>pathfind(a,b).length,strike,alert};}
    update(_time,delta){if(mode!=='playing')return;let dt=Math.min(delta/1000,.05);elapsed+=dt;ui.timer.textContent=formatTime(elapsed);let keys=this.keys;let mx=joy.x+(keys.D.isDown||keys.RIGHT.isDown?1:0)-(keys.A.isDown||keys.LEFT.isDown?1:0),my=joy.y+(keys.S.isDown||keys.DOWN.isDown?1:0)-(keys.W.isDown||keys.UP.isDown?1:0),m=Math.hypot(mx,my);if(m>0){let direction=art.inverse(mx/m,my/m),length=Math.hypot(direction.x,direction.y);let vx=direction.x/length*115,vy=direction.y/length*115;move(player,vx,vy,dt);player.face={x:vx/115,y:vy/115};art.sync(player,elapsed);}
      for(let g of guards){updateGuard(g,dt);art.sync(g,elapsed);if(mode!=='playing')return;}art.sync(target,elapsed);if(alarmTime){alarmTime+=dt;if(alarmTime>=3){alarmTime-=3;reinforce();}}let can=target.alive&&dist(player,target)<62||guards.some(g=>g.alive&&dist(player,g)<59);ui.strike.disabled=!can;ui.strike.classList.toggle('ready',!!can);updateMusic(dt);
    }
  }
  const game=new Phaser.Game({type:Phaser.AUTO,parent:'game',width:VW,height:VH,backgroundColor:'#0b1420',render:{pixelArt:false,antialias:true},scale:{mode:Phaser.Scale.FIT,autoCenter:Phaser.Scale.CENTER_BOTH},scene:[Stage]});
  function screenAction(action){if(action==='begin'){changeScreen('第一話　悪代官の屋敷','庭園か渡り廊下を抜け、奥座敷の悪代官に接近せよ。',[{action:'play',label:'潜入する'},{action:'help',label:'遊び方',secondary:true}]);}else if(action==='help'){changeScreen('遊び方','左スティックで移動。右の「仕置」で近くの敵を倒す。<br>倒れた見張りの音や姿に仲間が反応する。<br>見つかると3秒ごとに2人の追っ手が増える。<br>PCは WASD／矢印キー＋Space または Enter。',[{action:'play',label:'潜入する'},{action:'title',label:'戻る',secondary:true}]);}else if(action==='play'||action==='retry'){initAudio();reset();}else if(action==='title'){changeScreen('闇の仕置人','月の下、悪を討つ。<br>見つかれば、追っ手は尽きない。',[{action:'begin',label:'遊戯開始'},{action:'help',label:'遊び方',secondary:true}]);}}
  ui.screen.addEventListener('click',e=>{let b=e.target.closest('button[data-action]');if(b)screenAction(b.dataset.action)});
  ui.strike.addEventListener('pointerdown',e=>{e.preventDefault();strike()});
  let pointerId=null;function resetStick(){ui.stick.style.transform='translate(0px,0px)';joy.x=joy.y=0;pointerId=null;}
  ui.joy.addEventListener('pointerdown',e=>{e.preventDefault();pointerId=e.pointerId;ui.joy.setPointerCapture(pointerId);joyMove(e)});ui.joy.addEventListener('pointermove',e=>{if(e.pointerId===pointerId)joyMove(e)});for(let event of ['pointerup','pointercancel','lostpointercapture'])ui.joy.addEventListener(event,e=>{if(e.pointerId===pointerId)resetStick()});
  function joyMove(e){let b=ui.joy.getBoundingClientRect(),cx=b.left+b.width/2,cy=b.top+b.height/2,dx=e.clientX-cx,dy=e.clientY-cy,max=b.width*.33,length=Math.hypot(dx,dy),ratio=Math.min(1,length/max);joy.x=length?dx/length*ratio:0;joy.y=length?dy/length*ratio:0;ui.stick.style.transform=`translate(${joy.x*max}px,${joy.y*max}px)`;}
  function initAudio(){try{audioCtx??=new (window.AudioContext||window.webkitAudioContext)();audioCtx.resume();}catch(_e){}}
  function note(freq,duration=.15,type='sine',volume=.07,delay=0){if(!audioCtx)return;let t=audioCtx.currentTime+delay,osc=audioCtx.createOscillator(),gain=audioCtx.createGain();osc.type=type;osc.frequency.setValueAtTime(freq,t);gain.gain.setValueAtTime(.0001,t);gain.gain.exponentialRampToValueAtTime(volume,t+.014);gain.gain.exponentialRampToValueAtTime(.0001,t+duration);osc.connect(gain).connect(audioCtx.destination);osc.start(t);osc.stop(t+duration+.03);}
  function sound(id){if(!audioCtx)return;if(id==='start'){note(294,.32,'triangle');note(440,.34,'triangle',.035,.17);}if(id==='guard'){note(160,.12,'sawtooth',.09);note(90,.28,'triangle',.08,.06);}if(id==='spotted'){note(620,.17,'square',.07);note(830,.24,'square',.06,.16);}if(id==='reinforce'){note(100,.23,'sawtooth',.07);note(115,.21,'sawtooth',.06,.15);}if(id==='caught'){note(150,.45,'sawtooth',.13);note(72,.8,'triangle',.08,.15);}if(id==='shamisen'){note(196,.85,'sawtooth',.08);note(392,.75,'triangle',.035,.02);}if(id==='slash'){note(580,.08,'sawtooth',.18);note(120,.35,'square',.1,.07);}if(id==='final'){note(146,.9,'triangle',.09);note(220,.6,'triangle',.05,.18);}}
  function updateMusic(dt){if(!audioCtx)return;musicAt-=dt;if(musicAt>0)return;if(alarmTime){let seq=[147,175,196,233,196,175];let n=Math.floor(elapsed*3)%seq.length;note(seq[n],.22,'sawtooth',.024);note(seq[n]/2,.29,'triangle',.035);musicAt=.32;}else{let seq=[147,196,220,196,165,147,110,147],n=Math.floor(elapsed/1.2)%seq.length;note(seq[n],.5,'triangle',.025);if(n%4===0)note(73.5,.8,'sine',.02);musicAt=1.2;}}
})();
