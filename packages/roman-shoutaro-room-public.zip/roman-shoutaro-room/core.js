'use strict';
const Core=(()=>{
const DAY=86400000;
function fresh(now=Date.now()){return {version:1,first:now,points:0,outfits:[0],outfit:0,album:{},events:[],counts:{},settings:{hourly:true,sound:false,motion:true},catGifts:[],photos:0,lastCommand:null,visits:1};}
function level(p){return p>=1000?4:p>=600?3:p>=300?2:p>=100?1:0;}
function elapsed(s,now=Date.now()){return Math.max(0,now-s.first)/DAY;}
function gift(s,index,days,now=Date.now()){if(!Number.isInteger(index)||index<1||index>4||s.outfits.includes(index)||elapsed(s,now)<days)return false;s.outfits.push(index);s.outfit=index;s.points+=20;return true;}
function restore(raw,now=Date.now()){let d;try{d=JSON.parse(raw)}catch{return fresh(now)}if(!d||typeof d!=='object'||!Number.isFinite(d.first)||d.first<=0)return fresh(now);let s={...fresh(now),...d};s.points=Number.isFinite(d.points)?Math.max(0,d.points):0;s.outfits=Array.isArray(d.outfits)?[...new Set([0,...d.outfits.filter(x=>Number.isInteger(x)&&x>=0&&x<5)])]:[0];s.outfit=s.outfits.includes(d.outfit)?d.outfit:0;s.settings={...fresh(now).settings,...d.settings};s.album=d.album&&typeof d.album==='object'?d.album:{};s.events=Array.isArray(d.events)?d.events:[];s.counts=d.counts&&typeof d.counts==='object'?d.counts:{};s.catGifts=Array.isArray(d.catGifts)?d.catGifts:[];return s;}
function weights(hour){let w=[5,5,3,2,3,2,4,3,2,3,2,2];if(hour<6||hour>=22)w=[1,1,1,35,3,1,1,1,1,1,2,5];else if(hour===15)w[5]=25;else if(hour>=16&&hour<19){w[7]=12;w[1]=9}return w;}
function weighted(weights,r=Math.random()){let n=r*weights.reduce((a,b)=>a+b,0);for(let i=0;i<weights.length;i++){n-=weights[i];if(n<0)return i}return weights.length-1;}
function route(graph,start,end){if(start===end)return [];const q=[[start]],seen=new Set([start]);while(q.length){const path=q.shift(),node=path.at(-1);for(const n of graph[node].links){if(seen.has(n))continue;const p=[...path,n];if(n===end)return p.slice(1);seen.add(n);q.push(p)}}return [];}
return {DAY,fresh,level,elapsed,gift,restore,weights,weighted,route};
})();
if(typeof module!=='undefined')module.exports=Core;
