import {REVENUE_EVENTS,LATE_EVENTS,PROJECTS,ACHIEVEMENTS} from './endless.mjs';
export {PROJECTS,ACHIEVEMENTS};
import {DOCTRINES,EXTRA_ACTIONS,EXTRA_EVENTS} from './expansion.mjs';
import {hair,clothes,visual,special} from './visual-state.mjs';
export {DOCTRINES};
export const ACTIONS=[
['駅前でありがたいことを言う','ひとまず、声を出してみる。',1.22,1.02,1.05,1.01,1,'「足元にお気をつけて」\n信者「人生の足元、ですね……」'],
['SNSで意味深なことを言う','届くか、燃えるか。',1.36,1.04,1.04,1.02,1.05,'「今日は、今日です」\nなぜか保存されている。','sns'],
['山にこもる','少し離れて、神秘を育てる。',0.98,0.94,0.99,1.12,0.97,'電波が届かない。\n信者「俗世との交信を絶たれた」'],
['滝に打たれる','冷たさの先に、何かある。',1.15,0.95,1.02,1.09,0.99,'「つめたい！」\n信者は新たな真言を書き留めた。'],
['本を書く','言葉が一冊の教えになる。',1.25,1.15,1.05,1.03,1.02,'日記をまとめただけなのに、\n帯には「人類待望の書」。','book'],
['白い服を着る','形から入ってみる。',1.12,0.96,1.02,1.06,1,'ただの洗い替え。\n信者「新たな境地に達したのですね」'],
['信者と食事会','お腹と距離を満たす。',1.18,0.94,1.09,0.98,0.96,'「おかわりありますよ」\n今日いちばんの歓声が上がった。'],
['無言で過ごす','言わないことにも意味がつく。',1.13,1.01,0.98,1.1,1.02,'何も思いつかなかった。\n信者「これは深い」'],
['予言する','未来は、まだ分からない。',1.12,1.02,1.01,1.05,1.04,'「近いうちに、何かが起きます」\nみんな真剣にうなずいた。','prophecy'],
['グッズを作る','ありがたさを、お持ち帰り。',1.16,1.28,1.03,0.98,1.05,'「普通のタオルです」\n信者「普通を超越したタオル……」','goods'],
['動画配信する','画面の向こうへ、お言葉を。',1.3,1.1,1.06,0.99,1.04,'設定ミスで30分天井を配信。\n「天を見よ」という解釈が広まった。','sns'],
['全国行脚する','知らない町で、こんにちは。',1.4,0.86,1.08,1.04,1.01,'道を聞いただけで、\n人生の道を聞き返された。'],
['信者と掃除をする','まずは、目の前のゴミから。',1.13,0.98,1.06,0.99,0.9,'「そこのホコリもお願い」\n信者「心のホコリですね」'],
['瞑想会を開催する','静かな時間をみんなで。',1.2,1.08,1.02,1.08,0.98,'寝息が聞こえた。\nみんな同じ呼吸を始めた。'],
['握手会をする','手の温もりを届ける。',1.24,1.1,1.08,0.98,1.01,'「手、冷たいですね」\n信者「心を温めよとのお告げだ」'],
['ありがたい写真を撮る','とりあえず、遠くを見る。',1.23,1.06,1.03,1.07,1.03,'カメラの向こうにコンビニ。\n信者「遥かなる未来を見ている」'],
['悩み相談に乗る','話を聞くだけでも、いい。',1.15,1.04,1.1,0.97,0.93,'「それは大変でしたね」\n今日は少し、役に立てた気がした。'],
['講演会をする','マイクを握ると、それらしい。',1.28,1.18,1.07,1.01,1.03,'「後ろ、聞こえますか？」\n信者「見えぬ者への慈愛……」'],
['謎の儀式を考える','理由はあとからついてくる。',1.24,0.95,1.01,1.12,1.09,'右に二歩、左に二歩。\n結局、元の場所に戻った。'],
['何もしない','普通の一日を過ごす。',0.97,1,1,1.02,0.95,'ずっとプリンを食べていた。\n信者「無為の境地だ」']
].map((a,id)=>({id,name:a[0],hint:a[1],f:a[2],m:a[3],c:a[4],y:a[5],s:a[6],text:a[7],tag:a[8]})).concat(EXTRA_ACTIONS);
const E=(id,name,text,f=1,m=1,c=1,y=1,s=1,extra={})=>({id,name,text,f,m,c,y,s,kind:id<=30?'normal':id<=40?'rare':'crash',...extra});
export const EVENTS=[
E(1,'後光','写真を撮ったら、ちょうど太陽が背後にあった。\n信者「後光だ……！」',1.15,1,1,1.08,1),
E(2,'猫に選ばれる','野良猫が膝に乗った。\n「動物には分かるんですね」',1.1,1,1,1.05,1),
E(3,'虹が出た','外に出た瞬間、虹がかかった。\n「空まで祝福を……」',1.2,1,1,1.1,1),
E(4,'鳩が舞い降りる','説法中、白い鳩が舞い降りた。\n「お使いだ……」',1.15,1,1,1.08,1),
E(5,'教祖、寝坊','集会に90分遅刻。\n「……深い瞑想をしていました」',0.98,1,1,1.02,1.03),
E(6,'教祖、風邪をひく','くしゃみが止まらない。\n信者「我々の厄を引き受けてくださった！」',1.05,1,1,1.05,1),
E(7,'沈黙の教え','質問に答えられず黙る。\n信者「言葉を超えた教えだ」',1.1,1,1,1.08,1),
E(8,'盛大に噛む','説法で言葉を噛んだ。\n信者はその言葉を新しい教義として記録した。',1.05,1,1,1.04,1),
E(9,'聖なる石','道端の石を拾った。\n翌日には「聖石」と呼ばれていた。',1.1,1,1,1.07,1),
E(10,'聖なるプリン','好きな食べ物は「プリン」。\n翌月からプリンがお供えされる。',1.05,1.02,1,1,1),
E(11,'聖地誕生','座っただけの公園のベンチが聖地になった。',1.12,1,1,1.05,1),
E(12,'教祖のサイン','何となく書いた丸が「宇宙の象徴」になった。',1.08,1,1,1.06,1),
E(13,'今日の一言','「無理しなくていい」\n言っただけなのに、信者が泣いた。',1.12,1,1.04,1,1),
E(14,'手料理','教祖がカレーを作った。\n信者「悟りの味だ……」',1.08,1,1.05,1,1),
E(15,'街で握手','買い物中、信者に囲まれた。\n今日は卵が安いのに。',1.1,1,1.05,1,1),
E(16,'子どもに好かれる','子どもが突然抱きついた。\n「小さな者にも伝わるのですね」',1.15,1,1.04,1.03,1),
E(17,'いいことを言う','「人には優しくしましょう」\n信者「深い……」',1.08,1,1.05,1,1),
E(18,'教祖の落書き','暇つぶしの落書きが公式シンボルになった。',1.06,1,1,1.03,1),
E(19,'切り抜き動画','15秒の動画がバズった。\n一番伸びたのは、あくびの場面。',1.2,1,1.03,1,1.02,{sns:true}),
E(20,'勝手にファンクラブ','信者が無断でファンクラブを作った。\n本人も会費を払うらしい。',1.15,1.05,1,1,1),
E(21,'非公式グッズ','顔入りタオルが販売された。\n「写真、いつ撮ったの？」',1.08,1.1,1,1,1.03,{goods:true}),
E(22,'誕生日','誕生日が「降臨祭」と呼ばれる。\nケーキだけは、普通だった。',1.15,1.05,1,1.05,1),
E(23,'同級生登場','「こいつ昔から普通だったよ」\n場が、少し静かになった。',0.92,1,1,0.92,1.06),
E(24,'母親登場','「この子、昔は朝ぜんぜん起きなくてねぇ」',0.95,1,1.02,0.95,1),
E(25,'昔の写真','ジャージ姿の写真が発掘された。\n後光は、まだない。',0.95,1,1,0.96,1.04),
E(26,'教祖、スマホをなくす','「これは物質への執着を捨てよという啓示です」\nその後、必死に探した。',1.03,1,1,1.04,1),
E(27,'雨が止む','集会直前に雨が止んだ。\n信者「やはり……」',1.15,1,1,1.08,1),
E(28,'くしゃみ三回','くしゃみが三回続いた。\n「三度の啓示」と命名された。',1.05,1,1,1.04,1),
E(29,'教祖不在','休んだのに集会が成立した。\nむしろ、いつもより盛り上がった。',1.1,1,1,1,0.98),
E(30,'教義の解釈違い','信者同士が教義について激論。\n「そんな深い意味ないけど……」',1.05,1,1,1.05,1.02),
E(31,'完全予言的中','あの日の予言が完全的中。\n「言った本人が一番驚いてます」',3,1,1,1.25,0.9,{prereq:'prophecy',success:true}),
E(32,'世界的バズ','寝起きの一言が、世界を一周した。',2,1,1.1,1,1,{sns:true,overseas:true}),
E(33,'海外スターが引用','海の向こうのスターが教えを引用。\n翻訳は、だいぶ違う。',2.5,1,1.12,1,1,{overseas:true}),
E(34,'奇跡の写真','光に包まれた姿が撮れた。\n「逆光じゃないの？」',1.8,1,1,1.18,1),
E(35,'聖地に大行列','あのベンチに大行列。\n座りたいだけの人が困っている。',1.75,1.2,1,1,1,{prereq:11}),
E(36,'著書がベストセラー','日記がベストセラーになった。\n誤字にも深い意味があるらしい。',1.7,1.5,1.08,1,1,{prereq:'book'}),
E(37,'大物が入信','名の知れた大物が入信した。\n「何を期待されているんだろう」',2,1,1,1,1.05),
E(38,'謎の天体現象','夜空に不思議な光。\n教祖はそのとき、お風呂にいた。',2,1,1,1.15,1),
E(39,'国境を越える教え','知らない国から感謝の手紙。\n読めない。でもありがたい。',2.5,1,1,1.1,1.05,{prereq:'overseas',overseas:true}),
E(40,'教祖そっくりの雲','空いっぱいに、あの顔。\n「寝癖まで似てる……」',3,1,1,1.2,1,{weight:.08}),
E(41,'聖なる石398円','ホームセンターで同じ石が398円。\n「領収書、あります？」',0.6,1,1,0.8,1.2,{prereq:9}),
E(42,'昔のSNS発掘','「仕事行きたくねえ」\nという投稿が発掘された。',0.8,1,1,0.9,1.15),
E(43,'予言大ハズレ','何も起きなかった。\n「平和だった、ということで……」',0.65,1,1,0.85,1.2,{prereq:'prophecy',failure:true}),
E(44,'奇跡の正体','あの写真、レンズフレアと判明。\nカメラ屋さんが説明してくれた。',0.7,1,1,0.8,1.2,{prereq:34}),
E(45,'元恋人インタビュー','「普通の人ですよ。餃子好きでした」',0.85,1,1,0.9,1.15),
E(46,'教祖、競馬場にいる','「無欲」を説いた翌日に発見。\n「馬を見に来ただけです」',0.75,1,1,1,1.25),
E(47,'教義が矛盾する','昨日と正反対のことを言ってしまった。\n「いや、普通に間違えたんだけど」',0.85,1,1,1,1.15),
E(48,'弟子の暴走','弟子が勝手に「教祖さまの真意」を語る。\n「僕にも教えてほしい」',0.9,1,1,1,1.2),
E(49,'大炎上','一言が大きく切り取られた。\n通知が、鳴り止まない。',0.5,1,1,1,1.3),
E(50,'説明してください教祖さま','集まったマイク。押し寄せる質問。\nどう答えますか？',1,1,1,1,1,{special:true})].concat(EXTRA_EVENTS,LATE_EVENTS,REVENUE_EVENTS);
export const pick=(xs,r=Math.random)=>xs[Math.floor(r()*xs.length)];
export function fresh(name,r=Math.random){return {name:name.trim().slice(0,16)||'田中',f:10n,m:100000n,c:10n,y:10n,s:10n,meterFractions:{c:0n,y:0n,s:0n},schema:4,achievements:{},projectCounts:{},activeProject:null,snsEvents:0,scheduled:[],month:0,doctrine:Math.floor(r()*DOCTRINES.length),level:0,history:{},last:{},actions:{},pendingProphecy:0,success:0,failure:0,sns:0,goods:0,overseas:0,log:[],ended:0};}
// BigInt whole values with 4 decimal places retained separately for meters.
export function mult(n,k){return (n*BigInt(Math.round(k*10000))+5000n)/10000n;}
export function apply(s,e,{fixedCost=false}={}){
 if(s.ended)return;
 s.f=mult(s.f,e.f??1);if(s.f<1n)s.f=1n;
 s.m=mult(s.m,fixedCost?(e.m??1):1+((e.m??1)-1)*.75);if(s.m<1n)s.m=1n;
 s.meterFractions??={};
 for(const k of ['c','y','s']){
  let raw=typeof s[k]==='bigint'?s[k]*10000n+(s.meterFractions[k]||0n):BigInt(Math.round(Math.max(1,s[k])*10000));
  raw=mult(raw,e[k]??1);if(raw<10000n)raw=10000n;
  s[k]=raw/10000n;s.meterFractions[k]=raw%10000n;
 }
}
export const level=hair;
export const stage=hair;
export const wealth=clothes;
export function title(s){
 const ranks=[[1000000000n,'宇宙そのもの'],[100000000n,'全宇宙教祖'],[30000000n,'宇宙大聖人'],[10000000n,'地上神'],[3000000n,'大現人神'],[1000000n,'現人神'],[300000n,'大聖人'],[100000n,'救世主'],[30000n,'聖人'],[10000n,'大尊師'],[3000n,'尊師'],[1000n,'聖導師'],[300n,'大導師'],[100n,'導師'],[50n,'師'],[20n,'導き手'],[0n,'先生']];
 const x=special(s);let base=x.scandal?'渦中の救世主':x.poor?'清貧の救世主':x.rich?'黄金の先生':ranks.find(([n])=>s.f>=n)[1];
 const p=[];if(x.floating)p.push('浮遊する');else if(s.success>=3)p.push('天啓を受けし');else if(s.y>=80)p.push('天啓の');else if(s.y>=60)p.push('神秘の');
 if(!x.scandal&&s.s>=80)p.push('渦中の');if(!x.rich&&!x.poor&&s.m>=100000000n)p.push('黄金の');if(s.c>=80)p.push('偉大なる');if(x.social)p.push('百万再生の');if(s.f>=3000000n)p.push('大宇宙');return '超'.repeat(superCount(s.f))+p.join('')+base;
}
export const fullName=s=>title(s)==='先生'?s.name+'先生':title(s)+'・'+s.name;
export const doctrine=s=>DOCTRINES[s.doctrine][s.level];
export function candidates(r=Math.random,s=null){const a=ACTIONS.filter(x=>x.id!==38||!s||s.lastFestival===undefined||s.month-s.lastFestival>=11);for(let i=a.length-1;i>0;i--){const j=Math.floor(r()*(i+1));[a[i],a[j]]=[a[j],a[i]];}const out=a.slice(0,3);if(!out.some(x=>x.m>=1.15))out[2]=pick(a.filter(x=>x.m>=1.15),r);return out;}
function followerFactor(s,f){if(f<1&&(s.actions.ranks||s.actions.newspaper))f=1-(1-f)*.65;if(f<1&&s.actions.disciples)f=1-(1-f)*.85;if(f>1&&s.actions.branches)f*=1.05;return f;}
export function act(s,id,r=Math.random){
 if(s.ended)throw Error('この教祖さまの物語は終了しました');
 const a=ACTIONS.find(x=>x.id===id);if(!a)throw Error('活動が見つかりません');if(id===38&&s.lastFestival!==undefined&&s.month-s.lastFestival<11)throw Error('大祭は一年に一度です');s.month++;
 const range=(v,span,jitter)=>+(span?span[0]+r()*(span[1]-span[0]):v*(1-jitter+r()*jitter*2)).toFixed(4);
 let e={...a,f:range(a.f,a.fRange,.13),m:range(a.m,a.mRange,.04),c:range(a.c,null,.01)};
 if(id===31&&r()<.12){e.s=1.18;e.text+='\n話が少し、盛られていた。';}
 if(id===37&&r()<.3){e.f=.8;e.text+='\n「決まりが多い」と帰る人もいた。';}
 if(id===38){s.lastFestival=s.month;const success=r()<Math.min(.9,.45+Number(s.c>250n?250n:s.c)/250);e=success?{...e,f:1.5+r()*.5,m:1.3}:{...e,f:.95,m:.5,text:'大祭の日に大雨。\n会場と弁当だけが、盛大に余った。'};}
 if(s.actions.choir&&[13,17,38].includes(id)&&e.f>1)e.f*=1.08;
 if(s.actions.holyItems&&['goods','stickers','mascot'].includes(a.tag)&&e.m>1)e.m*=1.15;
 e.f=followerFactor(s,e.f);apply(s,e);
 s.actions[a.tag||a.id]=(s.actions[a.tag||a.id]||0)+1;
 if(a.tag==='prophecy')s.pendingProphecy++;if(a.tag==='goods'||a.tag==='stickers')s.goods++;if(a.tag==='sns'&&e.f>=1.3)s.sns++;
 if(r()<(id===20?.45:s.actions.sacredWord?.06:.02))s.doctrineAdvance=true;
 return e;
}
export function eligible(s,e){
 if(e.kind==='income'||e.scheduledOnly)return false;
 if(e.minC&&s.c<e.minC||e.minY&&s.y<e.minY||e.minS&&s.s<e.minS)return false;if(s.last[e.id]!==undefined&&s.month-s.last[e.id]<=6)return false;
 if(e.id===50&&s.s<80)return false;
 if(e.minFollowers&&s.f<e.minFollowers)return false;
 if(e.requires&&!s.history[e.requires]&&!(e.unlock&&s.actions[e.unlock]))return false;
 if(e.requireTag&&!s.actions[e.requireTag]&&!(e.requireTag==='goods'&&s.goods))return false;
 if(e.requireAnyTags&&!e.requireAnyTags.some(k=>s.actions[k]))return false;
 if(typeof e.prereq==='number'&&(!s.history[e.prereq]||s.month-s.last[e.prereq]<3))return false;
 if(e.prereq==='prophecy'&&!s.pendingProphecy)return false;if(e.prereq==='book'&&!s.actions.book)return false;if(e.prereq==='overseas'&&!s.overseas)return false;return true;
}
export function eventWeight(s,e){let weight=e.weight??1;if(s.actions.quotations&&e.id===47)weight*=3;if(s.actions.disciples&&[48,71,72,73].includes(e.id))weight*=3;if(s.actions.branches&&[75,76,77,78].includes(e.id))weight*=3;if(s.actions.successor&&[72,73,74,48].includes(e.id))weight*=5;return weight;}
export function drawEvent(s,r=Math.random){
 const due=(s.scheduled||[]).find(x=>x.month<=s.month);if(due){s.scheduled=s.scheduled.filter(x=>x!==due);return EVENTS.find(e=>e.id===due.id);}
 if(s.f>=1000000000000000n&&s.month%12===0){const era=s.f.toString().length-14;return {id:'frontier-'+s.month,name:'第'+era+'宇宙圏への進出',text:'新しい世界にも、集会の予定ができた。\n教祖「また会場が増えたの？」',f:2,m:2,c:1.15,y:1.2,s:1.1,kind:'rare'};}
 if(r()>=.8)return null;const n=r(),risk=Math.min(.3,.15+Math.max(0,s.s.toString().length-2)*.01),kind=n<.65?'normal':n<1-risk?'rare':'crash';const pool=EVENTS.filter(e=>e.kind===kind&&eligible(s,e));if(!pool.length)return null;let v=r()*pool.reduce((n,e)=>n+eventWeight(s,e),0);return pool.find(e=>(v-=eventWeight(s,e))<0)||pool.at(-1);
}
export function event(s,event){
 if(s.ended)throw Error('この教祖さまの物語は終了しました');
 let e={...event};s.history[e.id]=(s.history[e.id]||0)+1;s.last[e.id]=s.month;
 if(e.id===47&&s.y>=80)e={...e,f:1.2,s:1,text:'信者「矛盾しているように見えること自体が教えなのでは？」\n教祖「いや、普通に間違えたんだけど」'};
 if(e.id===48&&s.c>=80)e={...e,f:1.1,s:1,text:'弟子の暴走も、ひと言で収まった。\n信者「やはり教祖さまのお言葉が一番」'};
 if(e.id===87)e={...e,f:.8+Number(s.c>100n?100n:s.c<0n?0n:s.c)*.008,text:s.c>=60?'密着番組で、飾らない言葉が届いた。\n教祖「いつも通り話しただけです」':'緊張して、ほとんど話せなかった。\n番組の大半は、沈黙だった。'};
 if(e.special)return e;e.f=followerFactor(s,e.f);apply(s,e);
 if(e.followup){s.scheduled??=[];s.scheduled.push({id:e.followup,month:s.month+1});}
 if(e.success){s.success++;s.pendingProphecy--;}if(e.failure){s.failure++;s.pendingProphecy--;}
 if(e.sns){s.sns++;s.snsEvents=(s.snsEvents||0)+1;}if(e.goods)s.goods++;if(e.overseas)s.overseas++;return e;
}
export function explain(s,id){
 if(s.ended)throw Error('この教祖さまの物語は終了しました');const options=[s.c>=80?{f:1.5,s:0.8,c:1.05,text:'堂々と説明した。\n「説明する姿まで、ありがたい……」'}:{f:.6,s:1.15,text:'質問が質問を呼んだ。\n「すみません、一つずつお願いします」'},{f:.85,y:1.2,s:0.95,text:'静かに山へ入った。\n麓では、解釈だけが増えていた。'},s.y>=80?{f:1.8,y:1.1,s:1.05,text:'信者「我々の信仰が試されている！」\n「そこまでは言ってないです」'}:{f:.5,s:1.2,text:'「誰にとっての試練ですか？」\n答えは、出なかった。'}];if(!options[id])throw Error('選択してください');apply(s,options[id]);return options[id];}
export function evolve(s){const previous=s.level;s.level=Math.min(9,Math.max(s.level,level(s))+(s.doctrineAdvance?1:0));s.doctrineAdvance=false;return previous!==s.level;}
export function format(n){n=BigInt(n);const units=['','万','億','兆','京','垓','秭','穣','溝','澗','正','載','極'];if(n<10000n)return n.toLocaleString('ja-JP');let u=0,d=1n;while(n/d>=10000n){d*=10000n;u++;}if(u>=units.length)return n.toString().slice(0,4)+'…（'+n.toString().length+'桁）';const a=n/d,b=(n%d)*100n/d;return a.toLocaleString('ja-JP')+(b?'.'+b.toString().padStart(2,'0').replace(/0$/,''):'')+units[u];}
export const age=s=>Math.floor(s.month/12)+'年'+s.month%12+'か月';
export const serialize=s=>JSON.stringify(s,(_,v)=>typeof v==='bigint'?{$bigint:v.toString()}:v);
export const deserialize=t=>JSON.parse(t,(_,v)=>v&&typeof v==='object'&&'$bigint'in v?BigInt(v.$bigint):v);

export function upgrade(s){
 if(!s)return s;
 if(!s.schema||s.schema<2){s.level=Math.max([0,2,3,5,6][s.level]??0,hair(s));s.snsEvents=[19,32,68,82].reduce((n,id)=>n+(s.history[id]||0),0);}
 s.meterFractions??={};for(const k of ['c','y','s'])if(typeof s[k]!=='bigint'){
 const raw=BigInt(Math.round(Math.max(1,Number(s[k])||10)*10000));s[k]=raw/10000n;s.meterFractions[k]=raw%10000n;
 }
 if((s.schema||0)<4)s.ended=0;
 s.schema=4;s.ended??=0;s.scheduled??=[];s.visualShown??=visual(s);s.achievements??={};s.projectCounts??={};s.activeProject??=null;
 if(s.m<1n)s.m=1n;
 return s;
}
export const superCount=n=>Math.max(0,n.toString().length-9);
export function income(s,r=Math.random){
 if(s.ended)throw Error('この教祖さまの物語は終了しました');
 const eligible=REVENUE_EVENTS.filter(e=>s.f>=e.minFollowers&&(s.last[e.id]===undefined||s.month-s.last[e.id]>3));
 const e=pick(eligible.length?eligible:REVENUE_EVENTS.slice(0,4),r);return event(s,e);
}
export function projectOffer(s,p){
 const count=s.projectCounts?.[p.id]||0,scale=10n**BigInt(count);
 const f=p.f*scale,m=p.m*scale,c=(p.c||0n)*scale,y=(p.y||0n)*scale;
 return {...p,edition:count+1,need:{f,m,c,y},available:s.f>=f&&s.m>=m&&s.c>=c&&s.y>=y};
}
export function beginProject(s,id){
 if(s.ended)throw Error('この教祖さまの物語は終了しました');
 const p=PROJECTS.find(p=>p.id===id);if(!p)throw Error('計画が見つかりません');
 if(s.activeProject)throw Error('進行中の計画があります');const offer=projectOffer(s,p);if(!offer.available)throw Error('開始条件を満たしていません');
 apply(s,{m:p.cost},{fixedCost:true});s.activeProject={id,edition:offer.edition,progress:0,started:s.month};return offer;
}
export function progressProject(s){
 if(s.ended||!s.activeProject)return null;const active=s.activeProject,p=PROJECTS.find(p=>p.id===active.id);
 active.progress++;if(active.progress<p.turns)return null;
 apply(s,p.reward);s.projectCounts[p.id]=(s.projectCounts[p.id]||0)+1;s.activeProject=null;
 return {name:p.name+'・第'+active.edition+'期 完成！',text:p.done+'\n次の規模の計画が開かれました。',kind:'project',label:'大型プロジェクト完成',sound:'rare'};
}
export function awards(s){
 const found=[];s.achievements??={};const grant=(id,name)=>{if(!s.achievements[id]){s.achievements[id]={name,month:s.month};found.push(name);}};
 for(const a of ACHIEVEMENTS){if(a.test?a.test(s):a.project?(s.projectCounts[a.project]||0)>0:s[a.key]>=a.n)grant(a.id,a.name);}
 const labels={f:'救世主',m:'財界教祖',c:'カリスマ教祖',y:'神秘の導師',s:'疑惑の中心'};
 for(const k of Object.keys(labels)){
  const digits=s[k].toString().length;
  // Past digit milestones remain earned after setbacks; no finite last milestone.
  const first={f:10,m:14,c:6,y:6,s:6}[k];
  for(let d=first;d<=digits;d++){const n=10n**BigInt(d-1);grant('digit-'+k+'-'+d,d>=10?'超'.repeat(d-9)+labels[k]:format(n)+'の'+labels[k]);}
 }
 for(const p of PROJECTS){const n=s.projectCounts[p.id]||0;if(n>1)grant('repeat-'+p.id+'-'+n,p.name+'・第'+n+'期の開拓者');}
 return found;
}
export function nextMilestones(s){
 return ['f','m','c','y','s'].map((key,i)=>{
  const a=ACHIEVEMENTS.find(a=>a.key===key&&s[key]<a.n);
  return {key,label:['信者','資金','カリスマ','神秘性','疑惑'][i],target:a?.n??10n**BigInt(s[key].toString().length),name:a?.name??(s[key].toString().length>=9?'超'.repeat(s[key].toString().length-8)+['救世主','財界教祖','カリスマ教祖','神秘の導師','疑惑の中心'][i]:format(10n**BigInt(s[key].toString().length))+'の'+['救世主','財界教祖','カリスマ教祖','神秘の導師','疑惑の中心'][i])};
 });
}

export function declareHuman(s){
 if(s.ended)return;
 s.ended='human';s.specialPending=false;
 s.log.unshift({month:s.month,name:'人間宣言',text:'私は、ただの人間です。教祖としての物語に、幕を下ろした。'});
 s.log=s.log.slice(0,150);
}
