// Retry temporary image failures without touching game state or saved progress.
export function installImageRecovery(root) {
  const attempts = new WeakMap();
  root.addEventListener('error', event => {
    const img = event.target;
    if (img?.tagName !== 'IMG' || !img.hasAttribute('data-scene-image')) return;
    const attempt = attempts.get(img) || 0;
    if (attempt >= 3) return;
    attempts.set(img, attempt + 1);
    setTimeout(() => {
      if (!img.isConnected) return;
      const url = new URL(img.src);
      url.searchParams.set('retry', String(attempt + 1));
      img.src = url.href;
    }, [250, 1000, 2500][attempt]);
  }, true);
}
