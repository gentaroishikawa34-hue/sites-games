(function(root){
const random=()=>{const a=new Uint32Array(1);crypto.getRandomValues(a);return a[0]/4294967296};
function role(d){let a=[...d].sort();if(a[0]===a[2])return a[0]===1?{name:'ピンゾロ',rank:10,mult:5}:{name:'ゾロ目',rank:9,mult:3};if(a.join('')==='456')return {name:'シゴロ',rank:8,mult:2};if(a.join('')==='123')return {name:'ヒフミ',rank:-1,mult:2};if(a[0]===a[1])return {name:a[2]+'の目',rank:a[2],mult:1};if(a[1]===a[2])return {name:a[0]+'の目',rank:a[0],mult:1};return {name:'役なし',rank:0,mult:1}}
function settle(p,c,bet,money){let sign=Math.sign(p.rank-c.rank);let mult=sign?Math.max((sign>0?p:c).mult,(sign>0?c:p).rank===-1?2:1):0;let delta=sign>0?BigInt(bet)*BigInt(mult):sign<0?-(BigInt(bet)*BigInt(mult)>money?money:BigInt(bet)*BigInt(mult)):0n;return {sign,mult,delta,money:money+delta}}
const rate=s=>Math.min(80,5+s*.75);
const cheat=(s,r=random)=>({caught:r()<rate(s)/100,suspicion:Math.min(100,s+30)});
const cool=s=>Math.max(0,s-5);
const canLeave=(r=random)=>r()<.5;
const dice=(r=random)=>Array.from({length:3},()=>1+Math.floor(r()*6));
const E={random,role,settle,rate,cheat,cool,canLeave,dice};if(typeof module!=='undefined')module.exports=E;else root.Engine=E;
})(globalThis);
