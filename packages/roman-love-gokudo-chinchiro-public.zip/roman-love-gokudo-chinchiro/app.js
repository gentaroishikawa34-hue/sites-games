'use strict';
const $=id=>document.getElementById(id),E=Engine;let state,busy=false,phase='title',bgm=false,sfx=true,ctx,timer,cutResolve;
const fmt=n=>n.toLocaleString('ja-JP'),signed=n=>(n>0n?'+':n===0n?'±':'')+fmt(n)+' 両';
let caughtBufferPromise,caughtSource,caughtPlayback=0;
function loadCaughtVoice(){if(!ctx)return;if(!caughtBufferPromise)caughtBufferPromise=fetch('assets/cheat-caught.mp3').then(r=>{if(!r.ok)throw new Error('Voice unavailable');return r.arrayBuffer()}).then(data=>ctx.decodeAudioData(data)).catch(()=>{caughtBufferPromise=null;return null});return caughtBufferPromise}
function stopCaughtVoice(){caughtPlayback++;if(caughtSource){caughtSource.stop();caughtSource.disconnect();caughtSource=null}}
async function playCaughtVoice(){stopCaughtVoice();if(!sfx)return;audio();const playback=caughtPlayback,buffer=await loadCaughtVoice();if(playback!==caughtPlayback||!sfx)return;if(!buffer||ctx?.state!=='running'){effect('shock');return}const source=ctx.createBufferSource();source.buffer=buffer;source.connect(ctx.destination);caughtSource=source;source.onended=()=>{source.disconnect();if(caughtSource===source)caughtSource=null};source.start()}
function audio(){if(!ctx)try{ctx=new (window.AudioContext||window.webkitAudioContext)()}catch{}if(ctx?.state==='suspended')ctx.resume().catch(()=>{});loadCaughtVoice()}
function tone(freq,dur=.12,volume=.05,type='triangle'){if(!ctx||ctx.state!=='running')return;const o=ctx.createOscillator(),g=ctx.createGain();o.type=type;o.frequency.value=freq;g.gain.setValueAtTime(volume,ctx.currentTime);g.gain.exponentialRampToValueAtTime(.0001,ctx.currentTime+dur);o.connect(g).connect(ctx.destination);o.start();o.stop(ctx.currentTime+dur)}
function effect(kind){if(!sfx)return;audio();if(kind==='shock'){tone(50,.8,.3,'sawtooth');tone(110,.4,.12,'square')}else if(kind==='win'){[220,293.66,440].forEach((n,i)=>setTimeout(()=>tone(n,.3,.07),i*100))}else{[0,65,140,230].forEach((n,i)=>setTimeout(()=>tone(400+i*160,.065,.07,'triangle'),n))}}
function music(){clearInterval(timer);if(bgm){audio();let i=0;const notes=[110,0,164.81,146.83,110,0,130.81,98];timer=setInterval(()=>{if(!document.hidden){const n=notes[i++%notes.length];if(n)tone(n,.4,.022)}},430)}}
$('bgm').onclick=()=>{bgm=!bgm;$('bgm').textContent='BGM '+(bgm?'入':'切');$('bgm').setAttribute('aria-pressed',bgm);music()};$('sfx').onclick=()=>{sfx=!sfx;if(!sfx)stopCaughtVoice();$('sfx').textContent='効果音 '+(sfx?'入':'切');$('sfx').setAttribute('aria-pressed',sfx);audio()};
const patterns={1:[4],2:[0,8],3:[0,4,8],4:[0,2,6,8],5:[0,2,4,6,8],6:[0,2,3,5,6,8]};
// Opposite faces sum to seven. The chosen face is brought toward the viewer.
const faceTurns={1:[0,0],2:[0,-90],3:[-90,0],4:[90,0],5:[0,90],6:[0,180]};
function diePose(n,i,extra=0,wobble=0){const [x,y]=faceTurns[n];return `rotateZ(${[-13,9,21][i]+wobble}deg) rotateX(-7deg) rotateY(8deg) rotateX(${x+extra}deg) rotateY(${y+extra}deg)`}
function showDice(d){$('dice').innerHTML=d.map((n,i)=>`<div class="die-seat"><div class="dice-shadow"></div><div class="die-flight"><div class="die-cube" style="transform:${diePose(n,i)}">${[1,2,3,4,5,6].map(face=>`<div class="die-face face-${face} ${face===1?'one':''}">${patterns[face].map(p=>`<i class="pip" style="grid-area:${1+Math.floor(p/3)}/${1+p%3}"></i>`).join('')}</div>`).join('')}</div></div></div>`).join('');$('dice').setAttribute('aria-label','サイコロ '+d.join('・'))}
const wait=ms=>new Promise(r=>setTimeout(r,ms));
function diceImpact(strength=1){if(!sfx)return;tone(1050,.028,.09*strength);tone(2350,.016,.035*strength);tone(160,.075,.07*strength)}
async function roll(d){
 showDice(d);$('dice').setAttribute('aria-label','サイコロを振っています');
 const seats=$('dice').querySelectorAll?.('.die-seat')||[];
 if(window.matchMedia?.('(prefers-reduced-motion: reduce)').matches||!seats.length||!seats[0].animate){diceImpact();await wait(180);$('dice').setAttribute('aria-label','サイコロ '+d.join('・'));return}
 const animations=[],sounds=[];
 seats.forEach((seat,i)=>{
  const flight=seat.querySelector('.die-flight'),cube=seat.querySelector('.die-cube'),shadow=seat.querySelector('.dice-shadow');
  const delay=i*75,duration=1470+i*90,side=i===1?-1:1;
  const animate=(el,frames)=>{const a=el.animate(frames,{duration,delay,fill:'both',easing:'linear'});animations.push(a)};
  // Three progressively smaller ballistic arcs, then a short slide into rest.
  animate(flight,[
   {offset:0,transform:`translate3d(${-48+i*13}px,-100px,0)`,easing:'cubic-bezier(.42,0,1,1)'},
   {offset:.27,transform:`translate3d(${side*17}px,8px,0)`,easing:'cubic-bezier(0,0,.58,1)'},
   {offset:.43,transform:`translate3d(${side*26}px,-34px,0)`,easing:'cubic-bezier(.42,0,1,1)'},
   {offset:.6,transform:`translate3d(${side*13}px,4px,0)`,easing:'cubic-bezier(0,0,.58,1)'},
   {offset:.7,transform:`translate3d(${side*6}px,-12px,0)`,easing:'cubic-bezier(.42,0,1,1)'},
   {offset:.8,transform:'translate3d(2px,2px,0)',easing:'ease-out'},
   {offset:1,transform:'translate3d(0,0,0)'}]);
  animate(cube,[{offset:0,transform:diePose(d[i],i,720+360*i,80)},
   {offset:.27,transform:diePose(d[i],i,450,30)},
   {offset:.6,transform:diePose(d[i],i,180,-15)},
   {offset:.8,transform:diePose(d[i],i,0,9)},
   {offset:.9,transform:diePose(d[i],i,0,-3)},
   {offset:1,transform:diePose(d[i],i)}]);
  animate(shadow,[{offset:0,opacity:.1,transform:'scale(1.8)'},{offset:.27,opacity:.65,transform:`translateX(${side*17}px) scale(1)`},{offset:.43,opacity:.22,transform:`translateX(${side*26}px) scale(1.4)`},{offset:.6,opacity:.6,transform:`translateX(${side*13}px) scale(1)`},{offset:.7,opacity:.38,transform:'scale(1.15)'},{offset:.8,opacity:.6,transform:'scale(1)'},{offset:1,opacity:.55,transform:'scale(1)'}]);
  [.27,.6,.8].forEach((t,j)=>sounds.push(setTimeout(()=>diceImpact((1-j*.27)*(1-i*.12)),delay+duration*t)));
 });
 // Resolve even when a browser cancels an animation (for example on tab changes).
 await Promise.all(animations.map(a=>a.finished.catch(()=>{})));
 animations.forEach(a=>a.cancel());sounds.forEach(id=>clearTimeout(id));
 $('dice').setAttribute('aria-label','サイコロ '+d.join('・'));await wait(260);
}
function view(id){['title','game','ending'].forEach(x=>$(x).hidden=x!==id)}
function refresh(){const s=state;$('money').innerHTML=fmt(s.money)+'<small>両</small>';$('profit').textContent=signed(s.money-10000n);$('sus').textContent=s.suspicion;$('risk').textContent=E.rate(s.suspicion)+'%';$('bar').style.width=s.suspicion+'%';$('bar').style.background=s.suspicion<30?'#86aa86':s.suspicion<65?'#d5ac5f':'#df4545';document.querySelector('.meter').setAttribute('aria-valuenow',s.suspicion);$('round').textContent=`第 ${s.rounds+1} 勝負`;}
function lock(){for(const id of ['normal','loaded','next','leave'])$(id).disabled=busy;for(const id of ['bet','half','all'])$(id).disabled=busy||state.throws>0||phase!=='roll'}
function nextRound(){if(state.money<state.minBet){finish('insufficient');return}phase='roll';state.throws=0;state.cheated=false;state.player=null;state.cpu=null;state.bet=null;state.settled=false;state.pendingEnd=null;state.accounting='';$('settlement').hidden=true;$('bet').value=String(state.lastBet);$('playerRole').textContent='―';$('cpuRole').textContent='―';$('role').textContent='さあ、勝負。';$('role').className='role';$('turn').textContent='あんたの番だ';$('throwCount').textContent='第 1 投 / 最大 3 投';$('quote').innerHTML='さあ、旦那。<br>腹をくくりな。';$('rollButtons').hidden=false;$('resultButtons').hidden=true;$('hint').textContent='通常勝負を終えると、猜疑心 −5。';$('betError').textContent='';refresh();lock();updateExposure();showDice([1,1,1])}
function start(){if(busy)return;stopCaughtVoice();audio();state={money:10000n,suspicion:20,rounds:0,successes:0,lastBet:1000n,minBet:1n};view('game');nextRound()}
$('start').onclick=start;$('restart').onclick=start;
function refuseLowerBet(){ $('quote').textContent='そんな張りじゃあ、ヒリつかなえなあ';$('betError').textContent='そんな張りじゃあ、ヒリつかなえなあ（最低 '+fmt(state.minBet)+' 両）';$('bet').value=String(state.minBet);updateExposure();return false}
function checkBetFloor(){const v=$('bet').value.trim();if(/^[0-9]+$/.test(v)&&BigInt(v)<state.minBet)return refuseLowerBet();return true}
function readBet(){if(state.bet!==null)return true;const v=$('bet').value.trim();if(!/^[0-9]+$/.test(v)||BigInt(v)<1n||BigInt(v)>state.money){$('betError').textContent='1両以上、所持金以下の整数を入力してください。';return false}if(!checkBetFloor())return false;state.bet=BigInt(v);state.lastBet=state.bet;state.minBet=state.bet;$('betError').textContent='';return true}
function updateExposure(){const v=$('bet').value.trim();$('exposure').textContent=/^[0-9]+$/.test(v)&&BigInt(v)>0n?'最低掛け金 '+fmt(state.minBet)+' 両 ／ 最大支払い '+fmt(BigInt(v)*5n)+' 両（ピンゾロ負け）。所持金不足なら破産。':''}
$('bet').oninput=updateExposure;
$('bet').onchange=checkBetFloor;
$('half').onclick=()=>{$('bet').value=String(state.money/2n||1n);checkBetFloor();updateExposure()};$('all').onclick=()=>{$('bet').value=String(state.money);updateExposure()};
async function cutin(kind,tag,words,label){const el=$('cutin');el.className='cutin '+kind;$('cutTag').textContent=tag;$('cutWords').textContent=words;$('cutContinue').textContent=label;el.hidden=false;if(kind==='caught')playCaughtVoice();else effect(kind==='success'?'win':'shock');await new Promise(r=>{cutResolve=r;$('cutContinue').focus()});el.hidden=true}
$('cutContinue').onclick=()=>{if(cutResolve){const r=cutResolve;cutResolve=null;r()}};
async function suspense(){
 const el=$('cutin');el.className='cutin tension';$('cutTag').textContent='仕込みサイコロ ／ 発覚率 '+E.rate(state.suspicion)+'%';$('cutWords').textContent='気づくなよ……。';$('cutContinue').hidden=true;el.hidden=false;
 const reduced=window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
 const beat=()=>{if(sfx){tone(52,.16,.14,'sine');setTimeout(()=>tone(42,.2,.1,'sine'),140)}};
 beat();await wait(reduced?180:750);$('cutWords').textContent='極道の視線が、\n手元に落ちる。';beat();await wait(reduced?180:850);$('cutWords').textContent='……。';beat();await wait(reduced?180:750);
 el.hidden=true;$('cutContinue').hidden=false;
}
async function playerRoll(loaded){if(busy||phase!=='roll'||state.player||!readBet())return;busy=true;lock();audio();if(loaded){state.cheated=true;const check=E.cheat(state.suspicion);await suspense();if(check.caught){const before=state.money;await cutin('caught','イカサマ発覚・全額没収','てめえ、\nサマしやがったな？','没収額を確認する');state.money=0n;state.rounds++;state.settled=true;state.accounting='イカサマ発覚：'+fmt(before)+' 両 − 全額没収 '+fmt(before)+' 両 ＝ 0 両';refresh();finish('caught');busy=false;return}state.suspicion=check.suspicion;state.successes++;refresh();await cutin('success','仕込み成功','……通った。\n今だ、振れ。','シゴロを出す')}
const d=loaded?[4,5,6]:E.dice();state.throws++;await roll(d);const role=E.role(d);$('role').textContent=role.name;$('role').className='role'+(role.rank>=8?' special':'');if(role.rank>=8)effect('win');$('throwCount').textContent=`第 ${state.throws} 投 / 最大 3 投`;
if(role.rank===0&&state.throws<3&&!loaded){$('hint').textContent='役なし。もう一度振るか、仕込みに賭けるか。';busy=false;lock();return}
state.player=role;$('playerRole').textContent=role.name;$('turn').textContent='極道の番';$('hint').textContent='極道がサイコロを振っています…';await wait(450);
for(let i=1;i<=3;i++){const cpuDice=E.dice();await roll(cpuDice);state.cpu=E.role(cpuDice);$('role').textContent=state.cpu.name;$('throwCount').textContent=`極道 第 ${i} 投 / 最大 3 投`;if(state.cpu.rank!==0||i===3)break;await wait(300)}
$('cpuRole').textContent=state.cpu.name;
if(state.settled){busy=false;return} // One settlement per round, even if a callback is repeated.
state.settled=true;const before=state.money;const result=E.settle(state.player,state.cpu,state.bet,before);state.money=result.money;state.rounds++;if(!state.cheated)state.suspicion=E.cool(state.suspicion);refresh();$('round').textContent=`第 ${state.rounds} 勝負・決着`;
phase='result';state.pendingEnd=state.money===0n?'bankrupt':null;
const verdict=result.sign>0?'あんたの勝ち':result.sign<0?'極道の勝ち':'引き分け';
$('turn').textContent='勝負あり';$('role').textContent=verdict;$('role').className='role'+(result.sign>0?' special':'');$('throwCount').textContent=signed(result.delta);
state.accounting=fmt(before)+' 両 '+(result.delta<0n?'−':'+')+' '+fmt(result.delta<0n?-result.delta:result.delta)+' 両 ＝ '+fmt(state.money)+' 両';
$('settlement').hidden=false;$('settlementTitle').textContent=state.pendingEnd?'支払い不足で破産':verdict;
$('settlementRoles').textContent='あんた：'+state.player.name+' ／ 極道：'+state.cpu.name;
$('settlementMath').textContent=state.accounting;
const due=state.bet*BigInt(result.mult);
$('settlementReason').textContent=result.sign===0?'同じ強さのため、所持金の移動はありません。':'賭け金 '+fmt(state.bet)+' 両 × '+result.mult+'倍 ＝ '+fmt(due)+' 両。'+(result.sign<0&&due>before?'支払いが所持金を超えたため、残額 '+fmt(before)+' 両を支払いました。':state.pendingEnd?'支払いにより所持金が0両になりました。':'');
$('quote').innerHTML=result.sign>0?'運のいい<br>旦那だ。':result.sign<0?'これも、<br>渡世だ。':'次で<br>決めようや。';$('hint').textContent=state.cheated?'仕込み成功。猜疑心 ＋30。':'通常勝負。猜疑心 −5。';$('rollButtons').hidden=true;$('resultButtons').hidden=false;
$('next').textContent=state.pendingEnd?'結末を見る':'続ける →';$('leave').hidden=!!state.pendingEnd;busy=false;lock();if(result.sign>0)effect('win')}
$('normal').onclick=()=>playerRoll(false);$('loaded').onclick=()=>playerRoll(true);$('next').onclick=()=>{if(busy||phase!=='result')return;if(state.pendingEnd){finish(state.pendingEnd);return}nextRound()};
$('leave').onclick=async()=>{if(busy||phase!=='result'||state.pendingEnd)return;busy=true;lock();if(E.canLeave()){finish('clear');busy=false}else{await cutin('refused','帰宅拒否','勝ち逃げは許さねえよ、\n旦那。','次の勝負へ');busy=false;nextRound();$('quote').innerHTML='もう一勝負、<br>付き合いな。';$('hint').textContent='帰宅を拒まれた。次の勝負を終えるまで帰れない。'}};
function finish(type){phase=type;view('ending');const clear=type==='clear';$('endAccounting').textContent=clear?'':state.accounting||'';$('endKicker').textContent=clear?'無事、帰宅。':type==='caught'?'イカサマ発覚・全額没収':type==='insufficient'?'最低掛け金に届かず。':'所持金、尽きる。';$('endTitle').textContent=clear?'生きて帰った。':type==='caught'?'仁義を欠いたな。':type==='insufficient'?'ここまでだ、旦那。':'一文無し。';$('endQuote').textContent=clear?'今夜の勝負は、ここまでだ。':type==='caught'?'この賭場じゃ、サマの代償は重い。':type==='insufficient'?'最低掛け金 '+fmt(state.minBet)+' 両に所持金が届かないため、勝負終了。':'また出直してきな、旦那。';$('finalMoney').textContent=fmt(state.money)+' 両';$('stats').innerHTML=`<dt>収支</dt><dd>${signed(state.money-10000n)}</dd><dt>勝負回数</dt><dd>${state.rounds} 回</dd><dt>イカサマ成功</dt><dd>${state.successes} 回</dd>`;$('share').hidden=!clear;$('shareStatus').textContent='';$('shareText').hidden=true;if(clear)try{if(state.money>BigInt(localStorage.getItem('gokudo-best')||0))localStorage.setItem('gokudo-best',String(state.money))}catch{}loadRecord()}
function loadRecord(){try{$('record').textContent='最高獲得金額 '+fmt(BigInt(localStorage.getItem('gokudo-best')||0))+' 両'}catch{$('record').textContent='この環境では記録を保存できません。'}}loadRecord();showDice([1,1,1]);
$('share').onclick=async()=>{const text=`浪漫ラブ極道の仁義なきチンチロで無事帰宅！\n最終所持金：${fmt(state.money)}両\n収支：${signed(state.money-10000n)}\n勝負回数：${state.rounds}回\n#仁義なきチンチロ\n${location.href.split('?')[0]}`;if(navigator.share)try{await navigator.share({title:document.title,text});return}catch(e){if(e.name==='AbortError')return}try{await navigator.clipboard.writeText(text);$('shareStatus').textContent='結果の文章をコピーしました。'}catch{$('shareText').hidden=false;$('shareText').value=text;$('shareText').select();$('shareStatus').textContent='文章を長押ししてコピーしてください。'}};
$('help').onclick=()=>{$('rules').showModal()};$('closeRules').onclick=()=>{$('rules').close()};

$('titleHelp').onclick=()=>{$('rules').showModal()};$('closeRulesBottom').onclick=()=>{$('rules').close()};
