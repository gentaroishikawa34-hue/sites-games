window.IDEA_STOCK_CONFIG = { supabaseUrl: 'https://ncqjtcczrwegviqzsgbk.supabase.co', supabasePublishableKey: 'sb_publishable_9OFsNqKu99rM1jzDL5ebzQ_ulRHIqaX' };
