begin;
create table public.categories (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 name text not null check(length(trim(name)) between 1 and 40),
 created_at timestamptz not null default now(),
 unique(user_id,name), unique(id,user_id)
);
create table public.ideas (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 content text not null check(length(trim(content))>0),
 category_id uuid,
 status text not null default 'normal' check(status in ('normal','hold','adopted','done','rejected')),
 is_important boolean not null default false,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now(),
 foreign key(category_id,user_id) references public.categories(id,user_id) on delete set null (category_id)
);
create index ideas_user_date on public.ideas(user_id,created_at desc,id desc);
alter table public.ideas enable row level security;
alter table public.categories enable row level security;
create policy own_ideas on public.ideas for all to authenticated using ((select auth.uid())=user_id) with check ((select auth.uid())=user_id);
create policy own_categories on public.categories for all to authenticated using ((select auth.uid())=user_id) with check ((select auth.uid())=user_id);
revoke all on public.ideas,public.categories from anon;
grant select,insert,update,delete on public.ideas,public.categories to authenticated;
create function public.touch_idea() returns trigger language plpgsql set search_path='' as $$ begin new.updated_at=clock_timestamp();new.created_at=old.created_at;new.user_id=old.user_id;return new;end $$;
create trigger idea_updated before update on public.ideas for each row execute function public.touch_idea();
create function public.seed_idea_categories() returns trigger language plpgsql security definer set search_path='' as $$ begin
 insert into public.categories(user_id,name) select new.id,unnest(array['仕事','ゲーム','商品企画','キャラクター','勉強','個人','その他']) on conflict do nothing; return new;end $$;
create trigger user_idea_categories after insert on auth.users for each row execute function public.seed_idea_categories();
insert into public.categories(user_id,name) select u.id,n.name from auth.users u cross join unnest(array['仕事','ゲーム','商品企画','キャラクター','勉強','個人','その他']) as n(name) on conflict do nothing;
alter publication supabase_realtime add table public.ideas,public.categories;
commit;
