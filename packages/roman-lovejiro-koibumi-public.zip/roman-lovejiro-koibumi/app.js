'use strict';
const app=document.getElementById('app');
const phases=['序論','本論','結論'];
let selectionAudio;
function playSelectionSound(){
 try{
  const AudioEngine=window.AudioContext||window.webkitAudioContext;
  if(!AudioEngine)return;
  if(!selectionAudio||selectionAudio.state==='closed')selectionAudio=new AudioEngine();
  const ctx=selectionAudio;
  const play=()=>{
   if(ctx.state!=='running')return;
   const now=ctx.currentTime;
   // A brief paper rustle followed by a soft wooden seal tap.
   const buffer=ctx.createBuffer(1,Math.ceil(ctx.sampleRate*.12),ctx.sampleRate);
   const samples=buffer.getChannelData(0);
   for(let i=0;i<samples.length;i++)samples[i]=(Math.random()*2-1)*Math.pow(1-i/samples.length,2);
   const paper=ctx.createBufferSource(),filter=ctx.createBiquadFilter(),paperGain=ctx.createGain();
   paper.buffer=buffer;filter.type='bandpass';filter.frequency.value=1800;filter.Q.value=.65;paperGain.gain.value=.12;
   paper.connect(filter);filter.connect(paperGain);paperGain.connect(ctx.destination);
   paper.start(now);paper.stop(now+.13);
   paper.onended=()=>{paper.disconnect();filter.disconnect();paperGain.disconnect();};
   const seal=ctx.createOscillator(),sealGain=ctx.createGain();
   seal.type='sine';seal.frequency.setValueAtTime(330,now+.025);seal.frequency.exponentialRampToValueAtTime(125,now+.11);
   sealGain.gain.setValueAtTime(0,now);sealGain.gain.setValueAtTime(.0001,now+.025);sealGain.gain.exponentialRampToValueAtTime(.23,now+.029);sealGain.gain.exponentialRampToValueAtTime(.0001,now+.17);
   seal.connect(sealGain);sealGain.connect(ctx.destination);seal.start(now+.025);seal.stop(now+.18);
   seal.onended=()=>{seal.disconnect();sealGain.disconnect();};
  };
  if(ctx.state!=='running')ctx.resume().then(play).catch(()=>{});else play();
 }catch{/* Audio availability must never block a selection. */}
}
// Use the same unlocked context as the selection sound (including iOS Safari).
const resultVoices=new Set();
function unlockResultAudio(){
 try{
  const AudioEngine=window.AudioContext||window.webkitAudioContext;
  if(!AudioEngine)return;
  if(!selectionAudio||selectionAudio.state==='closed')selectionAudio=new AudioEngine();
  if(selectionAudio.state!=='running')selectionAudio.resume().catch(()=>{});
 }catch{/* Sound is optional; the game remains playable. */}
}
function stopResultSounds(){
 for(const voice of resultVoices){try{voice.stop();}catch{}}
 resultVoices.clear();
}
function playResultSound(kind){
 try{
  const ctx=selectionAudio;
  if(!ctx||ctx.state!=='running')return;
  const start=ctx.currentTime;
  const note=(frequency,offset,length,volume,type='triangle')=>{
   const voice=ctx.createOscillator(),gain=ctx.createGain(),at=start+offset;
   voice.type=type;voice.frequency.setValueAtTime(frequency,at);
   gain.gain.setValueAtTime(0,at);
   gain.gain.linearRampToValueAtTime(volume,at+.012);
   gain.gain.exponentialRampToValueAtTime(.0001,at+length);
   voice.connect(gain);gain.connect(ctx.destination);
   resultVoices.add(voice);
   voice.onended=()=>{resultVoices.delete(voice);voice.disconnect();gain.disconnect();};
   voice.start(at);voice.stop(at+length+.02);
  };
  if(kind==='combo'){
   // A clear, short ascending chime for each individual announcement.
   note(659.25,0,.16,.095,'sine');
   note(987.77,.09,.25,.075,'sine');
   note(1318.51,.13,.21,.035,'sine');
  }else if(kind==='fanfare'){
   // A bright C-major fanfare, ending in a softly sustained chord.
   [[523.25,0,.16],[523.25,.18,.16],[659.25,.36,.18],
    [783.99,.56,.2],[1046.5,.8,.65]].forEach(([hz,at,len])=>note(hz,at,len,.085));
   [261.63,329.63,392].forEach(hz=>note(hz,.8,.7,.035));
  }
 }catch{/* Audio errors must not interrupt result announcements. */}
}
function celebrateHundred(panel){
 if(!panel||panel.classList.contains('hundred-plus'))return;
 panel.classList.add('hundred-plus');
 playResultSound('fanfare');
 panel.insertAdjacentHTML('afterbegin','<div class="hundred-badge" role="status">祝・恋文力100点突破</div>');
 if(reduced())return;
 flourish(true);
 const halo=document.createElement('div');halo.className='hundred-halo';
 document.getElementById('effects').appendChild(halo);
 setTimeout(()=>halo.remove(),2100);
}

let state={favorites:[],picks:[],candidates:[],locked:false,run:0};
const reduced=()=>window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const chip=id=>`<span class="chip">${ELEMENTS[id].icon} ${ELEMENTS[id].name}</span>`;
const sample=(items,count)=>{const pool=[...items];for(let i=pool.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[pool[i],pool[j]]=[pool[j],pool[i]];}return pool.slice(0,count);};
function calculateScore(picks,favorites){
 const base=picks.reduce((sum,id)=>sum+ELEMENTS[id].points,0);
 const bonus=picks.reduce((sum,id)=>sum+(favorites.includes(id)?ELEMENTS[id].points:0),0);
 const found=COMBOS.filter(c=>c.elements.every(id=>picks.includes(id)));
 const multiplier=Math.round((1+found.reduce((sum,c)=>sum+c.multiplier-1,0))*10)/10;
 return {base,bonus,subtotal:base+bonus,combos:found,multiplier,total:Math.round((base+bonus)*multiplier)};
}
function authorBar(right){return `<div class="chapter-top"><div class="mini-author"><img src="assets/jiro.jpg" alt="浪漫ラブ次朗"><div><small>恋文指南</small><strong>浪漫ラブ次朗</strong></div></div><span class="chapter-no">${right}</span></div>`;}
function preferences(){return `<section class="preferences" aria-label="今回の彼女の好み"><h2>♡ 今回の彼女の好み</h2><div class="chips">${state.favorites.map(chip).join('')}</div></section>`;}
function focusTitle(){const el=app.querySelector('h1');if(el){el.tabIndex=-1;el.focus({preventScroll:true});}}
function scrollTop(){window.scrollTo({top:0,behavior:'instant'});}
function startScreen(){app.innerHTML=`<section class="start fade"><div class="cover"><img src="assets/jiro.jpg" alt="赤い薔薇を差し出す浪漫ラブ次朗" fetchpriority="high"><div class="vertical-note">拝啓、恋するあなたへ。</div></div><div class="start-copy"><div class="edition">恋文指南 ・ 特別編</div><p class="author">浪漫ラブ次朗の</p><h1><em>恋文</em><br>したためました</h1><p class="tagline">最高の恋文を送ろう。</p><button class="primary" id="start">恋文をしたためる<span class="arrow" aria-hidden="true">→</span></button><a class="secondary rules-link" href="rules.html">遊び方<span class="arrow" aria-hidden="true">↗</span></a><a class="family-link" href="https://roman-love-family.amane1981.chatgpt.site/">浪漫ラブファミリー総合サイトへ戻る</a><p class="explain">彼女の好み、話題の★、意外な組み合わせ。<br>三つの話題で、想いを一通の手紙に。</p><div class="guide"><span><b>一</b> 好みを知る</span><span><b>二</b> 話題を選ぶ</span><span><b>三</b> 想いを届ける</span></div></div></section>`;document.getElementById('start').addEventListener('click',newGame);}
function newGame(){stopResultSounds();state={favorites:sample(ELEMENTS.map(e=>e.id),3),picks:[],candidates:[],locked:false,run:state.run+1};document.getElementById('effects').replaceChildren();renderPhase();}
function renderPhase(){const index=state.picks.length;state.candidates=sample(ELEMENTS.map(e=>e.id),3);app.innerHTML=`<section class="game fade">${authorBar('LOVE LETTER / 0'+(index+1))}${preferences()}<ol class="steps">${phases.map((p,i)=>`<li class="${i===index?'active':i<index?'done':''}" ${i===index?'aria-current="step"':''}>${i<index?'✓ ':''}${p}</li>`).join('')}</ol><div class="phase-title"><h1>${phases[index]}</h1><span>${['想いの書き出し','心のまんなか','最後のひと押し'][index]}</span></div><p class="phase-desc">${['最初に語るのは、どんな話題？','想いを深める、次の話題は？','この恋文を締めくくる話題は？'][index]}</p><div class="choices">${state.candidates.map(id=>{const e=ELEMENTS[id],fav=state.favorites.includes(id);return `<button class="choice" data-id="${id}" aria-label="${e.name}、星${e.stars}つ${fav?'、彼女の好み':''}"><span class="icon" aria-hidden="true">${e.icon}</span><span><span class="label">${e.name}</span><span class="stars" aria-hidden="true">${'★'.repeat(e.stars)}<span class="empty">${'☆'.repeat(5-e.stars)}</span></span></span>${fav?'<span class="favorite">♡ 彼女の好み</span>':'<span class="select-mark" aria-hidden="true">›</span>'}</button>`;}).join('')}</div>${state.picks.length?`<div class="selected-topics"><span>ここまでの話題</span>${state.picks.map(chip).join('<span aria-hidden="true">・</span>')}</div>`:''}<p class="hint">♡ 彼女の好みはポイント2倍。<br>★が少ない話題にも、思わぬコンボが潜んでいる。</p></section>`;app.querySelectorAll('.choice').forEach(button=>button.addEventListener('click',()=>choose(Number(button.dataset.id))));scrollTop();focusTitle();}
async function choose(id){if(state.locked||!state.candidates.includes(id))return;playSelectionSound();state.locked=true;const run=state.run;app.querySelectorAll('.choice').forEach(b=>b.disabled=true);const index=state.picks.length;state.picks.push(id);const toast=document.getElementById('toast');toast.textContent=['序、したためました。','想い、深まりました。','覚悟、決まりました。'][index];toast.classList.remove('show');void toast.offsetWidth;toast.classList.add('show');await pause(reduced()?80:850);if(state.run!==run)return;state.locked=false;if(state.picks.length===3)renderLetter();else renderPhase();}
function renderLetter(){const letter=state.picks.map((id,i)=>`<p>${ELEMENTS[id].texts[i]}</p>`).join('');app.innerHTML=`<section class="result fade">${authorBar('LOVE LETTER / COMPLETE')}<div class="result-heading"><div class="eyebrow">A LETTER, JUST FOR YOU</div><h1>恋文、したためました。</h1><div class="chips" style="justify-content:center">${state.picks.map(chip).join('')}</div></div><article class="letter" aria-label="完成した恋文"><div class="letter-head"><span>君に贈る、一通。</span><span>恋文</span></div>${letter}<p class="confession">だから、僕と付き合ってください。</p><div class="letter-sign">心を込めて。</div></article><div id="score-area"><button class="primary score-trigger" id="judge">この恋文を届ける<span class="arrow" aria-hidden="true">→</span></button></div></section>`;document.getElementById('judge').addEventListener('click',judge);scrollTop();focusTitle();}
const pause=ms=>new Promise(resolve=>setTimeout(resolve,ms));
function flourish(gold=false){if(reduced())return;const fx=document.getElementById('effects');for(let i=0;i<(gold?42:20);i++){const el=document.createElement('i');el.className='petal'+(gold&&i%2?' gold':'');el.style.left=Math.random()*100+'%';el.style.setProperty('--duration',(2.8+Math.random()*2.6)+'s');el.style.animationDelay=Math.random()*.7+'s';fx.appendChild(el);setTimeout(()=>el.remove(),6500);}}
function approach(el){if(!el)return;el.scrollIntoView({behavior:reduced()?'instant':'smooth',block:'center'});}
async function judge(){if(state.locked)return;unlockResultAudio();state.locked=true;const run=state.run;const score=calculateScore(state.picks,state.favorites);const area=document.getElementById('score-area');area.innerHTML='<div class="judging" role="status">恋文を採点中……</div>';flourish();approach(area);await pause(reduced()?60:1200);if(state.run!==run)return;area.innerHTML=`<section class="breakdown reveal" aria-label="採点結果"><div class="score-row"><span>基礎恋文力</span><strong>${score.base} 点</strong></div></section>`;const breakdown=area.firstElementChild;await pause(reduced()?30:550);if(state.run!==run)return;const matches=state.picks.filter(id=>state.favorites.includes(id));breakdown.insertAdjacentHTML('beforeend',`<div class="reveal"><div class="score-row"><span>彼女の好みボーナス</span><strong>＋${score.bonus} 点</strong></div>${matches.length?matches.map(id=>`<p class="bonus-msg">♡ ${ELEMENTS[id].icon} ${ELEMENTS[id].name}が彼女の好みに刺さった！</p>`).join(''):'<p class="bonus-msg">今回は彼女の好みと一致なし。</p>'}<div class="score-row"><span>ボーナス後の恋文力</span><strong>${score.subtotal} 点</strong></div></div>`);approach(breakdown);await pause(reduced()?30:650);if(state.run!==run)return;
 for(const combo of score.combos){breakdown.insertAdjacentHTML('beforeend',`<section class="combo"><div class="eyebrow">COMBO!</div><h3>「${combo.name}」</h3><strong>×${combo.multiplier.toFixed(1)}</strong><p class="combo-elements">${combo.elements.map(id=>ELEMENTS[id].name).join(' ＋ ')}</p></section>`);playResultSound('combo');approach(breakdown.lastElementChild);flourish(true);await pause(reduced()?420:950);if(state.run!==run)return;}
 if(!score.combos.length)breakdown.insertAdjacentHTML('beforeend','<p class="no-combo reveal">今回はコンボなし。次の組み合わせに期待。</p>');
 breakdown.insertAdjacentHTML('beforeend',`<div class="score-row reveal"><span>合計コンボ倍率</span><strong>×${score.multiplier.toFixed(1)}</strong></div>${score.combos.length>1?`<p class="hint">倍率は増加分を加算：1 ${score.combos.map(c=>'＋ '+(c.multiplier-1).toFixed(1)).join(' ')} ＝ ${score.multiplier.toFixed(1)}</p>`:''}`);
 area.insertAdjacentHTML('beforeend',`<section class="final-score reveal" aria-label="最終恋文力 ${score.total}点"><h2>恋文力</h2><div class="number" aria-hidden="true"><span id="score-number">0</span><small>点</small></div><p class="equation">${score.subtotal} × ${score.multiplier.toFixed(1)} ＝ ${score.total.toLocaleString('ja-JP')} 点</p></section><div class="jiro-quote reveal"><img src="assets/jiro-result.jpg" alt="満足そうに微笑む浪漫ラブ次朗"><blockquote>真心を、君に……。<cite>浪漫ラブ次朗</cite></blockquote></div><button class="primary reveal" id="replay">もう一度したためる<span class="arrow" aria-hidden="true">↻</span></button><a class="family-link" href="https://roman-love-family.amane1981.chatgpt.site/">浪漫ラブファミリー総合サイトへ戻る</a>`);const number=document.getElementById('score-number'),begin=performance.now();const duration=reduced()?0:1000;let celebrated=false;function tick(now){if(state.run!==run)return;const t=duration?Math.min(1,(now-begin)/duration):1;const displayed=Math.round(score.total*(1-Math.pow(1-t,3)));number.textContent=displayed.toLocaleString('ja-JP');if(!celebrated&&displayed>100){celebrated=true;celebrateHundred(area.querySelector('.final-score'));}if(t<1)requestAnimationFrame(tick);}requestAnimationFrame(tick);flourish(true);approach(area.querySelector('.final-score'));document.getElementById('replay').addEventListener('click',newGame);state.locked=false;
}
if(window.location?.hash==='#play')newGame();else startScreen();
