// Official names/prices: https://1to3bunno1-official.com/restaurant (2026-10-04).
// Recipes, temperature choices, add-ons and unverified prices are game adaptations.
const BRAND={name:'イチトサンブンノイチ',logo:'assets/logo_header.png',official:'https://1to3bunno1-official.com/restaurant',useLogo:true};
const TOPPINGS=[['ねぎ','🌿'],['しょうが','🫚'],['大根おろし','⚪'],['すだち','🍋'],['卵黄','🟡'],['温泉卵','🥚'],['台湾ミンチ','🍖'],['肉','🥩'],['ベーコン','🥓'],['チーズ','🧀'],['のり','◼'],['えび天','🍤'],['ちくわ天','🍢'],['とり天','🍗'],['野菜天','🥬']];
const SOUPS=['ぶっかけつゆ','専用だし','台湾ベース','カルボナーラ','カレー','味噌だし','だし醤油'];
const MENUS=[
{id:'sudachi',menuName:'すだちうどん',temperatureOptions:['冷'],soup:'専用だし',requiredToppings:['すだち'],price:1265,difficulty:1,season:'夏季限定',photo:'menu_04.jpg',official:true},
{id:'bukkake',menuName:'天盛りぶっかけ',temperatureOptions:['温','冷'],soup:'ぶっかけつゆ',requiredToppings:['ねぎ','しょうが','大根おろし','えび天','ちくわ天','野菜天'],price:1628,difficulty:1,photo:'menu_01.jpg',official:true},
{id:'kamatama',menuName:'天盛り釜玉うどん',temperatureOptions:['温'],soup:'だし醤油',requiredToppings:['卵黄','ねぎ','えび天','ちくわ天'],price:1600,difficulty:2,official:false},
{id:'coldcarbo',menuName:'冷たいカルボナーラうどん',temperatureOptions:['冷'],soup:'カルボナーラ',requiredToppings:['温泉卵','ベーコン','チーズ'],price:1400,difficulty:2,official:false},
{id:'taiwan',menuName:'台湾カルボナーラうどん',temperatureOptions:['温','冷'],soup:'カルボナーラ',requiredToppings:['台湾ミンチ','卵黄','ねぎ','チーズ'],price:1800,difficulty:2,official:false},
{id:'curry',menuName:'台湾カレーうどん',temperatureOptions:['温'],soup:'カレー',requiredToppings:['台湾ミンチ','ねぎ','卵黄'],price:1600,difficulty:2,official:false},
{id:'set',menuName:'台湾カレーうどんデ唐揚げセット',temperatureOptions:['温'],soup:'カレー',requiredToppings:['台湾ミンチ','ねぎ','卵黄'],sideMenu:'唐揚げ',price:2200,difficulty:3,photo:'menu_03.jpg',official:true},
{id:'tencarbo',menuName:'天盛り台湾カルボナーラうどん',temperatureOptions:['温','冷'],soup:'カルボナーラ',requiredToppings:['台湾ミンチ','卵黄','ねぎ','チーズ','えび天','ちくわ天','野菜天'],price:2618,difficulty:3,photo:'menu_02.jpg',official:true},
{id:'miso',menuName:'味噌煮込みうどん',temperatureOptions:['温'],soup:'味噌だし',requiredToppings:['肉','卵黄','ねぎ'],price:1628,difficulty:3,season:'冬季限定',special:'simmer',photo:'menu_05.jpg',official:true}
].map(m=>({...m,optionalToppings:['温泉卵','すだち','とり天'],excludedToppings:['ねぎ','しょうが'],recipeStatus:'ゲーム用アレンジ'}));
if(typeof module!=='undefined')module.exports={MENUS,TOPPINGS,SOUPS};
