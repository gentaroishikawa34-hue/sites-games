import {SLOTS,part,DIST} from './parts.js';
export const clamp=(n,min,max)=>Math.max(min,Math.min(max,n));
export function rng(seed){let a=seed>>>0;return()=>{a+=0x6D2B79F5;let t=a;t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return((t^t>>>14)>>>0)/4294967296;};}
function effects(f,opponent){const out={};for(const s of SLOTS){let e=part(f[s]).effect;if(s==='head'&&e.copy)e=opponent&&!part(opponent.head).effect.copy?part(opponent.head).effect:{};for(const[k,v]of Object.entries(e)){if(['right','left'].includes(s))continue;out[k]=typeof v==='number'?(out[k]||0)+v:v;}}return out;}
export function stats(f,opponent){const e=effects(f,opponent),body=part(f.body),leg=part(f.leg);let base=SLOTS.reduce((v,s)=>v+part(f[s]).cost,0);return {maxHP:Math.max(30,100+body.hp+(e.hp||0)),cost:Math.max(0,base-Math.floor(base*(e.costRatio||0))-(e.costCut||0)+(e.extraCost||0)),baseCost:base,def:Math.max(0,body.def+(e.def||0)),move:Math.max(0,leg.move+(e.move||0)),e};}
export function simulate(a,b,seed=1,rulesVersion=2){
 const rand=rng(seed),fighters=[a,b],s=[stats(a,b),stats(b,a)],hp=s.map(x=>x.maxHP),st=[0,1].map(()=>({turns:0,poison:0,wound:0,burn:0,slow:0,hold:0,corrode:0,shield:false,survived:false}));let distance=1,turn=0,actor=rand()<.5?0:1,events=[],ended=false,winner=null,reason='';
 const add=(kind,text,who=actor,extra={})=>events.push({kind,text,actor:who,hp:hp.map(x=>Math.max(0,Math.round(x))),distance,turn,...extra});
 const heal=(who,n,label)=>{n=Math.min(Math.max(0,Math.round(n)),s[who].maxHP-hp[who]);if(n>0){hp[who]+=n;add('heal',`${fighters[who].name}：${label} ＋${n}HP`,who);}};
 const finish=(why)=>{if(hp[0]<=0||hp[1]<=0){winner=hp[0]<=0&&hp[1]<=0?null:hp[0]>0?0:1;ended=true;reason=why;add('ko',winner===null?'相打ち！':`${fighters[1-winner].name}、機能停止！`,winner===null?actor:1-winner);return true;}return false;};
 add('start',`距離は中距離。先攻：${fighters[actor].name}`);
 while(!ended&&turn<200){
  turn++;const i=actor,j=1-i,f=fighters[i],g=fighters[j],e=s[i].e,oe=s[j].e,ls=part(f.leg),os=part(g.leg);st[i].turns++;
  add('turn',`${f.name}の行動`);
  if(distance!==f.preferred){const toward=f.preferred<distance;const slow=Math.max(0,st[i].slow-(e.slowResist||0));const power=Math.max(0,s[i].move+(toward?ls.approach:Math.max(0,ls.escape-st[i].hold))+(st[i].turns===1?(e.firstMove||0):0)+(oe.enemyMove||0)-(oe.snare||0)-slow);const resistance=Math.max(0,s[j].move*.35+os.hold+(oe.holdAt===distance?(oe.holdBonus||0):0));const chance=clamp(.5+(power-resistance)*.035,e.steady?.35:.15,.9);const warp=!!e.teleport&&rand()<e.teleport;const jump=warp||!!e.jump&&rand()<e.jump; if(warp||rand()<chance){let steps=jump?2:1;distance+=Math.sign(f.preferred-distance)*Math.min(steps,Math.abs(f.preferred-distance));add('move',`${ls.name}で${toward?'接近':'離脱'}！ ${DIST[distance]}に到達。`,i,{chance});}else add('block',`${ls.name}で${toward?'接近':'離脱'}を試みるも、${os.name}が距離を維持！`,i,{chance});}
  else add('hold',`${DIST[distance]}を維持。得意距離で迎え撃つ！`);
  st[i].slow=0;st[i].hold=0;
  for(const slot of ['right','left']){
   const arm=part(f[slot]),ae=arm.effect,label=slot==='right'?'右腕':'左腕';
   if(!arm.range.includes(distance)){add('missRange',`${label}・${arm.name}――射程外！`,i,{slot});continue;}
   let evade=(oe.evade||0)+(st[j].turns===0?(oe.firstEvade||0):0);let hit=clamp(.93+(e.accuracy||0)+(ae.accuracy||0)+(distance===2?(e.farAccuracy||0):0)-evade,.25,.99);
   if(rand()>hit){add('evade',`${label}・${arm.name}！ ${g.name}が回避！`,i,{slot});continue;}
   let attack=arm.atk+(e.attack||0)+(distance===0?(e.nearAttack||0)+(ae.nearBonus||0):distance===1?(e.midAttack||0):(e.farAttack||0))+(distance===f.preferred?(e.preferredAttack||0):0)+(hp[i]<=s[i].maxHP*.35?(e.lowAttack||0):0)+Math.min(12,Math.floor((s[i].maxHP-hp[i])*(e.revenge||0)))+(e.alternating&&st[i].turns%2===1?6:0);
   let crit=rand()<clamp(.05+(e.crit||0)+(ae.crit||0)+(distance===0?(e.nearCrit||0):0),0,.65);const ultimate=rulesVersion>=2&&hp[i]<=s[i].maxHP*.5&&rand()<.1;if(ultimate){crit=false;add('ultimate',`${f.name}：必殺！ ${arm.name}・限界突破！`,i,{weapon:arm.index});}if(crit)attack*=1.5;if(e.gamble)attack*=rand()<.5?.7:1.4;
   let defense=Math.max(0,s[j].def-st[j].corrode+(distance===0?(oe.nearDef||0):distance===2?(oe.farDef||0):0)+(oe.alternating&&st[j].turns%2===0&&st[j].turns>0?6:0)-(ae.pierce||0)-(e.pierce||0));let damage=Math.max(2,Math.round(attack-defense))+(ae.splash||0);
   if(ae.type==='heat')damage*=1-(oe.heatResist||0)+(oe.heatWeak||0);if(ae.type==='cold')damage*=1-(oe.coldResist||0);if(ae.type==='beam')damage*=1-(oe.beamResist||0);if(/電撃|電磁|電気/.test(arm.name))damage*=1-(oe.electricResist||0);if(distance===0)damage*=1-(oe.meleeResist||0);
   if(oe.firstShield&&!st[j].shield){damage-=oe.firstShield;st[j].shield=true;}
   damage=Math.max(1,Math.round(damage));const baseDamage=damage;if(ultimate)damage=Math.round(damage*1.5);const actual=Math.min(hp[j],damage);hp[j]-=damage;
   if(hp[j]<=0&&oe.survive&&!st[j].survived){hp[j]=1;st[j].survived=true;add('special',`${g.name}：不死身ボディがHP1で耐えた！`,j);}
   add(ultimate?'finisher':crit?'critical':'attack',`${label}・${arm.name}！ ${ultimate?'必殺！ ×1.5 ':crit?'会心！ ':''}${damage} DAMAGE！`,i,{slot,damage,weapon:arm.index,critical:crit,...(ultimate?{baseDamage,ultimate:true}: {})});
   if(hp[j]<=0){if(oe.deathBlast){hp[i]-=oe.deathBlast;add('blast',`${g.name}の自爆ヘッド！ ${oe.deathBlast} DAMAGE！`,j);}finish('攻撃');break;}
   if(ae.poison){st[j].poison=Math.min(3,st[j].poison+1);add('special',`毒が蓄積！ ${st[j].poison}層。`,i);}
   if(ae.wound)st[j].wound+=ae.wound;if(ae.burn&&!oe.burnResist&&!oe.heatResist)st[j].burn+=ae.burn;if(ae.slow)st[j].slow=Math.max(st[j].slow,ae.slow);if(ae.hold)st[j].hold=Math.max(st[j].hold,ae.hold);if(ae.corrode)st[j].corrode=Math.min(8,st[j].corrode+ae.corrode);
   if(ae.drain||e.drain)heal(i,actual*Math.min(.5,(ae.drain||0)+(e.drain||0)),'吸血');if(oe.absorb)heal(j,actual*oe.absorb,'吸収');
   const reflect=(oe.reflectAll||0)+(distance===0?(oe.reflect||0):0);if(reflect){hp[i]-=reflect;add('reflect',`${g.name}の反撃装甲！ −${reflect}HP`,j);if(finish('反撃'))break;}
   if(!oe.recoilResist){if(ae.push&&rand()<ae.push&&distance<2){distance++;add('move',`衝撃で押し出した！ ${DIST[distance]}。`,i);}if(ae.pull&&rand()<ae.pull&&distance>0){distance--;add('move',`${arm.name}で引き寄せた！ ${DIST[distance]}。`,i);}}
  }
  if(ended)break;
  if(e.regen)heal(i,e.regen,'修復');
  const extra=Math.max(0,st[i].poison*2-(e.poisonResist||0))+st[i].wound+st[i].burn;const cost=Math.max(0,s[i].cost+(oe.enemyCost||0)-(hp[i]<=s[i].maxHP*.35?(e.lowCut||0):0)-(st[i].turns<=2?(e.firstCut||0):0))+extra;
  hp[i]-=cost;add('cost',`維持コスト −${cost}HP${extra?`（毒・損傷 ${extra} を含む）`:''}`,i,{cost});st[i].wound=0;st[i].burn=0;
  if(finish('維持コスト')){add('end',`${f.name}は身体の維持コストに耐えられない！`,i);break;}actor=j;
 }
 if(!ended){reason='膠着';add('end','200ターン経過。決着つかず、引き分け！');}
 return{winner,hp:hp.map(x=>Math.max(0,Math.round(x))),maxHP:s.map(x=>x.maxHP),turns:turn,reason,seed:seed>>>0,events};
}
