// Keep music outside DOM renders, so equipping parts never restarts a track.
export function createMusic(makeAudio = src => new Audio(src)) {
  let tracks, selected, wanted;
  const pending = new Set();
  function update(scene, muted) {
    if (!tracks && !muted) {
      try {
        tracks = Object.fromEntries(['bgm', 'battle'].map(key => {
          const audio = makeAudio(new URL(`./assets/${key}.mp3`, import.meta.url).href);
          audio.loop = true;
          audio.preload = 'metadata';
          audio.volume = 0.3;
          return [key, audio];
        }));
      } catch { return; }
    }
    if (!tracks) return;
    if (selected !== scene) {
      if (selected) {
        tracks[selected].pause();
        tracks[selected].currentTime = 0;
      }
      selected = scene;
    }
    const active = !muted && !document.hidden ? tracks[selected] : null;
    wanted = active;
    for (const audio of Object.values(tracks)) {
      if (audio !== active) { audio.pause(); continue; }
      if (!audio.paused || pending.has(audio)) continue;
      pending.add(audio);
      // Autoplay rejection is retried on the next user gesture.
      Promise.resolve(audio.play()).catch(() => {}).finally(() => {
        pending.delete(audio);
        if (wanted !== audio || document.hidden) audio.pause();
      });
    }
  }
  return {update};
}
