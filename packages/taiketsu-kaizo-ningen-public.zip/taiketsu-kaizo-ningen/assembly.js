// Shared attachment geometry for the lab, battle, previews and share cards.
// Rectangles use a 400 x 500 front-facing mannequin; neck/waist and shoulders overlap.
import {SOURCE_RECTS,assetKey} from './atlas-layout.js';
export const ASSEMBLY_ORDER=['leg','right','left','body','head'];
export const ASSEMBLY={
 head:{x:132,y:12,w:136,h:137,rotate:0,mirror:false},
 body:{x:102,y:130,w:196,h:192,rotate:0,mirror:false},
 right:{x:47,y:161,w:148,h:203,rotate:12,mirror:true},
 left:{x:205,y:161,w:148,h:203,rotate:-12,mirror:false},
 leg:{x:102,y:300,w:196,h:195,rotate:0,mirror:false}
};
export function assemblyRect(slot,p){const r={...ASSEMBLY[slot]};if((slot==='right'||slot==='left')&&p){const crop=SOURCE_RECTS[p.cat][p.index],width=Math.min(148,Math.max(65,r.h*crop[2]/crop[3]));r.x+=(r.w-width)/2;r.w=width;}return r;}
export function assemblyStyle(slot,p){const r=assemblyRect(slot,p);return `left:${r.x/4}%;top:${r.y/5}%;width:${r.w/4}%;height:${r.h/5}%;transform:rotate(${r.rotate}deg) scaleX(${r.mirror?-1:1});transform-origin:50% 0%;`;}
export function drawAssembly(ctx,fighter,parts,images,sourceRects,x,y,width,height){
 const scale=Math.min(width/400,height/500),ox=x+(width-400*scale)/2,oy=y+(height-500*scale)/2;
 for(const slot of ASSEMBLY_ORDER){const p=parts[fighter[slot]],im=images[assetKey(p)],r=assemblyRect(slot,p),crop=sourceRects[p.cat][p.index];ctx.save();ctx.translate(ox+(r.x+r.w/2)*scale,oy+r.y*scale);ctx.rotate(r.rotate*Math.PI/180);ctx.scale(r.mirror?-1:1,1);ctx.drawImage(im,...crop,-r.w*scale/2,0,r.w*scale,r.h*scale);ctx.restore();}
}
