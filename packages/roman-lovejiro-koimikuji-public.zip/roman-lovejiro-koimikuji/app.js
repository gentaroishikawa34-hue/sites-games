const fortunes = ["大吉","吉","中吉","小吉","末吉","凶"];

let audioCtx = null;
let seEnabled = true;
let bgmEnabled = false;
let bgmTimer = null;
let bgmNodes = [];

function ensureAudio(){
  if(!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  if(audioCtx.state === "suspended") audioCtx.resume();
}

function bell(freq=880, when=0, duration=.8, gain=.08){
  if(!seEnabled) return;
  ensureAudio();
  const t = audioCtx.currentTime + when;
  const osc = audioCtx.createOscillator();
  const g = audioCtx.createGain();
  osc.type = "sine";
  osc.frequency.setValueAtTime(freq, t);
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(gain, t + .02);
  g.gain.exponentialRampToValueAtTime(0.0001, t + duration);
  osc.connect(g).connect(audioCtx.destination);
  osc.start(t); osc.stop(t + duration + .03);
}

function playDrawSE(){
  if(!seEnabled) return;
  bell(659.25,0,.55,.06);
  bell(880,.12,.65,.055);
  bell(1318.5,.28,.9,.045);
}

function stopBgm(){
  if(bgmTimer) clearInterval(bgmTimer);
  bgmTimer = null;
  bgmNodes.forEach(n => { try{ n.stop?.(); }catch(e){} });
  bgmNodes = [];
}

function bgmPulse(){
  if(!bgmEnabled) return;
  ensureAudio();
  const notes = [261.63,329.63,392.00,523.25,392.00,329.63];
  const base = audioCtx.currentTime;
  notes.forEach((f,i)=>{
    const osc = audioCtx.createOscillator();
    const g = audioCtx.createGain();
    osc.type = "sine";
    osc.frequency.value = f;
    const t = base + i*1.25;
    g.gain.setValueAtTime(.0001,t);
    g.gain.exponentialRampToValueAtTime(.014,t+.15);
    g.gain.exponentialRampToValueAtTime(.0001,t+1.05);
    osc.connect(g).connect(audioCtx.destination);
    osc.start(t); osc.stop(t+1.1);
    bgmNodes.push(osc); osc.onended=()=>{ bgmNodes=bgmNodes.filter(n=>n!==osc); osc.disconnect(); g.disconnect(); };
  });
}

function startBgm(){
  stopBgm();
  bgmPulse();
  bgmTimer = setInterval(bgmPulse, 7600);
}

function pick(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

function trackEvent(name, params={}){
  if(typeof window.gtag === "function") window.gtag("event", name, params);
}

let hasDrawn=false, shareFile=null, shareURL=null;
function drawOmikuji(){
 if(hasDrawn)return; hasDrawn=true;
 const draw=document.getElementById('draw'); draw.disabled=true;
 try{if(seEnabled||bgmEnabled)ensureAudio();}catch(e){}
 const fortune=pick(fortunes), work=pick(works);
 trackEvent("draw_omikuji", {fortune, work_number:work.no});
 const overlay=document.getElementById('gacha-overlay');
 overlay.classList.add('show'); overlay.setAttribute('aria-hidden','false');
 document.querySelector('main').inert=true;
 setTimeout(()=>{try{playDrawSE();}catch(e){}},100);
 setTimeout(()=>{
  document.getElementById('fortune').textContent=fortune;
  document.getElementById('number').textContent='第'+String(work.no).padStart(3,'0')+'首';
  document.getElementById('tanka').textContent=work.tanka;
  document.getElementById('poem').textContent=work.poem;
  document.getElementById('home-screen').hidden=true;
  document.getElementById('result-screen').hidden=false;
  const ad=document.getElementById('affiliate-ad');
  ad.hidden=false;
  ad.querySelectorAll('[data-ad-src]').forEach(img=>{img.src=img.dataset.adSrc;});
  overlay.classList.remove('show'); overlay.setAttribute('aria-hidden','true');
  document.querySelector('main').inert=false;
  window.scrollTo(0,0); document.getElementById('result-title').focus({preventScroll:true});
  prepareShare();
 },matchMedia('(prefers-reduced-motion: reduce)').matches?350:2300);
}
async function prepareShare(){
 const b=document.getElementById('share-result'); b.disabled=true;
 try{await document.fonts.ready;const blob=await makeShareBlob();if(!blob)throw Error();
 shareFile=new File([blob],'roman-lovejiro-koimikuji.png',{type:'image/png'});
 shareURL=URL.createObjectURL(blob);document.getElementById('save-image').href=shareURL;
 document.getElementById('share-preview').src=shareURL;b.disabled=false;
 }catch(e){showToast('画像を作成できませんでした。結果のコピーをご利用ください。');}
}
function currentShareText(){
  const fortune = document.getElementById("fortune").textContent.trim();
  const tanka = document.getElementById("tanka").textContent.trim();
  const poem = document.getElementById("poem").textContent.trim();
  return `浪漫ラブ次朗の恋みくじ\nー恋に効く。愛が届く。\n【${fortune}】\n\n${tanka}\n\n${poem}\n\n#浪漫ラブ次朗\n#恋みくじ\nhttps://romanlovejiro.com/`;
}

function showToast(message){
  const t = document.getElementById("share-toast");
  t.textContent = message;
  t.classList.add("show");
  setTimeout(()=>t.classList.remove("show"), 1800);
}

function wrapJapanese(ctx, text, maxWidth){
  const out = [];
  for(const para of text.split("\n")){
    let line = "";
    for(const ch of para){
      const test = line + ch;
      if(ctx.measureText(test).width > maxWidth && line){
        out.push(line);
        line = ch;
      } else {
        line = test;
      }
    }
    if(line) out.push(line);
    if(!para) out.push("");
  }
  return out;
}

function roundRect(ctx,x,y,w,h,r){
  const rr=Math.min(r,w/2,h/2);
  ctx.beginPath();
  ctx.moveTo(x+rr,y);
  ctx.arcTo(x+w,y,x+w,y+h,rr);
  ctx.arcTo(x+w,y+h,x,y+h,rr);
  ctx.arcTo(x,y+h,x,y,rr);
  ctx.arcTo(x,y,x+w,y,rr);
  ctx.closePath();
}

async function makeShareBlob(){
  const fortune = document.getElementById("fortune").textContent.trim();
  const number = document.getElementById("number").textContent.trim();
  const tanka = document.getElementById("tanka").textContent.trim();
  const poem = document.getElementById("poem").textContent.trim();

  const canvas = document.createElement("canvas");
  canvas.width = 1080;
  canvas.height = 1350;
  const ctx = canvas.getContext("2d");

  // Background
  const bg = ctx.createLinearGradient(0,0,0,1350);
  bg.addColorStop(0,"#180d13");
  bg.addColorStop(1,"#32151f");
  ctx.fillStyle = bg;
  ctx.fillRect(0,0,1080,1350);

  // subtle glow
  const rg = ctx.createRadialGradient(820,180,10,820,180,440);
  rg.addColorStop(0,"rgba(210,72,95,.22)");
  rg.addColorStop(1,"rgba(210,72,95,0)");
  ctx.fillStyle = rg;
  ctx.fillRect(0,0,1080,700);

  // outer frame
  ctx.strokeStyle = "rgba(231,201,128,.75)";
  ctx.lineWidth = 2;
  roundRect(ctx,38,38,1004,1274,28); ctx.stroke();
  ctx.strokeStyle = "rgba(231,201,128,.22)";
  roundRect(ctx,54,54,972,1242,22); ctx.stroke();

  // header
  ctx.fillStyle = "#e8cf93";
  ctx.font = '28px "Yu Mincho","Hiragino Mincho ProN",serif';
  ctx.textAlign = "center";
  ctx.fillText("浪漫ラブ次朗の",540,94);

  ctx.fillStyle = "#fff5e7";
  ctx.font = '700 72px "Yu Mincho","Hiragino Mincho ProN",serif';
  ctx.fillText("恋みくじ",540,176);
  ctx.font='24px "Yu Mincho","Hiragino Mincho ProN",serif';
  ctx.fillStyle="#e8cf93";ctx.fillText("ー恋に効く。愛が届く。",540,216);

  // Fortune card
  ctx.fillStyle = "#fffaf2";
  roundRect(ctx,96,238,888,160,22); ctx.fill();
  ctx.strokeStyle = "rgba(201,162,90,.6)";
  ctx.lineWidth = 2;
  roundRect(ctx,96,238,888,160,22); ctx.stroke();

  ctx.fillStyle = "#8c1626";
  ctx.textAlign = "left";
  ctx.font = '700 64px "Yu Mincho","Hiragino Mincho ProN",serif';
  ctx.fillText(fortune,146,338);
  ctx.textAlign = "right";
  ctx.fillStyle = "#8b6d61";
  ctx.font = '28px "Yu Mincho","Hiragino Mincho ProN",serif';
  ctx.fillText(number,934,330);

  // Tanka
  ctx.textAlign = "left";
  ctx.fillStyle = "#fff8ef";
  ctx.font = '600 46px "Yu Mincho","Hiragino Mincho ProN",serif';
  const tankaLines = wrapJapanese(ctx,tanka,820);
  let y = 490;
  for(const line of tankaLines){
    ctx.fillText(line,130,y);
    y += 78;
  }

  // Divider
  y += 8;
  const lineGrad = ctx.createLinearGradient(130,y,950,y);
  lineGrad.addColorStop(0,"#c9a25a");
  lineGrad.addColorStop(1,"rgba(201,162,90,0)");
  ctx.strokeStyle=lineGrad;ctx.lineWidth=2;
  ctx.beginPath();ctx.moveTo(130,y);ctx.lineTo(950,y);ctx.stroke();

  // Poem
  y += 62;
  ctx.fillStyle="#e5c77c";
  ctx.font='24px "Yu Mincho","Hiragino Mincho ProN",serif';
  ctx.fillText("SMALL POEM",130,y);
  y += 44;
  ctx.fillStyle="#f3e9dc";
  ctx.font='32px "Yu Mincho","Hiragino Mincho ProN",serif';
  const poemLines=wrapJapanese(ctx,poem,820);
  for(const line of poemLines){
    ctx.fillText(line,130,y);
    y += 52;
  }

  // Footer
  ctx.textAlign="center";
  ctx.fillStyle="#e6d3aa";
  ctx.font='26px "Yu Mincho","Hiragino Mincho ProN",serif';
  ctx.fillText("浪漫ラブ次朗",540,1236);
  ctx.fillStyle="#a98e7c";
  ctx.font='21px "Yu Mincho","Hiragino Mincho ProN",serif';
  ctx.fillText("#浪漫ラブ次朗   #恋みくじ",540,1266);
  ctx.fillText("romanlovejiro.com",540,1301);

  return await new Promise(resolve => canvas.toBlob(resolve,"image/png"));
}

async function shareResult(){
 if(!shareFile)return;
 try{if(navigator.canShare?.({files:[shareFile]}) && navigator.share){
 await navigator.share({title:'浪漫ラブ次朗の恋みくじ',text:currentShareText(),files:[shareFile]});
 trackEvent("share_result", {method:"web_share"});return;}
 }catch(e){if(e.name==='AbortError')return;}
 trackEvent("share_result", {method:"image_save_dialog"});
 document.getElementById('image-dialog').showModal();
}
document.getElementById("draw").addEventListener("click", drawOmikuji);
document.getElementById("affiliate-rakuten").addEventListener("click", ()=>{
  trackEvent("affiliate_click", {affiliate_network:"a8net",advertiser:"rakuten",placement:"result_bottom",transport_type:"beacon"});
});
document.getElementById("affiliate-second").addEventListener("click", ()=>{
  trackEvent("affiliate_click", {affiliate_network:"a8net",advertiser:"a8_126240",placement:"result_bottom_second",transport_type:"beacon"});
});

document.getElementById("share-result").addEventListener("click", shareResult);

document.getElementById("copy-result").addEventListener("click", async ()=>{
  try{
    await navigator.clipboard.writeText(currentShareText());
    trackEvent("copy_result");
    showToast("結果をコピーしました");
  }catch(e){
    const t=document.getElementById("copy-fallback");t.hidden=false;t.value=currentShareText();t.focus();t.select();showToast("文章を選択してコピーしてください");
  }
});

document.getElementById("se-toggle").addEventListener("click", (e)=>{
  seEnabled = !seEnabled;
  e.currentTarget.classList.toggle("on", seEnabled);e.currentTarget.setAttribute("aria-pressed",String(seEnabled)); e.currentTarget.textContent="鈴 SE "+(seEnabled?"ON":"OFF");
  if(seEnabled){ ensureAudio(); bell(880,0,.45,.05); }
});

document.getElementById("bgm-toggle").addEventListener("click", (e)=>{
  bgmEnabled = !bgmEnabled;
  e.currentTarget.classList.toggle("on", bgmEnabled);e.currentTarget.setAttribute("aria-pressed",String(bgmEnabled));e.currentTarget.textContent="♫ BGM "+(bgmEnabled?"ON":"OFF");
  if(bgmEnabled){ ensureAudio(); startBgm(); }
  else stopBgm();
});

document.getElementById('close-dialog').onclick=()=>document.getElementById('image-dialog').close();
document.addEventListener('visibilitychange',()=>{if(document.hidden)stopBgm();else if(bgmEnabled)startBgm();});
if(document.modelContext?.registerTool){
 const lifecycle=new AbortController();
 try{Promise.resolve(document.modelContext.registerTool({name:'read_love_fortune',description:'Read the currently displayed love fortune and its unchanged poem pair. Does not draw a new fortune.',inputSchema:{type:'object',properties:{},additionalProperties:false},annotations:{readOnlyHint:true},execute(input){if(!input||Object.keys(input).length)throw Error('No parameters accepted');if(document.getElementById('result-screen').hidden)return {status:'not_drawn'};return {fortune:document.getElementById('fortune').textContent,number:document.getElementById('number').textContent,tanka:document.getElementById('tanka').textContent,poem:document.getElementById('poem').textContent};}},{signal:lifecycle.signal})).catch(()=>{});}catch(e){}
 addEventListener('pagehide',()=>lifecycle.abort(),{once:true});
}
